const swal = require('sweetalert2');
/**
 * 銀行情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt02omt0201Ctrl', function($scope, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.bank = '';
            $scope.search = '';
            $scope.datatable = {};

            $scope.depositTypeList = CONST.DEPOSIT_TYPE_LIST;

            // 銀行一覧の取得処理
            $scope.getbankList();

            // datatable options初期化
            $scope.initDtOption();
        };

        /**
         * 銀行情報一覧の取得処理
         */
        $scope.getbankList = function() {
            $api.post('/omt02/r/list', $scope.search, function(res) {
                if (res.success) {
                    $scope.bankList = [];
                    let data = res.data;
                    for (let i = 0; i < data.length; i++) {
                        let info = data[i];
                        $scope.bankList.push(info);
                    }
                    if ($scope.bankList.length == 0) {
                        commonService.removeData(CONST.PERMISSION_KEY);
                    }
                } else {
                    $scope.bankList = [];
                    commonService.removeData(CONST.PERMISSION_KEY);
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [8],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * 銀行削除処理
         */
        $scope.bankDel = function(bankInfo) {
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    let data = {
                        rowsId: bankInfo.rowsId,
                    };
                    $api.post('/omt02/d/item', data, function(res) {
                        if (res.success) {
                            message.showSuccess('削除しました。');
                            $scope.getbankList();
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        };
    });

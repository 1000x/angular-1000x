const swal = require('sweetalert2');
/**
 * 出金情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('oswosw0101Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 出金情報一覧の取得処理
            // $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                yyyymm: '', // 検索用請求年月
                withdrawalToYmd: '', // 検索出金期限年月
                withdrawalType: '', // 検索用支払い状態
                corporationCompId: '', // 検索用契約会社
            };

            $scope.searchText = ''; // データ絞り込み用
            $scope.datatable = {};
            $scope.payList = [];

            // select list
            $scope.withdrawalTypeList = CONST.WITHDRAWAL_TYPE_LIST; // 出金状態
            $scope.contractorCompList = {}; // 契約会社リスト
            $scope.bankList = {}; // 支払先リスト

            // drop listの取得
            $api.get('/osw01/r/droplist', function(res) {
                if (res.success) {
                    // 会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(res.data.contractorCompList, 'corporationCompId', 'customerCompNm');
                }
            });
        };

        /**
         * 出金情報一覧の取得処理
         */
        $scope.searchList = function() {
            $api.post('/osw01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.withdrawalList = [];
                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(data.contractorCompList, 'corporationCompId', 'customerCompNm');

                    for (let i = 0; i < data.withdrawalList.length; i++) {
                        let info = data.withdrawalList[i];
                        info.checked = false;
                        $scope.withdrawalList.push(info);
                    }

                    //銀行名称リスト
                    $scope.corporationBankList = commonService.makeCorporationBankDroplist(data.withdrawalBankList);

                    // dropdown and select trigger
                    $timeout(function() {
                        $('.btn-setting').dropdown({
                            on: 'hover',
                            duration: '100',
                        });
                    });
                } else {
                    $scope.withdrawalList = [];
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [0, 7],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * dtInstanceCallback table
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み(Search)
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * 出金削除処理
         */
        $scope.withdrawalDel = function(withdrawalInfo) {
            let $url = '/osw01/d/item/' + withdrawalInfo.rowsId;

            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    $api.get($url, function(res) {
                        if (res.success) {
                            message.showSuccess('削除しました。');
                            // 出金情報一覧の取得処理
                            $scope.searchList();
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        };
        $scope.form_check = function() {
            jQuery('.searchform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 出金予定年月選択
                    withdrawalToYm: {
                        identifier: 'withdrawalToYm',
                        rules: [
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5019', '出金予定年月'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };

        /**
         * CSVダウロードの取得処理
         */
        $scope.download = function() {
            let param = {
                yyyymm: $scope.search.yyyymm,
                withdrawalToYmd: $scope.search.withdrawalToYmd,
                withdrawalFlg: $scope.search.withdrawalFlg,
                corporationCompId: $scope.search.corporationCompId,
            };

            $api.post('/osw01/download/list', param, function(res) {
                if (res.success) {
                    let blob = $api.b64toBlob(res.data.fileBase64String, 'application/octet-stream');
                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, res.data.fileName);
                    } else {
                        let objectUrl = URL.createObjectURL(blob);
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = objectUrl;
                        a.download = res.data.fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };
    });

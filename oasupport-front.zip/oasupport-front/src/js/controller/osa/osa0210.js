const swal = require('sweetalert2');
/**
 * 二段階認証画面コントローラ
 */
module.exports = app =>
    app.controller('osaosa0210Ctrl', function($scope, $timeout, $auth, message, $session, CONST) {
        /**
         * 画面初期化
         */
        $scope.init = function() {
            $scope.account = {};

            /**
             * 二段階認証設定STEPS
             *
             * 0: 初期表示
             * 1: スキャン画面表示
             * 2: 認証コード確認画面表示
             * 3: 認証コード確認
             * 9: 完了
             */
            $scope.STEPS = {
                init: '0',
                qrcode: '1',
                secretKey: '2',
                validCode: '3',
                end: '9',
            };

            // 二段階認証ステータス取得
            $scope.oneTimeCodeSt = $session.ONE_TIME_CODE_ST;

            // step
            $scope.nextStep($scope.STEPS.init);
        };

        /**
         * 二段階認証コード有効化処理
         */
        $scope.toValid = function() {
            jQuery('.pass_input_modal')
                .modal({
                    onShow: function() {
                        $timeout(function() {
                            $scope.pass_form_check();
                        });
                    },
                    onApprove: function() {
                        if (!$scope.isValidPassForm()) {
                            return false;
                        }
                        $auth.checkAuthority($session.USR_ID, $scope.account.password).then(
                            function() {
                                $auth.generateQRCode($session.USR_ID, $scope.account.password).then(
                                    function(result) {
                                        // modal close
                                        jQuery('.pass_input_modal')
                                            .modal('hide')
                                            .parent()
                                            .removeClass('visible')
                                            .removeClass('active')
                                            .addClass('hidden');
                                        // QRコード表示
                                        $scope.nextStep($scope.STEPS.qrcode);
                                        // qrcode src
                                        $scope.account = jQuery.extend({}, $scope.account, result);
                                    },
                                    function() {
                                        // modal close
                                        jQuery('.pass_input_modal')
                                            .modal('hide')
                                            .parent()
                                            .removeClass('visible')
                                            .removeClass('active')
                                            .addClass('hidden');
                                    }
                                );
                            },
                            function(message) {
                                jQuery('.pass_input_modal').form('add prompt', 'password', message);
                            }
                        );

                        return false;
                    },
                    onDeny: function() {
                        $scope.nextStep($scope.STEPS.init);
                    },
                    onHide: function() {
                        $scope.nextStep($scope.STEPS.init);
                    },
                })
                .modal('show');
        };

        /**
         * 二段階認証無効化処理
         */
        $scope.toInvalid = function() {
            jQuery('.pass_input_modal')
                .modal({
                    onShow: function() {
                        $timeout(function() {
                            $scope.pass_form_check();
                        });
                    },
                    onApprove: function() {
                        if (!$scope.isValidPassForm()) {
                            return false;
                        }
                        $auth.checkAuthority($session.USR_ID, $scope.account.password).then(
                            function() {
                                $auth.releasePassword($session.USR_ID, $scope.account.password).then(
                                    function() {
                                        // modal close
                                        jQuery('.pass_input_modal')
                                            .modal('hide')
                                            .parent()
                                            .removeClass('visible')
                                            .removeClass('active')
                                            .addClass('hidden');
                                        $scope.oneTimeCodeSt = CONST.ONE_TIME_CODE_ST.off;
                                        $session.ONE_TIME_CODE_ST = CONST.ONE_TIME_CODE_ST.off;
                                    },
                                    function() {
                                        // modal close
                                        jQuery('.pass_input_modal')
                                            .modal('hide')
                                            .parent()
                                            .removeClass('visible')
                                            .removeClass('active')
                                            .addClass('hidden');
                                    }
                                );
                            },
                            function(message) {
                                jQuery('.pass_input_modal').form('add prompt', 'password', message);
                            }
                        );

                        return false;
                    },
                    onDeny: function() {
                        $scope.nextStep($scope.STEPS.init);
                    },
                    onHide: function() {
                        $scope.nextStep($scope.STEPS.init);
                    },
                })
                .modal('show');
        };

        /**
         * キャンセル処理
         */
        $scope.cancle = function() {
            swal({
                text: 'キャンセルしてよろしいですか。',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $timeout(function() {
                            $scope.init();
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         * next step
         */
        $scope.nextStep = function(step) {
            $scope.step = step;
            //認証コードチェック
            if (step == $scope.STEPS.validCode) {
                $timeout(function() {
                    $scope.totp_key_form_check();
                });
            }
        };

        /**
         * 確認
         */
        $scope.save = function() {
            if (!$scope.isValidTotpKeyForm()) {
                return false;
            }
            $auth.registePassword($session.USR_ID, $scope.account.password, $scope.account.secretKey, $scope.account.totpKey).then(
                function(result) {
                    $scope.nextStep($scope.STEPS.end);
                    $scope.account.backupKey = result.backupCode;
                    $scope.oneTimeCodeSt = CONST.ONE_TIME_CODE_ST.on;
                    $session.ONE_TIME_CODE_ST = CONST.ONE_TIME_CODE_ST.on;
                },
                function(message) {
                    jQuery('.totp_key_form').form('add prompt', 'totpKey', message);
                }
            );
            return false;
        };

        /**
         * is valid form
         */
        $scope.isValidPassForm = function() {
            return jQuery('.pass_input_modal').form('validate form');
        };

        /**
         * パスワード検証フォームチェック
         */
        $scope.pass_form_check = function() {
            jQuery('.pass_input_modal').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // パスワード
                    password: {
                        identifier: 'password',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'パスワード'),
                            },
                            {
                                type: 'minLength[6]',
                                prompt: message.getMsgById('E_XX_FW_5020', 'パスワード', '6'),
                            },
                        ],
                    },
                },
            });
        };

        /**
         * is valid form
         */
        $scope.isValidTotpKeyForm = function() {
            return jQuery('.totp_key_form').form('validate form');
        };

        /**
         * totp_key_formフォームチェック
         */
        $scope.totp_key_form_check = function() {
            jQuery('.totp_key_form').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 確認コード
                    totp_key: {
                        identifier: 'totpKey',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '認証コード'),
                            },
                            {
                                type: 'exactLength[6]',
                                prompt: message.getMsgById('E_XX_FW_5010', '認証コード', '6'),
                            },
                        ],
                    },
                },
            });
        };
    });

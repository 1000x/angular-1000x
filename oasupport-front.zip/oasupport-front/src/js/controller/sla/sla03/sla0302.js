const moment = require('moment');
/**
 * メール提案·画面コントローラ
 */
module.exports = app =>
    app.controller('slasla03sla0302Ctrl', function($scope, $api, message, CONST, commonService, $timeout) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 履歴書一覧の取得処理
            $scope.searchresumeList();
            // 宛先情報一覧の取得処理
            $scope.searchaddressList();
            // datatable options初期化
            $scope.initDtOption();
            // 自社基本情報の取得
            $scope.title = '';
            $scope.getTitle();

            $scope.selectCompList = [];
            $scope.addressList = [];
            $scope.selectComp_index_0_sendflg = '';
            $scope.sendHasClicked = false;
        };

        /**
         * data init
         */
        $scope.initData = function() {
            $scope.searchResume = ''; // データ絞り込み用
            $scope.searchAddress = ''; // データ絞り込み用
            $scope.resumeList = [];
            $scope.datatable = {};
            $scope.search = {};
            $scope.toggleCheckFlg = false;
            $scope.addressCheckFlg = false;
            $scope.address2 = {
                toEmail: '',
                ccEmail1: '',
                ccEmail2: '',
                ccEmail3: '',
                title: '',
                yobi: '',
            };
            // select list
            $scope.affiliationList = CONST.AFFILIATION_LIST; // 所属
            $scope.parallelFlgList = CONST.PARALLEL_FLG_LIST; // 並行状況
        };

        /**
         * 履歴書一覧の取得処理
         */
        $scope.searchresumeList = function() {
            $api.post('/sla01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.resumeList = [];

                    for (let i = 0; i < data.resumeList.length; i++) {
                        let info = data.resumeList[i];
                        if (info.operationStatus == '1') {
                            $scope.resumeList.push(info);
                        }
                    }

                    // dropdown and select trigger
                    $timeout(function() {
                        $('.btn-setting').dropdown({
                            on: 'hover',
                            duration: '100',
                        });
                    });
                } else {
                    $scope.resumeList = [];
                }
            });
        };

        /**
         * 宛先情報一覧の取得処理
         */
        $scope.searchaddressList = function() {
            $api.get('/sla02/r/list', function(res) {
                if (res.success) {
                    $scope.addressList = res.data.addressList;
                }
            });
        };

        $scope.getTitle = function() {
            $scope.company = {};

            // 自社基本情報の取得
            $api.get('/omt01/r/item/', function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.company = data;
                    $scope.title = '【' + $scope.company.compNm + '】' + '【要員】JAVA、PHP' + '（' + moment().format('YYYY-MM-DD') + '）';
                }
            });
        };

        /**
         * 「全選択/解除」ボタン押下
         */
        $scope.toggle_check = function() {
            for (let i = 0; i < $scope.resumeList.length; i++) {
                $scope.resumeList[i].checked = !$scope.toggleCheckFlg;
            }
            $scope.toggleCheckFlg = !$scope.toggleCheckFlg;
        };

        /**
         * 「全選択/解除」ボタン押下
         */
        $scope.address_check = function() {
            for (let j = 0; j < $scope.addressList.length; j++) {
                $scope.addressList[j].checked = !$scope.addressCheckFlg;
            }
            $scope.addressCheckFlg = !$scope.addressCheckFlg;
        };

        /**
         * hasChecked
         */
        $scope.hasChecked = function() {
            if (!$scope.resumeList || !$scope.resumeList) return false;
            let hasChecked = false;
            for (let i = 0; i < $scope.resumeList.length; i++) {
                if ($scope.resumeList[i].checked) {
                    for (let j = 0; j < $scope.addressList.length; j++) {
                        if ($scope.addressList[j].checked) {
                            hasChecked = true;
                            break;
                        }
                    }
                }
            }
            return hasChecked;
        };

        /**
         *  メール送信処理
         */
        $scope.showMailPreviewModal = function() {
            $('.ui.form2.modal')
                .modal('setting', 'closable', false)
                .modal('show');
        };

        /**
         *  show一括メール送信
         */
        $scope.showCompNmListModal = function() {
            $scope.sendHasClicked = false;
            $scope.selectComp_index_0_sendflg = '';
            $scope.selectCompList = [];
            for (let j = 0; j < $scope.addressList.length; j++) {
                if ($scope.addressList[j].checked) {
                    $scope.addressList[j].sendflg = '';
                    $scope.selectCompList.push($scope.addressList[j]);
                }
            }
            $('.ui.form.modal')
                .modal('setting', 'closable', false)
                .modal('show');
        };

        /**
         *  一括メール送信処理
         */
        $scope.mailSendTogether = function() {
            $scope.sendHasClicked = true;
            let resumeRowsIdList = [];
            for (let i = 0; i < $scope.resumeList.length; i++) {
                if ($scope.resumeList[i].checked) {
                    resumeRowsIdList.push($scope.resumeList[i].rowsId);
                }
            }
            let tasks = [];
            $scope.selectCompList.forEach(function(address) {
                let mailList = {
                    resumeRowsIdList: resumeRowsIdList,
                    title: $scope.title,
                    addressRowsId: address.rowsId,
                };
                $scope.selectComp_index_0_sendflg = '1';
                address.sendflg = '1';
                tasks.push(function(next) {
                    $api.post(
                        '/sla03/mail/list',
                        mailList,
                        function(res) {
                            if (res.success) {
                                $scope.selectComp_index_0_sendflg = '2';
                                address.sendflg = '2';
                                next();
                            } else {
                                $scope.selectComp_index_0_sendflg = '0';
                                address.sendflg = '0';
                                next();
                            }
                        },
                        false
                    );
                });
            });

            $api.execTasks(
                tasks,
                function(data) {
                    message.showSuccess('success');
                },
                function() {
                    alert('error!');
                }
            );
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                bPaginate: false,
                info: false,
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                order: [],
                displayLength: 10,
            };
        };

        /**
         * dtInstanceCallback table
         */
        $scope.dtInstanceCallbackResume = function(dtInstance) {
            $scope.dtInstanceResume = dtInstance;
        };

        /**
         * dtInstanceCallback table
         */
        $scope.dtInstanceCallbackAddress = function(dtInstance) {
            $scope.dtInstanceAddress = dtInstance;
        };

        /**
         * データの絞り込み(SearchResume)
         */
        $scope.doSearchResume = function() {
            if (!$scope.dtInstanceResume) return;
            $scope.dtInstanceResume.DataTable.search($scope.searchResume).draw();
        };
        /**
         * データの絞り込み(SearchAddress)
         */
        $scope.doSearchAddress = function() {
            if (!$scope.dtInstanceAddress) return;
            $scope.dtInstanceAddress.DataTable.search($scope.searchAddress).draw();
        };
    });

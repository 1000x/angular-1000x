/**
 * commonService
 */
module.exports = app =>
    app.service('commonService', function($http, $api, message) {
        this.setData = function(key, data) {
            this.removeData(key);
            return window.localStorage.setItem(key, window.JSON.stringify(data));
        };

        this.getData = function(key) {
            return window.JSON.parse(window.localStorage.getItem(key));
        };

        this.removeData = function(key) {
            return window.localStorage.removeItem(key);
        };

        /**
         * datatable options
         */
        this.getDtLanguage = function() {
            return {
                paginate: {
                    next: '次へ',
                    previous: '前へ',
                },
                emptyTable: 'データが見つかりません。',
                info: '_START_ - _END_ / _TOTAL_件',
                infoEmpty: '',
                lengthMenu: '',
                infoFiltered: '全 _MAX_ 件から絞り込み',
                zeroRecords: 'データが見つかりません。',
            };
        };

        /**
         * 郵便番号から住所を検索する
         * @param postCd
         * @param callback(address)
         */
        this.getAddrByPostCd = function(postCd, callback) {
            if (!postCd) return '';
            let data = {
                address: postCd,
                language: 'ja',
                sensor: 'false',
            };
            let url = 'https://maps.googleapis.com/maps/api/geocode/json?' + jQuery.param(data);

            $api.show_loader();
            $http.get(url).then(
                function(res) {
                    let data = res.data;
                    if (data && data.status == 'OK') {
                        let addressArr = data.results[0].address_components;
                        let address = '';
                        if (addressArr[addressArr.length - 1]['short_name'] && addressArr[addressArr.length - 1]['short_name'].toUpperCase() != 'JP') {
                            address += addressArr[addressArr.length - 1]['long_name'];
                        }
                        for (let i = addressArr.length - 2; i > 0; i--) {
                            address += addressArr[i]['long_name'];
                        }
                        callback(address);
                    } else {
                        message.showError(message.getMsgById('E_XX_FW_5027'));
                    }
                    $api.hide_loader();
                },
                function() {
                    message.showError('サーバーへ接続が失敗しました。');
                    $api.hide_loader();
                }
            );
        };

        /**
         * makeArrToDroplist
         * @param arr
         * @param key_str
         * @param value_str
         */
        this.makeArrToDroplist = function(arr, key_str, value_str) {
            let result = {};
            angular.forEach(arr, function(info) {
                result[info[key_str]] = info[value_str];
            });

            return result;
        };

        /**
         * makeBankDroplist
         * @param arr
         * @param key_str
         * @param value_str1
         * @param value_str2
         * @param value_str3
         */
        this.makeBankDroplist = function(arr, key_str, value_str1, value_str2, value_str3, value_str4) {
            let result = {};
            angular.forEach(arr, function(info) {
                result[info[key_str]] = info[value_str1] + '[' + info[value_str2] + ':' + info[value_str3] + ' ' + info[value_str4] + ']';
            });

            return result;
        };

        /**
         * getBankName
         * @param arr
         * @param key_str
         * @param value_str
         */
        this.getBankName = function(arr, key_bank_id, bank_value, key_bank_nm_id) {
            let bankName = '';
            angular.forEach(arr, function(info) {
                if (info[key_bankid] != bank_value) {
                    //
                } else {
                    bankName = info[key_bank_nm_id];
                }
            });

            return bankName;
        };

        /**
         * makeCorporationBankDroplist(取引先銀行リスト用)
         * @param arr
         * @param key_str
         * @param value_str
         */
        this.makeCorporationBankDroplist = function(arr) {
            let result = {};
            angular.forEach(arr, function(info) {
                key = info['corporationCompId'] + info['bankId'];
                result[key] = info['bankNm'] + '[' + info['bankchKanji'] + ':' + info['accountCd'] + ' ' + info['accountNmKana'] + ']';
            });
            return result;
        };

        return this;
    });

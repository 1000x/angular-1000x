const moment = require('moment');
const swal = require('sweetalert2');
/**
 * 契約情報登録·画面コントローラ
 */
module.exports = app =>
    app.controller('osdosd0102Ctrl', function($scope, $location, $routeParams, $timeout, $api, message, CONST, commonService) {
        $scope.MAX_TAB_CNT = 10;

        /**
         * 初期化
         */
        $scope.init = function() {
            // 契約情報
            $scope.contract = {
                payDeadlineDayFlg: '1', // 支払期限(day):月末
                contractYm: moment().format('YYYY-MM'), // 契約月
                details: [],
            };
            $scope.tabIndex = 0;
            // 契約基本情報追加
            $scope.addDetailInfo();

            $scope.showUserSelect = false;
            $scope.detailInValidList = [];

            // select list 初期化
            $scope.initSelectList();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * select list 初期化
         */
        $scope.initSelectList = function() {
            if (JSON.stringify($routeParams) == '{}') {
                // select list
                $scope.contractTypeList = CONST.CONTRACT_TYPE_LIST; // 契約区分
                $scope.payDeadlineMonthList = CONST.PAY_DEADLINE_MONTH_LIST; // 支払期限(月)

                // drop listの取得
                $api.get('/osd01/r/droplist', function(res) {
                    if (res.success) {
                        // 銀行リスト
                        $scope.bankList = commonService.makeArrToDroplist(res.data.bankList, 'bankId', 'bankNm');
                        // 契約会社リスト
                        $scope.contractorCompList = commonService.makeArrToDroplist(res.data.contractorCompList, 'corporationCompId', 'customerCompNm');
                        // 部門リスト
                        $scope.departmentList = commonService.makeArrToDroplist(res.data.departmentList, 'departId', 'departNm');
                    }
                });
            } else {
                $scope.initData();
                $timeout(function() {
                    $scope.form_check();
                });
            }
        };

        /**
         * copy元データ取得
         */
        $scope.initData = function() {
            let search = {};
            $scope.contractTypeList = CONST.CONTRACT_TYPE_LIST; // 契約区分
            $scope.payDeadlineMonthList = CONST.PAY_DEADLINE_MONTH_LIST; // 支払期限(月)
            $api.post('/osd01/r/item/' + $routeParams.id, search, function(res) {
                if (res.success) {
                    $scope.contract = res.data.contractInfo;
                    // tabIndexの設定
                    if ($routeParams.detailId) {
                        for (let i = 0; i < $scope.contract.details.length; i++) {
                            if ($scope.contract.details[i].rowsId == $routeParams.detailId) {
                                $scope.tabIndex = i;
                                break;
                            }
                        }
                    }
                    // 銀行リスト
                    $scope.bankList = commonService.makeArrToDroplist(res.data.bankList, 'bankId', 'bankNm');
                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(res.data.contractorCompList, 'corporationCompId', 'customerCompNm');
                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(res.data.departmentList, 'departId', 'departNm');
                } else {
                    swal({
                        type: 'error',
                        text: res.data.message,
                        allowOutsideClick: false,
                        confirmButtonText: '契約一覧画面へ戻る',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('osd0101');
                        });
                    });
                }
            });
        };

        /**
         * change tab
         */
        $scope.changeTab = function(newTabIndex) {
            $scope.tabIndex = newTabIndex;
        };

        /**
         * 契約基本情報追加
         */
        $scope.addDetailInfo = function() {
            if ($scope.contract.details.length >= $scope.MAX_TAB_CNT) {
                return false;
            }
            $scope.contract.details.push({
                taxFlg: '1', // 税込
                overtimeFlg: '2', // 残業代なし
                contractDate: moment().format('YYYY-MM-DD'), // 契約開始日
                overPrice: '0', // 超過単価（円）
                deductPrice: '0', // 控除単価（円）
            });
            $scope.tabIndex = $scope.contract.details.length - 1;

            // detail form check
            $timeout(function() {
                $scope.detailFormCheck($scope.tabIndex);
            });
        };

        /**
         * 契約基本情報削除
         * @param index
         */
        $scope.removeDetailInfo = function(index, event) {
            if ($scope.contract.details.length > 1) {
                swal({
                    text: '削除してよろしいですか',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(
                    function(isConfirm) {
                        if (isConfirm) {
                            $scope.contract.details.splice(index, 1);
                            if ($scope.tabIndex >= $scope.contract.details.length) {
                                $scope.tabIndex = $scope.contract.details.length - 1;
                            }
                            $scope.$apply();
                        }
                    },
                    function(dismiss) {
                        // 処理なし
                    }
                );
            }

            event.stopPropagation();
            return false;
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            $scope.detailInValidList = [];
            // form valid : updates UI
            jQuery('.detailForm').form('validate form');
            jQuery('.mainform').form('validate form');

            if (jQuery('.mainform').form('is valid') && $scope.detailInValidList.length > 0) {
                let inValidFormIndex;
                if ($.inArray($scope.tabIndex, $scope.detailInValidList) != -1) {
                    inValidFormIndex = $scope.tabIndex;
                } else {
                    inValidFormIndex = $scope.detailInValidList[0];
                    $scope.tabIndex = inValidFormIndex;
                }
                let $errorField = $('.detailForm')
                    .eq(inValidFormIndex)
                    .find('.field.error')
                    .eq(0);
                $errorField.focus();
                $('html,body').animate(
                    {
                        scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                    },
                    200
                );

                return false;
            }
            return jQuery('.mainform').form('is valid');
        };

        /**
         * validFields mainForm
         */
        $scope.validFields = function() {
            if (arguments.length == 0) return;
            let isValid = true;
            for (let i = 0; i < arguments.length; i++) {
                if (!jQuery('.mainform').form('validate field', arguments[i])) {
                    isValid = false;
                }
            }

            return isValid;
        };

        /**
         * validDetailFields detailForm
         */
        $scope.validDetailFields = function() {
            if (arguments.length == 0) return;
            let isValid = true;
            for (let i = 0; i < arguments.length; i++) {
                if (
                    !jQuery('.detailForm')
                        .eq($scope.tabIndex)
                        .form('validate field', arguments[i])
                ) {
                    isValid = false;
                }
            }

            return isValid;
        };

        /**
         * ユーザー検索処理
         * @param type
         */
        $scope.showUserSelectModal = function(type) {
            $scope.userSelectType = type;
            // 担当者検索の場合
            if (type == '1') {
                $scope.showUserSelect = true;
            } else {
                if ($scope.contract.details[$scope.tabIndex].contractType == '1') {
                    $scope.showUserSelect = true;
                } else {
                    $scope.contract.details[$scope.tabIndex].empleNm = ''; // 品名（技術者名）
                    $scope.contract.details[$scope.tabIndex].empleId = ''; // 技術者ID
                }
            }
        };

        /**
         * user modal confirm
         */
        $scope.userConfirm = function(data) {
            // 担当者検索の場合
            if ($scope.userSelectType == '1') {
                $scope.contract.picDepartId = data.department; // 担当者部門ID
                $scope.contract.picNm = data.userNm; // 担当者名前
                $scope.contract.picEmail = data.email; // 担当者メールアドレス
                $timeout(function() {
                    $scope.validFields('picDepartNm', 'picNm', 'picEmail');
                }, 10);
            } else {
                if ($scope.contract.details[$scope.tabIndex].contractType == '1') {
                    $scope.contract.details[$scope.tabIndex].empleNm = data.userNm; // 品名（技術者名）
                    $scope.contract.details[$scope.tabIndex].empleId = data.empleId; // 技術者ID
                } else {
                    $scope.contract.details[$scope.tabIndex].empleNm = ''; // 品名（技術者名）
                    $scope.contract.details[$scope.tabIndex].empleId = ''; // 技術者ID
                }
                $timeout(function() {
                    $scope.validDetailFields('empleNm');
                }, 10);
            }
        };

        /**
         * userCancel
         */
        $scope.userCancel = function() {
            // 契約区分の場合
            if ($scope.userSelectType == '2') {
                $scope.contract.details[$scope.tabIndex].contractType = '2'; // 契約区分
                $scope.contract.details[$scope.tabIndex].empleId = ''; // 技術者ID
            }
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                swal({
                    text: '登録してよろしいですか。',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(
                    function(isConfirm) {
                        if (isConfirm) {
                            $api.post('/osd01/c/item', $scope.contract, function(res) {
                                if (res.success) {
                                    message.showSuccess('success');
                                } else {
                                    message.showError(res.data.message);
                                    // show error details
                                    let errDetails = res.data.details;
                                    if (errDetails) {
                                        for (let i = 0; i < errDetails.length; i++) {
                                            jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                                        }
                                    }
                                }
                            });
                        }
                    },
                    function(dismiss) {
                        // 処理なし
                    }
                );
            }
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            // detail form check
            $scope.detailFormCheck(0);
            // main form check
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 契約先会社
                    contractorCompId: {
                        identifier: 'contractorCompId',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5022', '契約先会社'),
                            },
                        ],
                    },
                    // 契約月
                    contractYm: {
                        identifier: 'contractYm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '契約月'),
                            },
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '契約月'),
                            },
                        ],
                    },
                    // 担当者部門
                    picDepartNm: {
                        identifier: 'picDepartNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5022', '担当者部門'),
                            },
                        ],
                    },
                    // 担当者名前
                    picNm: {
                        identifier: 'picNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5022', '担当者名前'),
                            },
                        ],
                    },
                    // 担当者メールアドレス
                    picEmail: {
                        identifier: 'picEmail',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5022', 'メールアドレス'),
                            },
                        ],
                    },
                    // 支払期限
                    payDeadlineMonthFlg: {
                        identifier: 'payDeadlineMonthFlg',
                        depends: 'payDeadlineDay',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支払期限'),
                            },
                        ],
                    },
                    // 支払日数
                    payDeadlineDay: {
                        identifier: 'payDeadlineDay',
                        optional: true,
                        rules: [
                            {
                                type: 'greaterThan[1]',
                                prompt: message.getMsgById('E_XX_FW_5024', '支払日数', 1),
                            },
                            {
                                type: 'lessThan[31]',
                                prompt: message.getMsgById('E_XX_FW_5017', '支払日数', 31),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };

        /**
         * detailFormCheck
         */
        $scope.detailFormCheck = function(index) {
            // hoursInMonth
            /*let hoursInMonth = moment().daysInMonth() * 24;*/
            let hoursInMonth = 744;

            jQuery('.detailForm')
                .eq(index)
                .form({
                    on: 'blur',
                    inline: true,
                    keyboardShortcuts: false,
                    fields: {
                        // 所属
                        contractType: {
                            identifier: 'contractType',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5022', '所属'),
                                },
                            ],
                        },
                        // 技術者名
                        empleNm: {
                            identifier: 'empleNm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '技術者名'),
                                },
                            ],
                        },
                        // 契約開始日
                        contractDate: {
                            identifier: 'contractDate',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '契約開始日'),
                                },
                                {
                                    type: 'date[YYYY-MM-DD]',
                                    prompt: message.getMsgById('E_XX_FW_5012', '契約開始日'),
                                },
                            ],
                        },
                        // 契約終了予定日
                        contractScheEndDate: {
                            identifier: 'contractScheEndDate',
                            optional: true,
                            rules: [
                                {
                                    type: 'date[YYYY-MM-DD]',
                                    prompt: message.getMsgById('E_XX_FW_5012', '契約終了予定日'),
                                },
                                {
                                    type: 'greaterThan[contractDate]',
                                    prompt: message.getMsgById('E_XX_FW_5024', '契約終了予定日', '契約開始日'),
                                },
                            ],
                        },
                        // 単価
                        price: {
                            identifier: 'price',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '単価'),
                                },
                            ],
                        },
                        // 基準時間(from)
                        baseTimeStart: {
                            identifier: 'baseTimeStart',
                            optional: true,
                            rules: [
                                {
                                    type: 'lessThan[' + hoursInMonth + ']',
                                    prompt: message.getMsgById('E_XX_FW_5017', '基準時間(from)', hoursInMonth),
                                },
                            ],
                        },
                        // 基準時間(to)
                        baseTimeEnd: {
                            identifier: 'baseTimeEnd',
                            optional: true,
                            rules: [
                                {
                                    type: 'greaterThan[baseTimeStart]',
                                    prompt: message.getMsgById('E_XX_FW_5023', '基準時間(from)より大きい値'),
                                },
                                {
                                    type: 'lessThan[' + hoursInMonth + ']',
                                    prompt: message.getMsgById('E_XX_FW_5017', '基準時間(to)', hoursInMonth),
                                },
                            ],
                        },
                    },
                    onFailure: function() {
                        $scope.detailInValidList.push(index);
                    },
                });
        };
    });

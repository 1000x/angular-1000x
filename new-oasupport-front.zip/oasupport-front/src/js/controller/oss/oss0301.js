const swal = require('sweetalert2');
/**
 * 給与調整一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('ossoss0301Ctrl', function($scope, $timeout, $api, commonService, message) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 給与情報一覧の取得処理
            $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };
        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                salaryYyyymm: '', // 検索用年月
            };

            $scope.searchText = ''; // データ絞り込み用
            $scope.datatable = {};
            $scope.departmentList = {}; //部門リスト
            $scope.adjustList = [];
        };

        /**
         * 給与調整一覧の取得処理
         */
        $scope.searchList = function() {
            $api.post('/oss03/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.adjustList = [];

                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');

                    for (let i = 0; i < data.adjustList.length; i++) {
                        let info = data.adjustList[i];
                        $scope.adjustList.push(info);
                    }
                } else {
                    $scope.adjustList = [];
                }
            });
        };

        /**
         * 社員名の取得
         */
        $scope.getName = function(empleInfo) {
            let uName;
            // 姓名
            if (empleInfo.lastNmKanji || empleInfo.fristNmKanji) {
                uName = jQuery.trim(empleInfo.lastNmKanji + ' ' + empleInfo.fristNmKanji);
            } else {
                uName = jQuery.trim(empleInfo.lastNmKana + ' ' + empleInfo.fristNmKana);
            }
            return uName;
        };

        /**
         * 給与削除処理
         */
        $scope.adjustDel = function(info) {
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.get('/oss03/d/item/' + info.rowsId, function(res) {
                            if (res.success) {
                                message.showSuccess('削除しました。');
                                // 給与情報一覧の取得処理
                                $scope.searchList();
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.searchForm').form('validate form');
            return jQuery('.searchForm').form('is valid');
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [0],
                        order: [],
                        displayLength: 20,
                    },
                ],
            };
        };
    });

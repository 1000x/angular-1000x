const angular = require('angular');
const swal = require('sweetalert2');
/**
 * api
 */
module.exports = angular.module('app.api', []).factory('$api', [
    '$http',
    '$session',
    'message',
    'CONFIG',
    '$location',
    '$timeout',
    'CONST',
    function($http, $session, message, CONFIG, $location, $timeout, CONST) {
        let show_loader, hide_loader, getResource, postResource, groupBy, b64toBlob, toNumeric, convertBase64ToBlob, execTasks;

        show_loader = function() {
            $('.page-spinner-bar').remove();
            const Img = new Image();
            Img.src = require('@/images/z99/spinner.gif');
            $('<div class="page-spinner-bar"></div>').append(Img).appendTo('body');
        };

        hide_loader = function() {
            $('.page-spinner-bar').remove();
        };

        /**
         * システム使用前のチェック
         */
        function permissionCheck() {
            return new Promise(function(resolve, reject) {
                // 除外マッピング
                var isExclude = $location.path().indexOf('/omt') == 0 || $location.path().indexOf('/msa') == 0 || $location.path().indexOf('/osa0101') == 0 || $location.path().indexOf('/osa0201') == 0;
                if (window.localStorage.getItem(CONST.PERMISSION_KEY)) {
                    resolve();
                } else if (isExclude) {
                    resolve();
                } else {
                    call_web_api('GET', '/permission', null, function(res) {
                        if (res.success) {
                            var permissionId = res.data.permissionId;
                            if (permissionId) {
                                var messageText, confirmButtonText, path;
                                if (permissionId == '1') {
                                    messageText = '会社情報は見つかりません。';
                                    confirmButtonText = '会社情報を設定する';
                                    path = 'omt0101';
                                } else if (permissionId == '2') {
                                    messageText = '会社銀行口座情報は見つかりません。';
                                    confirmButtonText = '銀行口座を設定する';
                                    path = 'omt0201';
                                } else if (permissionId == '3') {
                                    messageText = '会社送信メール情報は見つかりません。';
                                    confirmButtonText = '送信メールを設定する';
                                    path = 'omt0301';
                                } else {
                                    messageText = '部門情報は見つかりません。';
                                    confirmButtonText = '部門情報を設定する';
                                    path = 'omt0401';
                                }
                                swal({
                                    text: messageText,
                                    type: 'warning',
                                    confirmButtonText: confirmButtonText,
                                    allowOutsideClick: false,
                                }).then(function(isConfirm) {
                                    $timeout(function() {
                                        $location.path(path);
                                    });
                                });
                            } else {
                                window.localStorage.removeItem(CONST.PERMISSION_KEY);
                                window.localStorage.setItem(CONST.PERMISSION_KEY, 'true');
                                resolve();
                            }
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        }

        /**
         * call_web_api
         * @param method
         * @param url
         * @param data
         * @param callback
         * @param showLoader
         */
        function call_web_api(method, url, data, callback, showLoader) {
            if (showLoader !== false) show_loader();

            var api_base = CONFIG.API_BASE;

            var confHeaders;

            if (method == 'GET') {
                confHeaders = {
                    Authorization: 'Bearer ' + $session.getToken(),
                    'Cache-Control': 'private, no-store, no-cache, must-revalidate',
                    Pragma: 'no-cache',
                    Expires: 0,
                };
            } else {
                confHeaders = { Authorization: 'Bearer ' + $session.getToken() };
            }

            var conf = {
                method: method,
                url: api_base + url,
                timeout: 0,
                headers: confHeaders,
                data: data || {},
            };

            return $http(conf).then(
                function success(res) {
                    if (showLoader !== false) hide_loader();
                    callback({
                        success: res.data.success ? res.data.success : true,
                        data: res.data,
                    });
                },
                function error(res) {
                    if (showLoader !== false) hide_loader();
                    // チェック失敗の場合
                    if (res.status == '400' || res.status == '404' || res.status == '409') {
                        callback({
                            success: false,
                            status: res.status,
                            data: res.data,
                        });
                    } else if (res.status == '401') {
                        $session.destroy();
                        $timeout(function() {
                            message.showError('権限認証が失敗しました。もう一度ログインください。');
                            return $location.path('/osa0101');
                        });
                    } else if (res.status == '403') {
                        message.showError('権限認証が失敗しました。');
                    } else if (res.status == '500') {
                        message.showError(message.getMsgById('E_XX_FW_9001'));
                    } else {
                        message.showError('サーバーへ接続が失敗しました。');
                    }
                }
            );
        }

        /**
         * get
         */
        getResource = function(url, callback, showLoader) {
            permissionCheck().then(function() {
                return call_web_api('GET', url, null, callback, showLoader);
            });
        };

        /**
         * post
         */
        postResource = function(url, data, callback, showLoader) {
            permissionCheck().then(function() {
                return call_web_api('POST', url, data, callback, showLoader);
            });
        };

        /**
         * groupBy
         */
        groupBy = function(array) {
            var group = {};
            for (var id in array) {
                var groupkey = '';
                for (var i = 1; i < arguments.length; i++) {
                    groupkey = groupkey + '##' + getValueByMultikey(array[id], arguments[i]);
                }
                if (is_empty(group[groupkey])) {
                    group[groupkey] = {};
                    for (i = 0; i < Object.keys(array[id]).length; i++) {
                        group[groupkey][Object.keys(array[id])[i]] = array[id][Object.keys(array[id])[i]];
                    }
                    group[groupkey].key = groupkey;
                    group[groupkey].list = [array[id]];
                } else {
                    group[groupkey].list.push(array[id]);
                }
            }
        };

        /**
         * base64 to blob
         * @param b64Data
         * @param contentType
         * @param sliceSize
         * @returns {Blob}
         */
        b64toBlob = function(base64Str, mimeType) {
            // Blobを作成
            try {
                var bin = atob(base64Str.replace(/^.*,/, ''));
                var buffer = new Uint8Array(bin.length);
                for (var i = 0; i < bin.length; i++) {
                    buffer[i] = bin.charCodeAt(i);
                }
                return new Blob([buffer.buffer], { type: mimeType });
            } catch (e) {
                return false;
            }
        };

        /**
         * base64 to blob
         * @param b64Data
         * @param contentType
         * @param sliceSize
         * @returns {Blob}
         */
        convertBase64ToBlob = function(base64Str, mimeType) {
            // Blobを作成
            try {
                var bin = atob(base64Str.replace(/^.*,/, ''));
                var buffer = new Uint8Array(bin.length);
                for (var i = 0; i < bin.length; i++) {
                    buffer[i] = bin.charCodeAt(i);
                }
                return new Blob([buffer.buffer], { type: mimeType });
            } catch (e) {
                return false;
            }
        };

        /**
         * string to numeric
         */
        toNumeric = function(str) {
            return Number(str) || 0;
        };

        /**
         * タスクの同期化実行
         */
        execTasks = function(tasks, onSuccess, onFail) {
            if (!tasks || !Array.isArray(tasks)) return;

            var queueName = '__EXECUTE_TASKS__';
            var result = [];
            var execCnt = 0;

            var next = function(isSuccess, data) {
                if (isSuccess === false) {
                    $(document).clearQueue(queueName);
                    if (onFail) return onFail(data);
                } else {
                    result.push(data);
                    if (execCnt == tasks.length) {
                        $(document).clearQueue(queueName);
                        if (onSuccess) return onSuccess(result);
                    } else {
                        $(document).dequeue(queueName);
                    }
                }
            };
            tasks.forEach(function(task) {
                $(document).queue(queueName, function() {
                    task.call(this, next);
                    execCnt++;
                });
            });
            $(document).dequeue(queueName);
        };

        return {
            show_loader: show_loader,
            hide_loader: hide_loader,
            get: getResource,
            post: postResource,
            groupBy: groupBy,
            b64toBlob: b64toBlob,
            toNumeric: toNumeric,
            convertBase64ToBlob: convertBase64ToBlob,
            execTasks: execTasks,
        };
    },
]);
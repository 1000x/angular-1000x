module.exports = env => {
    const isProduction = env === 'production';

    if (isProduction) {
        console.log('mode: production');
        return require('./build/prod.config');
    } else {
        console.log('mode: develop');
        return require('./build/dev.config');
    }
};
const angular = require('angular');
const swal = require('sweetalert2');
const storage = require('./storage');

/**
 * app.auth
 * @auth wang.qt
 */
module.exports = angular
    .module('app.auth', [])
    .service('$session', function(CONST) {
        /**
         * getToken
         */
        this.getToken = function() {
            return storage.getItem(CONST.TOKEN_KEY) || '';
        };

        /**
         * get resresh token
         */
        this.getRefreshToken = function() {
            return storage.getItem(CONST.REFRESH_TOKEN_KEY) || '';
        };

        /**
         * token create
         */
        this.createToken = function(data) {
            storage.setItem(CONST.TOKEN_KEY, data.access_token || '', 1000 * data.expires_in);
            storage.setItem(CONST.REFRESH_TOKEN_KEY, data.refresh_token || '', 1000 * 60 * 60 * 24 * 30);
        };

        /**
         * createUser
         */
        this.createUser = function(authentication, rememberPass) {
            this.COMP_NM = authentication.compNm;
            this.USR_ID = authentication.usrId;
            this.USR_NM = authentication.usrNm;
            this.ONE_TIME_CODE_ST = authentication.oneTimeCodeSt;
            this.AUTHORITY_LIST = {};
            for (let i = 0; i < authentication.authorityList.length; i++) {
                let authInfo = authentication.authorityList[i];
                this.AUTHORITY_LIST[authInfo.funcId] = authInfo.authority;
            }

            // login COMP_ID, USR_ID
            localStorage.removeItem(CONST.LOGIN_USER_KEY);
            localStorage.setItem(
                CONST.LOGIN_USER_KEY,
                JSON.stringify({
                    USR_ID: authentication.usrId,
                })
            );
            this.AUTHORITIED = true;
        };

        /**
         * session init
         */
        this.init = function() {
            let loginUser = JSON.parse(localStorage.getItem(CONST.LOGIN_USER_KEY));
            if (loginUser) {
                this.USR_ID = loginUser.USR_ID;
            } else {
                this.USR_ID = null;
            }
            this.AUTHORITIED = false;
        };

        /**
         * session destroy
         */
        this.destroy = function() {
            this.init();
            try {
                Set_Cookie(CONST.TOKEN_KEY, '');
                Set_Cookie(CONST.REFRESH_TOKEN_KEY, '');
            } catch (_error) {
                // 処理なし
            }
        };

        this.init();

        return this;
    })
    .factory('$auth', function($rootScope, $api, $location, $session, $timeout, CONST, $route, $http, message, CONFIG, $q) {
        /**
         * 自動ログイン
         * @param nextState
         */
        let autoLogin = function(event) {
            if (event) {
                event.preventDefault();
            }
            let token = $session.getToken();
            // try to refresh token
            if (!token) {
                let refreshToken = $session.getRefreshToken();
                // refreshTokenが存在していない場合
                if (!refreshToken) {
                    return $location.path('/osa0101');
                }

                console.log('try to refresh token');
                // do refresh token
                let data = {
                    grant_type: 'refresh_token',
                    refresh_token: refreshToken,
                    client_id: CONST.CLIENT_ID,
                    client_secret: CONST.CLIENT_SECRET,
                };
                let url = CONFIG.AUTH_BASE + '/oauth/token?' + $.param(data);
                $api.show_loader();
                $http({
                    method: 'POST',
                    url: url,
                }).then(
                    function success(res) {
                        $session.createToken(res.data);
                        // user infoの取得
                        $api.get('/userinfo', function(res1) {
                            $session.createUser(res1.data);
                            $rootScope.$broadcast('refresh_user');
                            $rootScope.$broadcast('reload_session');
                            return $route.reload();
                        });
                    },
                    function error(res) {
                        $api.hide_loader();
                        $timeout(function() {
                            message.showError('認証が失敗しました。');
                            return $location.path('/osa0101');
                        });
                    }
                );
            } else {
                console.log('try to reload');
                // user infoの取得
                $api.get('/userinfo', function(res1) {
                    $session.createUser(res1.data);
                    $rootScope.$broadcast('refresh_user');
                    $rootScope.$broadcast('reload_session');
                    return $route.reload();
                });
            }
        };

        /**
         * ログイン前、ユーザー認証状態情報取得
         * @param username
         * @param password
         * @param rememberPass
         */
        let checkAuthority = function(username, password) {
            let data = {
                username: username,
                password: password,
            };
            let url = CONFIG.AUTH_BASE + '/login/authority?' + $.param(data);

            let deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
            }).then(
                function success(res) {
                    deferred.resolve(res.data);
                },
                function error(res) {
                    deferred.reject('認証処理に失敗しました。');
                    // message.showError("認証処理に失敗しました。");
                }
            );

            return deferred.promise;
        };

        /**
         * 二段階認証設定ーQRCode取得
         * @param username
         * @param password
         * @param rememberPass
         */
        let generateQRCode = function(username, password) {
            let data = {
                username: username,
                password: password,
            };
            let url = CONFIG.AUTH_BASE + '/account/security/qrcode/accessUrl?' + $.param(data);

            let deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
            }).then(
                function success(res) {
                    let result = {};
                    result.username = res.data.username;
                    result.email = res.data.email;
                    result.accessUrl = res.data.accessUrl;
                    result.secretKey = res.data.secretKey;
                    deferred.resolve(result);
                },
                function error(res) {
                    deferred.reject();
                    message.showError('二段階認証プロセスが失敗しました。');
                }
            );
            return deferred.promise;
        };

        /**
         * 二段階認証設定ー設定登録
         * @param username
         * @param password
         * @param rememberPass
         */
        let registePassword = function(username, password, secretKey, totpKey) {
            let data = {
                username: username,
                password: password,
                secretKey: secretKey,
                totpKey: totpKey,
            };
            let url = CONFIG.AUTH_BASE + '/account/security/password/registation?' + $.param(data);

            let deferred = $q.defer();

            $api.show_loader();
            $http({
                method: 'POST',
                url: url,
            }).then(
                function success(res) {
                    let result = {};
                    result.backupCode = res.data;
                    deferred.resolve(result);
                    $api.hide_loader();
                },
                function error(res) {
                    deferred.reject('認証コードが間違っています、もう一度お試しください。');
                    $api.hide_loader();
                    // message.showError("二段階認証プロセスが失敗しました。");
                }
            );
            return deferred.promise;
        };

        /**
         * 二段階認証設定ー認証取消
         * @param username
         * @param password
         * @param rememberPass
         */
        let releasePassword = function(username, password) {
            let data = {
                username: username,
                password: password,
            };
            let url = CONFIG.AUTH_BASE + '/account/security/password/release?' + $.param(data);

            let deferred = $q.defer();
            $api.show_loader();
            $http({
                method: 'POST',
                url: url,
            }).then(
                function success(res) {
                    $api.hide_loader();
                    deferred.resolve();
                },
                function error(res) {
                    deferred.reject('二段階認証プロセスが失敗しました。');
                    $api.hide_loader();
                }
            );
            return deferred.promise;
        };

        /**
         * ログイン
         * @param username
         * @param password
         * @param rememberPass
         */
        let login = function(username, password, totp_key, backup_key) {
            let data = {
                username: username,
                password: password,
                totp_key: totp_key,
                backup_key: backup_key,
                grant_type: 'password',
                client_id: username,
                client_secret: password,
                // client_id: CONST.CLIENT_ID,
                // client_secret: CONST.CLIENT_SECRET
            };
            let url = CONFIG.AUTH_BASE + '/oauth/token?' + $.param(data);

            $api.show_loader();
            $http({
                method: 'POST',
                url: url,
            }).then(
                function success(res) {
                    $session.createToken(res.data);
                    // user infoの取得
                    $api.get('/userinfo', function(res1) {
                        $session.createUser(res1.data);
                        $rootScope.$broadcast('refresh_user');
                        $location.path('/');
                    });
                },
                function error(res) {
                    $api.hide_loader();
                    message.showError('認証が失敗しました。');
                }
            );
        };

        /**
         * ログアウト
         */
        let logout = function() {
            swal({
                text: 'ログアウトよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    $session.destroy();
                    $timeout(function() {
                        $location.path('/osa0101');
                    });
                }
            }).catch(function() {
                // 処理なし
            });
        };

        /**
         * 画面の権限チェック
         */
        let isAuthorized = function() {
            return $session.AUTHORITIED;
        };

        /**
         * isAuthValid
         * @param url
         * @param pageRoles array
         */
        let isAuthValid = function(url, pageRoles) {
            let isValid = true;
            for (let key in $session.AUTHORITY_LIST) {
                if (url.indexOf('/' + key) == 0) {
                    isValid = jQuery.inArray($session.AUTHORITY_LIST[key], pageRoles) >= 0;
                    break;
                }
            }
            return isValid;
        };

        return {
            autoLogin: autoLogin,
            checkAuthority: checkAuthority,
            generateQRCode: generateQRCode,
            registePassword: registePassword,
            releasePassword: releasePassword,
            login: login,
            logout: logout,
            isAuthorized: isAuthorized,
            isAuthValid: isAuthValid,
        };
    });

/**
 * tools
 */
module.exports = app => app.controller('z99toolsCtrl', function($scope, $rootScope, $location, $routeParams, $api, message, CONST) {
    
});

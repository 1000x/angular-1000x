const angular = require('angular');
/**
 * app.filters
 */
module.exports = angular.module('app.filters', []).filter('percent', function() {
    return function(input) {
        if (input === null || input === undefined || input === '') {
            return '';
        }
        input = input + '';
        if (!/\d+/.test(input)) {
            return '';
        }
        return (Number(input) / 100).toFixed(2) + '%';
    };
});

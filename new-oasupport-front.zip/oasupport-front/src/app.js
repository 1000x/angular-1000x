// style
require('./plugins/semantic/semantic.css');
require('datatables.net-se/css/dataTables.semanticui.css');
require('sweetalert2/dist/sweetalert2.min.css');
require('ngdropzone/dist/ng-dropzone.css');
require('./css/common.css');
require('./css/main.css');

// node plugins
require('jquery');
require('jquery.marquee');
require('numeral');
require('datatables.net');
require('datatables.net-se');
require('dropzone');
const moment = require('moment');
require('moment-timezone');
// set default timezone
moment.tz.setDefault('Asia/Tokyo');

// local plugins
require('./plugins/semantic/semantic');

// angular modules
const angular = require('angular');
require('angular-route');
require('angular-animate');
require('angular-cookies');
require('angular-touch');
require('angular-sanitize');
require('angular-filter');
require('angular-datatables');
require('ngdropzone');

require('./js/config');
require('./js/utils/const');
require('./js/utils/api');
require('./js/utils/filter');
require('./js/utils/directives');
require('./js/widget/customLabels');
require('./js/utils/message');
require('./js/utils/auth');

const app = angular.module('app', [
    'ngRoute',
    'ngAnimate',
    'ngCookies',
    'ngTouch',
    'ngSanitize',
    'datatables',
    'thatisuday.dropzone',

    // common
    'app.config',
    'app.consts',
    'app.api',
    'app.filters',
    'app.directives',
    'app.customLabels',
    'app.message',
    'app.auth'

])
.directive('app', () => {
    return {
        replace : 'true',
        template: require('./app.html')
    }
})
.controller('appCtrl', function($scope, $location) {

    /**
     * menuの表示／非表示·
     */
    $scope.showMenu = () => $location.path() != "/osa0101" && $location.path() != "/error";

});

require('./js/utils/route')(app);
require('./js/service')(app);
require('./js/controller')(app);


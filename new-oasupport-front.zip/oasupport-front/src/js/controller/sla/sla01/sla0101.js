const swal = require('sweetalert2');
/**
 * 履歴書一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('slasla0101Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 履歴書一覧の取得処理
            $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();
        };

        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                operationStatus: '', // 検索用稼働状況
            };
            $scope.searchText = ''; // データ絞り込み用
            $scope.datatable = {};
            $scope.resumeList = [];

            // select list
            $scope.operationStatusList = CONST.OPERATION_STATUS_LIST; // 稼働状況
            $scope.affiliationList = CONST.AFFILIATION_LIST; // 所属
            $scope.openStatusList = CONST.OPEN_STATUS_LIST; // 公開状況
        };

        /**
         * 履歴書一覧の取得処理
         */
        $scope.searchList = function() {
            $api.post('/sla01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.resumeList = [];

                    for (let i = 0; i < data.resumeList.length; i++) {
                        let info = data.resumeList[i];
                        $scope.resumeList.push(info);
                    }

                    // dropdown and select trigger
                    $timeout(function() {
                        $('.btn-setting').dropdown({
                            on: 'hover',
                            duration: '100',
                        });
                    });
                } else {
                    $scope.resumeList = [];
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [7],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * dtInstanceCallback table
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み(Search)
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * 履歴書download処理
         */
        $scope.downloadResume = function(resumeInfo) {
            $param = {};
            $api.post('/sla01/download/item/' + resumeInfo.compId + '/' + resumeInfo.skillSheetFile.split('.'), $param, function(res) {
                if (res.success) {
                    let fileName = res.data.fileName;
                    let mimeType;
                    if (/.xlsx/.test(fileName)) {
                        mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                    } else if (/.xls/.test(fileName)) {
                        mimeType = 'application/vnd.ms-excel';
                    } else if (/.pdf$/.test(fileName)) {
                        mimeType = 'application/pdf';
                    } else {
                        message.showError('許可されていないファイル拡張子をダウンロードできません。');
                    }

                    let blob = $api.b64toBlob(res.data.fileBase64String, mimeType);

                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, fileName);
                    } else {
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = URL.createObjectURL(blob);
                        a.download = fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };

        /**
         * 履歴書削除処理
         */
        $scope.resumeDel = function(resumeInfo) {
            let $url = '/sla01/d/item/' + resumeInfo.rowsId;

            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    $api.get($url, function(res) {
                        if (res.success) {
                            message.showSuccess('削除しました。');
                            // 履歴書一覧の取得処理
                            $scope.searchList();
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        };
    });

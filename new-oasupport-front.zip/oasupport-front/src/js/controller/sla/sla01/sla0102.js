const Dropzone = require('dropzone');
const swal = require('sweetalert2');
/**
 * 履歴書登録·画面コントローラ
 */
module.exports = app =>
    app.controller('slasla0102Ctrl', function($scope, $timeout, $api, message, CONST, CONFIG, $session) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // 履歴書
            $scope.resume = {
                operationStatus: '1', // 稼働状況「稼働空きます」
                nationality: '1', // 国籍「日本籍」
                parallelFlg: '2', // 並行有無「無」
            };

            // select list
            $scope.sexList = CONST.SEX_LIST; // 性別リスト
            $scope.affiliationList = CONST.AFFILIATION_LIST; // 所属リスト
            $scope.operationStatusList = CONST.OPERATION_STATUS_LIST; // 稼働状況リスト
            $scope.nationalityList = CONST.NATIONALITY_LIST; // 国籍リスト
            $scope.parallelFlgList = CONST.PARALLEL_FLG_LIST; // 並行有無リスト

            // user modal
            $scope.showUserSelect = false;

            // dropzone初期化
            $scope.initDropzone();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.mainform').form('validate form');
        };

        /**
         * ユーザー検索処理
         */
        $scope.showUserSelectModal = function() {
            // 自社員の場合
            if ($scope.resume.affiliation == '1') {
                $scope.showUserSelect = true;
            } else {
                $scope.resume.empleName = ''; // 氏名
                $scope.resume.empleId = ''; // 社員ID
            }
        };

        /**
         * user modal confirm
         */
        $scope.userConfirm = function(data) {
            // 自社員の場合
            if ($scope.resume.affiliation == '1') {
                $scope.resume.empleName = data.userNm; // 氏名
                $scope.resume.empleId = data.empleId; // 社員ID
            } else {
                $scope.resume.empleName = ''; // 氏名
                $scope.resume.empleId = ''; // 社員ID
            }
        };

        /**
         * userCancel
         */
        $scope.userCancel = function() {
            $scope.resume.affiliation = ''; // 所属
            $scope.resume.empleName = ''; // 氏名
            $scope.resume.empleId = ''; // 社員ID
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/sla01/c/item', $scope.resume, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * dropzone初期化
         */
        $scope.initDropzone = function() {
            $scope.dzOptions = {
                url: CONFIG.API_BASE + '/sla01/upload',
                paramName: 'file',
                maxFiles: '1',
                maxFilesize: '2',
                parallelUploads: 1,
                thumbnailWidth: 100,
                thumbnailHeight: 100,
                dictInvalidFileType: 'Word/Excel/Pdfだけ、アップロードできます。',
                dictFileTooBig: 'ファイルの最大サイズは2M。',
                autoProcessQueue: true,
                uploadMultiple: false,
                acceptedFiles: '.pdf,.doc,.docs,.xls,.xlsx',
                headers: {
                    Authorization: 'Bearer ' + $session.getToken(),
                    //'Content-Type': 'multipart/form-data',
                },
            };
            $scope.dzCallbacks = {
                addedfile: function(file) {
                    let removeButton = Dropzone.createElement('<i class="remove circle outline icon dz-remove"></i>');
                    removeButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (!file.accepted) {
                            $scope.dzMethods.removeFile(file);
                            return;
                        }
                        swal({
                            text: '削除してよろしいですか。',
                            type: 'warning',
                            showCancelButton: true,
                            cancelButtonColor: '#d33',
                        }).then(function(isConfirm) {
                            if (isConfirm) {
                                $scope.dzMethods.removeFile(file);
                            }
                        });
                    });
                    // Add the button to the file preview element.
                    file.previewElement.appendChild(removeButton);
                },
                error: function(file, res) {
                    $scope.dzMethods.removeFile(file);
                    message.showError(res.message);
                },
                success: function(file, res) {
                    let resume = res.resume;
                    // 履歴書ID
                    $scope.resume.resumeId = resume.resumeId;
                    $scope.resume.skillSheetFile = resume.skillSheetFile;
                },
                maxfilesexceeded: function(file) {
                    $scope.dzMethods.removeFile(file);
                },
                /*'sending': function(file, xhr, formData) {
                  // イニシャル氏名
                  formData.append("empleInitialName", $scope.resume.empleInitialName);
                  // 最寄駅
                  formData.append("station", $scope.resume.station);
              }*/
            };
            $scope.dzMethods = {};
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 履歴書ID
                    resumeId: {
                        identifier: 'resumeId',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5029', '履歴書ID'),
                            },
                        ],
                    },
                    // 参画時期
                    participateTime: {
                        identifier: 'participateTime',
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', '参画時期'),
                            },
                        ],
                    },
                    // 所属
                    affiliation: {
                        identifier: 'affiliation',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '所属'),
                            },
                        ],
                    },
                    // 性別
                    sex: {
                        identifier: 'sex',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '性別'),
                            },
                        ],
                    },
                    // イニシャル氏名
                    empleInitialName: {
                        identifier: 'empleInitialName',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'イニシャル氏名'),
                            },
                        ],
                    },
                    // 年齢
                    age: {
                        identifier: 'age',
                        optional: true,
                        rules: [
                            {
                                type: 'integer',
                                prompt: message.getMsgById('E_XX_FW_5004', '年齢'),
                            },
                        ],
                    },
                    // 希望月額単価
                    monthPrice: {
                        identifier: 'monthPrice',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '希望月額単価'),
                            },
                        ],
                    },
                    // 並行営業状態（面接予定）件数
                    interviewPlanNums: {
                        identifier: 'interviewPlanNums',
                        optional: true,
                        rules: [
                            {
                                type: 'integer',
                                prompt: message.getMsgById('E_XX_FW_5004', '並行営業状態（面接予定）件数'),
                            },
                        ],
                    },
                    //並行営業状態（結果待ち）件数
                    interviewResultPlanNums: {
                        identifier: 'interviewResultPlanNums',
                        optional: true,
                        rules: [
                            {
                                type: 'number',
                                prompt: message.getMsgById('E_XX_FW_5004', '並行営業状態（結果待ち）件数'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

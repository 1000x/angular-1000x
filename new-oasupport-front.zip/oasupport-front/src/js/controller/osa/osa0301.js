const swal = require('sweetalert2');
/**
 * アカウント一覧画面コントローラ
 */
module.exports = app =>
    app.controller('osaosa0301Ctrl', function($scope, $api, message, CONST, commonService) {
        /**
         * 画面初期化
         */
        $scope.init = function() {
            $scope.datatable = {};

            // 加盟企業一覧の取得処理
            $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();

            // select list
            $scope.userStatusList = CONST.USER_STATUS_LIST;
        };

        /**
         * アカウント一覧の取得処理
         */
        $scope.searchList = function() {
            $api.get('/osa03/r/list', function(res) {
                if (res.success) {
                    $scope.accountList = [];
                    let accountList = res.data.accountList;
                    for (let i = 0; i < accountList.length; i++) {
                        $scope.accountList.push(accountList[i]);
                    }
                } else {
                    $scope.accountList = [];
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [0, 7],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * dtInstanceCallback
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * doSearch
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * ユーザー状態の更新
         * @param account
         * @param newUsrSt
         */
        $scope.updateUsrSt = function(account, newUsrSt) {
            $api.get('/osa03/u/item/' + account.rowsId + '/' + newUsrSt, function(res) {
                if (res.success) {
                    message.showSuccess('success');
                    account.usrSt = newUsrSt;
                } else {
                    message.showError(res.data.message);
                }
            });
        };

        /**
         * アカウントの削除処理
         */
        $scope.remove = function(rowsId, index) {
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.get('/osa03/d/item/' + rowsId, function(res) {
                            if (res.success) {
                                message.showSuccess('success');
                                $scope.accountList.splice(index, 1);
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };
    });

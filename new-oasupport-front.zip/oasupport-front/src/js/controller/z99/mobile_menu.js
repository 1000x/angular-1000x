/**
 * mobile menu コントローラ
 */
module.exports = app =>
    app.controller('z99mobilemenuCtrl', function($scope, $rootScope, $location, $session, $auth, $timeout, $api) {
        $scope.compNm = $session.COMP_NM;
        $scope.authorityList = $session.AUTHORITY_LIST;

        /**
         * logout
         */
        $scope.logout = function() {
            $auth.logout();
        };

        /**
         * refresh user
         */
        $rootScope.$on('refresh_user', function() {
            $scope.compNm = $session.COMP_NM;
            $scope.authorityList = $session.AUTHORITY_LIST;
        });

        /**
         * menu/item active
         */
        $scope.isActive = function(str) {
            return $location.path().indexOf(str) == 0;
        };

        /**
         * path
         */
        $scope.path = function(newPath) {
            if ($scope.isActive(newPath)) {
                $('.ui.sidebar.small-screen').sidebar('hide');
            } else {
                $api.show_loader();
                $('.ui.sidebar.small-screen')
                    .sidebar('setting', {
                        onHidden: function() {
                            $timeout(function() {
                                $location.path(newPath);
                            });
                        },
                    })
                    .sidebar('hide');
            }
        };
    });

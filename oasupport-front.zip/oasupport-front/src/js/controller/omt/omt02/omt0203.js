const swal = require('sweetalert2');
/**
 * 自社銀行更新·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt02omt0203Ctrl', function($scope, $location, $routeParams, $api, message, CONST, $timeout) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.bank = {};

            let $url = '/omt02/r/item/' + $routeParams.id;

            // 自社銀行情報の取得
            $api.get($url, function(res) {
                // 自社銀行情報が存在していない場合
                if (res.status == '409') {
                    swal({
                        text: res.data.message,
                        type: 'error',
                        allowOutsideClick: false,
                        confirmButtonText: '自社銀行情報一覧画面へ戻す',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('omt0201');
                        });
                    });
                    return;
                }
                if (res.success) {
                    let data = res.data;
                    $scope.bank = data;
                }
            });

            //預金種類
            $scope.depositTypeList = CONST.DEPOSIT_TYPE_LIST;

            //初期化
            $scope.form_check();
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.bankform').form('validate form');
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            let $url = '/omt02/u/item';
            if ($scope.isValidForm()) {
                $api.post($url, $scope.bank, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.bankform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.bankform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //金融機関名称
                    bankNm: {
                        identifier: 'bankNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '金融機関名称'),
                            },
                        ],
                    },
                    //支店名（漢字）
                    bankchKanji: {
                        identifier: 'bankchKanji',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店名（漢字）'),
                            },
                        ],
                    },
                    //支店名（カナ）
                    bankchKana: {
                        identifier: 'bankchKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店名（カナ）'),
                            },
                        ],
                    },
                    //支店コード
                    bankchCd: {
                        identifier: 'bankchCd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店コード'),
                            },
                        ],
                    },
                    //預金種類
                    depositType: {
                        identifier: 'depositType',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '預金種類'),
                            },
                        ],
                    },
                    //口座番号
                    accountCd: {
                        identifier: 'accountCd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座番号'),
                            },
                        ],
                    },
                    //口座名義（漢字）
                    accountNm: {
                        identifier: 'accountNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座名義（漢字）'),
                            },
                        ],
                    },
                    //口座名義（カナ）
                    accountNmKana: {
                        identifier: 'accountNmKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座名義（カナ）'),
                            },
                        ],
                    },
                },
                onSuccess: function() {
                    if (callback) callback();
                },
            });
        };
    });

const moment = require('moment');
/**
 * 給与作成情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('ossoss0101Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 出金情報一覧の取得処理
            $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();

            // form check 初期化
            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            if (commonService.getData('ossOss0101SearchTarget') && jQuery.isPlainObject(commonService.getData('ossOss0101SearchTarget'))) {
                $scope.search = commonService.getData('ossOss0101SearchTarget');
                if (!$scope.search.salaryYyyymm) {
                    $scope.search.salaryYyyymm = moment().format('YYYY-MM'); // 検索用給与年月
                }
            } else {
                $scope.search = {
                    salaryYyyymm: moment().format('YYYY-MM'), // 検索用給与年月
                    salaryCreateStatus: '', // 給与作成状態「未作成」
                    //"salaryCreateStatus":   "1",                               // 給与作成状態「未作成」
                };
            }

            $scope.searchText = ''; // データ絞り込み用
            $scope.datatable = {};

            $scope.departmentList = {}; //部門リスト
            $scope.empleList = [];

            // select list
            $scope.employStatusList = CONST.EMPLOY_STATUS_LIST; // 雇用形態
            $scope.salaryTypeList = CONST.SALARY_TYPE_LIST; // 給与方式
            $scope.salaryCreateStatusList = CONST.SALARY_CREATE_STATUS_LIST; // 給与作成状態
        };

        /**
         * 出金情報一覧の取得処理
         */
        $scope.searchList = function() {
            if (!$scope.isValidForm()) {
                return false;
            }
            commonService.setData('ossOss0101SearchTarget', $scope.search);
            $api.post('/oss01/r/clist', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.empleList = [];

                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');

                    for (let i = 0; i < data.empleList.length; i++) {
                        $scope.empleList.push(data.empleList[i]);
                    }
                } else {
                    $scope.empleList = [];
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [8],
                    },
                ],
                order: [],
                displayLength: 20,
            };
        };

        /**
         * dtInstanceCallback table
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み(Search)
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.searchForm').form('validate form');
            return jQuery('.searchForm').form('is valid');
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.searchForm').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 給与年月
                    salaryYyyymm: {
                        identifier: 'salaryYyyymm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '給与年月'),
                            },
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '給与年月'),
                            },
                        ],
                    },
                }, // fields end
            });
        };
    });

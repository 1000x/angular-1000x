const moment = require('moment');
/**
 * angular route
 * ■ authorizedRoles: ログインが必須の画面だけ
 * ■ pageRoles: default、「editable, readonly」
 */
module.exports = app => {
    app.config(function($routeProvider, CONST) {
        $routeProvider
            .when('/', {
                redirectTo: '/hom0101',
            })
            // =================== アカウント_START =================== //
            .when('/osa0101', {
                template: require('@/views/osa/osa0101.html'),
            })
            .when('/osa0201', {
                template: require('@/views/osa/osa0201.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osa0210', {
                template: require('@/views/osa/osa0210.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osa0301', {
                template: require('@/views/osa/osa0301.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osa0302', {
                template: require('@/views/osa/osa0302.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/osa0303/:id', {
                template: require('@/views/osa/osa0303.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // ==================== アカウント_END ==================== //
            // =================== HOM_START =================== //
            .when('/hom0101', {
                template: require('@/views/hom/hom0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== HOM_END =================== //

            // =================== 社員管理_START =================== //
            .when('/osu0101', {
                template: require('@/views/osu/osu0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osu0102', {
                template: require('@/views/osu/osu0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/osu0103/:id', {
                template: require('@/views/osu/osu0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osu0301/:id', {
                template: require('@/views/osu/osu0301.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // ==================== 社員管理_END ==================== //

            // =================== 履歴書管理_START =================== //
            .when('/sla0101', {
                template: require('@/views/sla/sla01/sla0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/sla0102', {
                template: require('@/views/sla/sla01/sla0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/sla0103/:id', {
                template: require('@/views/sla/sla01/sla0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/sla0201', {
                template: require('@/views/sla/sla02/sla0201.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/sla0202', {
                template: require('@/views/sla/sla02/sla0202.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/sla0203/:id', {
                template: require('@/views/sla/sla02/sla0203.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/sla0301', {
                template: require('@/views/sla/sla03/sla0301.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/sla0302', {
                template: require('@/views/sla/sla03/sla0302.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // ==================== 履歴書管理_END ==================== //

            // =================== 契約情報_START =================== //
            .when('/osd0101', {
                template: require('@/views/osd/osd0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osd0104', {
                template: require('@/views/osd/osd0104.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osd0102', {
                template: require('@/views/osd/osd0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/osd0102/:id/:detailId?', {
                template: require('@/views/osd/osd0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osd0103/:id/:detailId?', {
                template: require('@/views/osd/osd0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // ==================== 契約情報_END ==================== //

            // =================== 自社基本情報_START =================== //
            .when('/omt0101', {
                template: require('@/views/omt/omt01/omt0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 自社基本情報_END =================== //
            // =================== 自社銀行_START =================== //
            .when('/omt0201', {
                template: require('@/views/omt/omt02/omt0201.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/omt0202', {
                template: require('@/views/omt/omt02/omt0202.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/omt0203/:id', {
                template: require('@/views/omt/omt02/omt0203.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 自社銀行_END =================== //

            // =================== 自社送信メール設定_START =================== //
            .when('/omt0301', {
                template: require('@/views/omt/omt03/omt0301.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 自社送信メール設定_END =================== //

            // =================== 自社部門_START =================== //
            .when('/omt0401', {
                template: require('@/views/omt/omt04/omt0401.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/omt0402', {
                template: require('@/views/omt/omt04/omt0402.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/omt0403/:id', {
                template: require('@/views/omt/omt04/omt0403.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 自社部門_END =================== //

            // =================== 取引先_START =================== //
            .when('/ose0101', {
                template: require('@/views/ose/ose0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/ose0102', {
                template: require('@/views/ose/ose0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/ose0103/:id', {
                template: require('@/views/ose/ose0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 取引先_END =================== //

            // =================== 請求管理_START =================== //
            .when('/oso0101', {
                template: require('@/views/oso/oso0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/oso0102/:id', {
                template: require('@/views/oso/oso0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/oso0103', {
                template: require('@/views/oso/oso0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/oso0104/:id/:detailId?', {
                template: require('@/views/oso/oso0104.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 請求管理_END =================== //

            // =================== 入金_START =================== //
            .when('/ost0101', {
                template: require('@/views/ost/ost0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/ost0102', {
                template: require('@/views/ost/ost0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/ost0102/:id', {
                template: require('@/views/ost/ost0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/ost0103/:id', {
                template: require('@/views/ost/ost0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 入金_END =================== //

            // =================== 出金_START =================== //
            .when('/osw0101', {
                template: require('@/views/osw/osw0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/osw0102', {
                template: require('@/views/osw/osw0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/osw0102/:id', {
                template: require('@/views/osw/osw0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/osw0103/:id', {
                template: require('@/views/osw/osw0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 出金_END =================== //

            // =================== 給与_START =================== //
            .when('/oss0101', {
                template: require('@/views/oss/oss0101.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/oss0102/:id', {
                template: require('@/views/oss/oss0102.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                    pageRoles: [CONST.PAGE_AUTHORITY.editable],
                },
            })
            .when('/oss0103', {
                template: require('@/views/oss/oss0103.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/oss0104/:id', {
                template: require('@/views/oss/oss0104.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/oss0201', {
                template: require('@/views/oss/oss0201.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/oss0301', {
                template: require('@/views/oss/oss0301.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            .when('/oss0302', {
                template: require('@/views/oss/oss0302.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // =================== 給与_END =================== //

            .when('/tools', {
                template: require('@/views/z99/tools.html'),
                data: {
                    authorizedRoles: CONST.USER_TYPE.login_user,
                },
            })
            // ================= error_END ================ //
            .when('/error', {
                template: require('@/views/error/error404.html'),
            })
            .otherwise({
                redirectTo: '/error',
            });
    }).run(function($rootScope, $timeout, $window, $auth, $location, $api, message, CONST, $templateCache) {

        $templateCache.put('mobile_menu.html', require('@/views/z99/mobile_menu.html'));
        $templateCache.put('menu.html', require('@/views/z99/menu.html'));
        $templateCache.put('navbar.html', require('@/views/z99/navbar.html'));
        $templateCache.put('footer.html', require('@/views/z99/footer.html'));

        /**
         * $routeChangeStart
         */
        $rootScope.$on('$routeChangeStart', function(event, next, current) {
            var authorizedRoles, pageRoles;
            if (next.data) {
                authorizedRoles = next.data.authorizedRoles;
                pageRoles = next.data.pageRoles;
                if (!pageRoles) {
                    pageRoles = [CONST.PAGE_AUTHORITY.editable, CONST.PAGE_AUTHORITY.readonly];
                }
            }
            if (!authorizedRoles) return;

            if (!$auth.isAuthorized()) {
                event.preventDefault();
                $auth.autoLogin(event);
            } else {
                // 権限認証
                if (!$auth.isAuthValid(next.originalPath, pageRoles)) {
                    event.preventDefault();
                    if (!current || current.originalPath == '/' || current.originalPath == '/error' || current.originalPath == '/osa0101') {
                        // パスワード変更画面 TODO(home)
                        $location.path('/osa0201');
                    } else {
                        message.showError('権限認証が失敗しました。');
                    }
                }
            }
        });

        /**
         * $routeChangeSuccess
         */
        $rootScope.$on('$routeChangeSuccess', function(event, next, current) {
            //**************** form check 拡張 start ****************//
            /**
             * 日付check
             * @param value
             * @param format
             */
            $.fn.form.settings.rules.date = function(value, format) {
                if (!value) return true;
                if (!moment) {
                    console.warn('[moment.js] is necessary');
                    return false;
                }
                return moment(value, format, true).isValid();
            };

            /**
             * カタカナチェック
             * @param value
             * @param format
             */
            $.fn.form.settings.rules.kana = function(value) {
                return !value || /^[\u30a0-\u30ff]+$/.test(value);
            };

            /**
             * 比較
             * @param value
             * @param value2
             */
            $.fn.form.settings.rules.greaterThan = function(value, identifier) {
                var matchingValue;
                if ($('[data-validate="' + identifier + '"]').length > 0) {
                    matchingValue = $('[data-validate="' + identifier + '"]').val();
                } else if ($('#' + identifier).length > 0) {
                    matchingValue = $('#' + identifier).val();
                } else if ($('[name="' + identifier + '"]').length > 0) {
                    if ($('[name="' + identifier + '"]').length == 1) {
                        matchingValue = $('[name="' + identifier + '"]').val();
                    } else {
                        matchingValue = $(this)
                            .closest('.ui.form')
                            .find('[name="' + identifier + '"]')
                            .val();
                    }
                } else if ($('[name="' + identifier + '[]"]').length > 0) {
                    matchingValue = $('[name="' + identifier + '[]"]');
                } else {
                    matchingValue = identifier;
                }
                if (jQuery.isNumeric(value) && jQuery.isNumeric(matchingValue)) {
                    return Number(value) >= Number(matchingValue);
                }
                return matchingValue !== undefined ? value.toString() >= matchingValue.toString() : false;
            };
            /**
             * 比較
             * @param value
             * @param identifier
             */
            $.fn.form.settings.rules.lessThan = function(value, identifier) {
                var matchingValue;
                if ($('[data-validate="' + identifier + '"]').length > 0) {
                    matchingValue = $('[data-validate="' + identifier + '"]').val();
                } else if ($('#' + identifier).length > 0) {
                    matchingValue = $('#' + identifier).val();
                } else if ($('[name="' + identifier + '"]').length > 0) {
                    if ($('[name="' + identifier + '"]').length == 1) {
                        matchingValue = $('[name="' + identifier + '"]').val();
                    } else {
                        matchingValue = $(this)
                            .closest('.ui.form')
                            .find('[name="' + identifier + '"]')
                            .val();
                    }
                } else if ($('[name="' + identifier + '[]"]').length > 0) {
                    matchingValue = $('[name="' + identifier + '[]"]');
                } else {
                    matchingValue = identifier;
                }
                if (jQuery.isNumeric(value) && jQuery.isNumeric(matchingValue)) {
                    return Number(value) <= Number(matchingValue);
                }
                return matchingValue !== undefined ? value.toString() <= matchingValue.toString() : false;
            };
            //**************** form check 拡張 end ****************//
        });

        /**
         * $viewContentLoaded
         */
        $rootScope.$on('$viewContentLoaded', function() {
            // .ui.accordion.menu-accordion
            $timeout(function() {
                $('.ui.accordion').accordion(); //accordion trigger
                $('.ui.accordion.menu-accordion')
                    .find('.content.active .item')
                    .removeClass('hidden');
            }, 20);
            $api.hide_loader();
        });

        /**
         * reload
         */
        $rootScope.$on('reload_session', function() {
            console.log('reload path ' + $location.path());
        });

        /**
         * resize
         */
        angular.element($window).bind('resize', function() {
            $timeout(function() {
                $('body').scrollTop(0);
            }, 10);
        });
    });
};

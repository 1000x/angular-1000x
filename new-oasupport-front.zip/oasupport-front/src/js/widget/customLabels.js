const angular = require('angular');
const moment = require('moment');
require('@chenfengyuan/datepicker/dist/datepicker.css');
require('@chenfengyuan/datepicker/dist/datepicker');
require('@chenfengyuan/datepicker/i18n/datepicker.ja-JP');

/**
 * app.customLabels
 */
module.exports = angular
    .module('app.customLabels', [])
    .directive('dropdown', function($timeout) {
        return {
            scope: {
                ngModel: '=',
                list: '=',
                ngDisabled: '=',
                searchAble: '=?',
                allowAdditions: '=?',
                name: '@',
                placeholder: '@',
                ngChange: '&',
            },
            restrict: 'E',
            replace: 'true',
            template: require('@/js/widget/template/dropdown.html'),
            link: function(scope, elem, attrs) {
                elem.removeAttr('name');

                var $elem = jQuery(elem);

                // class
                if (attrs['class']) {
                    $elem.addClass(attrs['class']);
                }
                // style
                if (attrs['style']) {
                    $elem.attr('style', attrs['style']);
                }
                // width
                if (attrs['width']) {
                    $elem.css({
                        'min-width': attrs['width'],
                    });
                } else {
                    $elem.css({
                        'min-width': '100%',
                    });
                }
                // spaceOption
                if (attrs['spaceOption']) {
                    scope.spaceOption = attrs['spaceOption'];
                }
                // searchAble[default : false]
                if (!scope.searchAble) scope.searchAble = false;
                if (scope.allowAdditions) scope.searchAble = true;

                // 初期化
                $elem
                    .find(':hidden')
                    .val(scope.ngModel)
                    .attr('name', scope.name);

                $timeout(function() {
                    $elem.dropdown({
                        allowAdditions: !!scope.allowAdditions,
                        hideAdditions: !scope.allowAdditions,
                        forceSelection: !scope.allowAdditions,
                        onChange: function() {
                            scope.ngModel = $elem.find(':hidden').val();
                            if ($elem.hasClass('active') && !scope.$parent.$$phase) {
                                scope.$parent.$digest();
                                scope.ngChange();
                            }
                        },
                    }); //dropdown and select trigger
                });

                scope.$parent.$watch(attrs.ngDisabled, function(newVal, oldVal) {
                    scope.ngDisabled = newVal;
                });

                scope.$parent.$watch(attrs.ngModel, function(newVal, oldVal) {
                    scope.ngModel = newVal;
                    $timeout(function() {
                        if (newVal === '' || newVal === null || newVal === undefined) {
                            //$elem.dropdown('restore defaults');
                        } else {
                            $elem.dropdown('set selected', newVal);
                        }
                    });
                });

                scope.$parent.$watch(attrs.list, function(newVal, oldVal) {
                    scope.list = newVal;
                    $timeout(function() {
                        $elem.dropdown('set selected', scope.ngModel);
                    });
                });
            },
        };
    })
    .directive('radiobutton', function($timeout) {
        return {
            scope: {
                /* Required */
                ngModel: '=',
                value: '=?',
                name: '@',
                label: '@',
                /* Optional */
                ngDisabled: '=',
                /* Events */
                ngChange: '&',
            },
            restrict: 'E',
            replace: 'true',
            template: require('@/js/widget/template/radiobutton.html'),
            link: function(scope, elem, attrs) {
                elem.removeAttr('name');

                elem.ready(function() {
                    elem.checkbox({
                        onChange: function() {
                            scope.ngModel = scope.value;
                            if (!scope.$parent.$$phase) {
                                scope.$parent.$digest();
                                $timeout(function() {
                                    scope.ngChange();
                                });
                            }
                        },
                    });

                    if (scope.value === undefined) {
                        scope.value = true;
                    }

                    if (scope.ngModel == scope.value || scope.ngModel == 'true' || scope.ngModel === true) {
                        elem.checkbox('set checked');
                    }

                    if (elem.hasClass('slider')) {
                        elem.removeClass('radio');
                    }

                    if (scope.ngDisabled) {
                        elem.checkbox('set disabled');
                    }

                    scope.$parent.$watch(attrs.ngDisabled, function(newVal, oldVal) {
                        elem.checkbox(newVal ? 'set disabled' : 'set enabled');
                    });

                    scope.$parent.$watch(attrs.ngModel, function(newVal, oldVal) {
                        if (newVal == scope.value) {
                            elem.checkbox('set checked');
                        }
                    });
                });
            },
        };
    })
    .directive('countries', function($timeout) {
        return {
            scope: {
                ngModel: '=',
                ngDisabled: '=',
                name: '@',
                placeholder: '@',
                ngChange: '&',
            },
            restrict: 'E',
            replace: 'true',
            template: require('@/js/widget/template/dropdown-country.html'),
            link: function(scope, elem, attrs) {
                elem.removeAttr('name');

                var $elem = jQuery(elem);

                // class
                if (attrs['class']) {
                    $elem.addClass(attrs['class']);
                }
                // style
                if (attrs['style']) {
                    $elem.attr('style', attrs['style']);
                }
                // width
                if (attrs['width']) {
                    $elem.css({
                        'min-width': attrs['width'],
                    });
                } else {
                    $elem.css({
                        'min-width': '100%',
                    });
                }
                // 初期化
                $elem.find(':hidden').val(scope.ngModel);

                $timeout(function() {
                    $elem.dropdown({
                        onChange: function() {
                            scope.ngModel = $elem.find(':hidden').val();
                            if (!scope.$parent.$$phase) {
                                scope.$parent.$digest();
                                scope.ngChange();
                            }
                        },
                    }); //dropdown and select trigger
                });

                scope.$parent.$watch(attrs.ngDisabled, function(newVal, oldVal) {
                    scope.ngDisabled = newVal;
                });

                scope.$parent.$watch(attrs.ngModel, function(newVal, oldVal) {
                    scope.ngModel = newVal;
                    $timeout(function() {
                        if (newVal === '' || newVal === null || newVal === undefined) {
                            $elem.dropdown('restore defaults');
                        } else {
                            $elem.dropdown('set selected', newVal);
                        }
                    });
                });
            },
        };
    })
    .directive('datepicker', function() {
        return {
            scope: {
                ngModel: '=',
                ngDisabled: '=',
                name: '@',
                ngChange: '&',
            },
            restrict: 'E',
            replace: true,
            template: '<div class="ui input"><input type="text" maxlength="10" ng-model="ngModel" input-convert="date" /></div>',
            link: function(scope, elem, attrs) {
                elem.removeAttr('name');

                var picker = elem.find('input');
                var dateFormat = attrs['format'] || 'YYYY-MM-DD';

                // width
                if (attrs['width']) picker.css('width', attrs['width']);
                // placeholder
                if (attrs['placeholder']) {
                    picker.attr('placeholder', attrs['placeholder']);
                }
                // name
                if (attrs['name']) {
                    picker.attr('name', attrs['name']);
                }
                // class
                if (attrs['class']) {
                    picker.addClass(attrs['class']);
                }

                picker.datepicker({
                    format: dateFormat,
                    language: 'ja-JP',
                    autoHide: true,
                });

                scope.$parent.$watch(attrs['ngDisabled'], function(newVal, oldVal) {
                    picker.prop('disabled', newVal);
                });

                scope.$parent.$watch(attrs['ngModel'], function(newVal, oldVal) {
                    if (!newVal) {
                        picker.val('');
                        picker.datepicker('update');
                        return;
                    }
                    if (newVal instanceof Date) {
                        picker.datepicker('setDate', moment(newVal).format(dateFormat));
                    } else if (newVal.length >= 8) {
                        var date = moment(newVal.replace(/[-|\/]/g, ''), 'YYYYMMDD', true);
                        if (date.isValid()) picker.datepicker('setDate', date.format(dateFormat));
                    }
                });

                // change
                picker.bind('change', function() {
                    $(this).datepicker('hide');
                    if (!attrs['ngModel']) return;
                    scope.ngModel = $(this)
                        .val()
                        .replace(new RegExp('/', 'g'), '-');
                    if (!scope.$parent.$$phase) {
                        scope.$parent.$digest();
                        scope.ngChange();
                    }
                });

                // dblclick
                picker.bind('dblclick', function() {
                    $(this).datepicker('setDate', new Date());
                });
            },
        };
    })
    .directive('userSelectModal', [
        '$timeout',
        '$api',
        'commonService',
        function($timeout, $api, commonService) {
            return {
                scope: {
                    visible: '=',
                    multiSelect: '=?',
                    ngClass: '=?',
                    header: '@',
                    /* Events */
                    ngConfirm: '&',
                    ngCancel: '&',
                },
                restrict: 'E',
                replace: true,
                template: require('@/js/widget/template/user-select-modal.html'),
                link: function(scope, elem, attrs) {
                    // header
                    if (!scope.header) scope.header = 'ユーザー検索';
                    // multiSelect[default : false]
                    if (!scope.multiSelect) scope.multiSelect = false;

                    // search
                    scope.search = {
                        departId: '',
                        text: '',
                    };

                    scope.checkAll = false;
                    scope.btnClick = false;

                    /**
                     * ユーザーリストの検索処理
                     */
                    scope.doSearch = function() {
                        // 社員一覧情報の取得処理
                        $api.get('/osu01/r/list?departId=' + scope.search.departId, function(res) {
                            if (res.success) {
                                var data = res.data;

                                // 社員リスト
                                scope.userList = [];
                                // 部門リスト
                                scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');

                                for (var i = 0; i < data.empleList.length; i++) {
                                    var info = data.empleList[i];
                                    // checked
                                    if (!scope.multiSelect && i == 0) {
                                        info.checked = true;
                                    } else {
                                        info.checked = false;
                                    }
                                    // // 部門名
                                    info.departNm = scope.departmentList[info.department];
                                    // 姓名
                                    if (info.lastNmKanji || info.fristNmKanji) {
                                        info.userNm = jQuery.trim(info.lastNmKanji + ' ' + info.fristNmKanji);
                                    } else {
                                        info.userNm = jQuery.trim(info.lastNmKana + ' ' + info.fristNmKana);
                                    }
                                    scope.userList.push(info);
                                }
                            } else {
                                scope.userList = [];
                                scope.departmentList = {};
                            }

                            $timeout(function() {
                                elem.modal('refresh');
                            });
                        });
                    };

                    /**
                     * set checked
                     */
                    scope.setChecked = function(index) {
                        if (scope.multiSelect) {
                            return false;
                        }

                        for (var i = 0; i < scope.userList.length; i++) {
                            if (i == index) {
                                scope.userList[i].checked = true;
                            } else {
                                scope.userList[i].checked = false;
                            }
                        }
                    };

                    /**
                     * toggleMaster
                     */
                    scope.toggleMaster = function() {
                        scope.checkAll = !scope.checkAll;
                        for (var i = 0; i < scope.userList.length; i++) {
                            scope.userList[i].checked = scope.checkAll;
                        }
                    };

                    // modal初期化
                    elem.modal({
                        autofocus: false,
                        onShow: function() {
                            scope.doSearch();
                        },
                        onApprove: function() {
                            scope.btnClick = true;
                            if (scope.userList && scope.userList.length > 0) {
                                // data
                                var data;
                                if (scope.multiSelect) {
                                    data = [];
                                    for (var i = 0; i < scope.userList.length; i++) {
                                        var info = scope.userList[i];
                                        if (info.checked) {
                                            data.push(info);
                                        }
                                    }
                                } else {
                                    for (var i = 0; i < scope.userList.length; i++) {
                                        var info = scope.userList[i];
                                        if (info.checked) {
                                            data = info;
                                            break;
                                        }
                                    }
                                }
                                if (!scope.$parent.$$phase) {
                                    scope.$parent.$digest();
                                    scope.ngConfirm({ data: data });
                                }
                            }
                        },
                        onDeny: function() {
                            scope.btnClick = true;
                            if (!scope.$parent.$$phase) {
                                scope.$parent.$digest();
                                scope.ngCancel();
                            }
                        },
                        onHide: function() {
                            $timeout(function() {
                                scope.$parent[attrs.visible] = false;
                            });
                            if (!scope.btnClick && !scope.$parent.$$phase) {
                                scope.$parent.$digest();
                                scope.ngCancel();
                            }
                        },
                    });

                    scope.$parent.$watch(attrs['visible'], function(newVal, oldVal) {
                        if (newVal) {
                            elem.modal('show');
                        }
                    });
                },
            };
        },
    ]);

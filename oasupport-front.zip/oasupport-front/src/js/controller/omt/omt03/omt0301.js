/**
 * 自社送信メール設定·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt03omt0301Ctrl', function($scope, $timeout, $api, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.mailInfo = {};

            // select list
            $scope.sslList = CONST.MAIL_SSL_LIST; // メールSSLリスト
            $scope.authenticationList = CONST.MAIL_AUTHENTICATION_LIST; // メール認証方式リスト
            $scope.mailPortList = CONST.DEFAULT_MAIL_PORT_LIST; // メールポート

            // 処理データ取得
            $scope.search();

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * 初期データを取得する
         */
        $scope.search = function() {
            $api.get('/omt03/r/item', function(res) {
                if (res.success && res.data.mailInfo) {
                    $scope.mailInfo = res.data.mailInfo;
                } else {
                    $scope.mailInfo = {
                        port: '587', // ポート番号
                        ssl: '3', // ssl[SSL/TLS]
                        authentication: '2', // 認証方式[通常のパスワード認証]
                        timeout: '60', // タイムアウト
                    };
                }
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.mainform').form('validate form');
            return jQuery('.mainform').form('is valid');
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/omt03/u/item', $scope.mailInfo, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * 接続テスト
         */
        $scope.connectionTest = function() {
            if ($scope.isValidForm()) {
                $api.post('/omt03/t/item', $scope.mailInfo, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                        $scope.mailInfo.status = '1'; // 接続成功
                    } else {
                        message.showError(res.data.message);
                        $scope.mailInfo.status = '2'; // 接続失敗
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // お名前
                    fromName: {
                        identifier: 'fromName',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'お名前'),
                            },
                        ],
                    },
                    // メールアドレス
                    fromEmail: {
                        identifier: 'fromEmail',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'メールアドレス'),
                            },
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', 'メールアドレス'),
                            },
                        ],
                    },
                    // パスワード
                    fromPwd: {
                        identifier: 'fromPwd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'パスワード'),
                            },
                        ],
                    },
                    // タイムアウト(秒)
                    timeout: {
                        identifier: 'timeout',
                        optional: true,
                        rules: [
                            {
                                type: 'integer',
                                prompt: message.getMsgById('E_XX_FW_5004', 'タイムアウト(秒)'),
                            },
                        ],
                    },
                    // サーバーのホスト名
                    host: {
                        identifier: 'host',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'サーバーのホスト名'),
                            },
                        ],
                    },
                    // ポート番号
                    port: {
                        identifier: 'port',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'ポート番号'),
                            },
                            {
                                type: 'integer',
                                prompt: message.getMsgById('E_XX_FW_5004', 'ポート番号'),
                            },
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', 'ポート番号'),
                            },
                        ],
                    },
                    // SSL
                    ssl: {
                        identifier: 'ssl',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5023', 'SSL'),
                            },
                        ],
                    },
                    // 認証方式
                    authentication: {
                        identifier: 'authentication',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5023', '認証方式'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

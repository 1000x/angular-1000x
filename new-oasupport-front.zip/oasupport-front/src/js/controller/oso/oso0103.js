const swal = require('sweetalert2');
/**
 * 請求情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('osooso0103Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 請求一覧の取得処理
            $scope.searchList();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };
        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                claimDt: '', // moment().format("YYYY-MM"),  // 検索用年月
                claimFlg: '', // 検索用請求状態
                claimToCompanyId: '',
            };

            // ソート
            $scope.sort = {};

            $scope.searchText = ''; // データ絞り込み用

            // select list
            $scope.claimFlgList = CONST.CLAIM_STATUS_LIST; // 請求情報作成状態リスト
            $scope.claimToCompanyList = {}; // 請求先会社リスト

            // drop listの取得
            $api.get('/osw01/r/droplist', function(res) {
                if (res.success) {
                    // 会社リスト
                    $scope.claimToCompanyList = commonService.makeArrToDroplist(res.data.contractorCompList, 'corporationCompId', 'customerCompNm');
                }
            });
        };

        /**
         * 請求情報一覧取得処理
         */
        $scope.searchList = function() {
            $api.post('/oso01/r/claimlist', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.claimList = [];
                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(data.contractorCompList, 'corporationCompId', 'customerCompNm');
                    // 銀行リスト
                    $scope.bankList = commonService.makeArrToDroplist(data.bankList, 'bankId', 'bankNm');

                    for (let i = 0; i < data.claimList.length; i++) {
                        let info = data.claimList[i];
                        // 展開する
                        info.expand = false;
                        // toggle check
                        info.toggleCheck = true;
                        // ソート
                        info.sort = {};
                        // 請求先会社名称
                        info.claimToCompanyNm = $scope.contractorCompList[info.claimToCompanyId];
                        // 請求金額の算出
                        let claimMoney = 0;
                        // 詳細
                        for (let j = 0; j < info.details.length; j++) {
                            info.details[j].checked = true;
                            claimMoney += Number(info.details[j].claimMoney) || 0;
                        }
                        info.claimMoney = claimMoney;
                        $scope.claimList.push(info);
                    }
                } else {
                    $scope.claimList = [];
                }
            });
        };

        /**
         * sort by
         */
        $scope.sortBy = function(sort, target) {
            sort.target = target;
            sort.reverse = !sort.reverse;
        };

        /**
         * sorting
         */
        $scope.sorting = function(sort, target) {
            return {
                sorting: sort.target != target,
                sorting_asc: sort.target == target && !sort.reverse,
                sorting_desc: sort.target == target && sort.reverse,
            };
        };

        /**
         * toggle_check
         * @param claimInfo
         */
        $scope.toggle_check = function(claimInfo) {
            claimInfo.toggleCheck = !claimInfo.toggleCheck;
            for (let i = 0; i < claimInfo.details.length; i++) {
                claimInfo.details[i].checked = claimInfo.toggleCheck;
            }
        };

        /**
         * 請求削除処理
         * @param rowsId
         * @param index
         */
        $scope.claimDel = function(rowsId, index) {
            let $url = '/oso01/d/item/' + rowsId;
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.post($url, null, function(res) {
                            if (res.success) {
                                message.showSuccess('削除しました。');
                                $scope.claimList.splice(index, 1);
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         * 請求書のダウンロード
         * @param claimRowsId 請求rowsId
         * @param rowsId
         * @param type [1:Excel, 2:Pdf]
         */
        $scope.downloadFile = function(claimRowsId, rowsId, type) {
            $scope.doDownload(claimRowsId, [rowsId], type);
        };

        /**
         * 請求書リストのダウンロード
         * @param claimInfo
         * @param type [1:Excel, 2:Pdf]
         */
        $scope.downloadList = function(claimInfo, type) {
            let rowsIdList = [];
            for (let i = 0; i < claimInfo.details.length; i++) {
                if (claimInfo.details[i].checked) {
                    rowsIdList.push(claimInfo.details[i].rowsId);
                }
            }
            if (rowsIdList.length == 0) {
                claimInfo.expand = true;
                message.showError(message.getMsgById('E_XX_FW_5022', '操作対象'));
            } else {
                $scope.doDownload(claimInfo.rowsId, rowsIdList, type);
            }
        };

        /**
         * 請求書リストのダウンロード
         * @param claimRowsId
         * @param rowsIdList
         * @param type [1:Excel, 2:Pdf]
         */
        $scope.doDownload = function(claimRowsId, rowsIdList, type) {
            $api.post('/oso01/download/item/' + claimRowsId + '/' + type, rowsIdList, function(res) {
                if (res.success) {
                    let blob = $api.b64toBlob(res.data.fileBase64String, 'application/vnd.ms-excel');
                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, res.data.fileName);
                    } else {
                        let objectUrl = URL.createObjectURL(blob);
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = objectUrl;
                        a.download = res.data.fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };

        $scope.form_check = function() {
            jQuery('.searchform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 請求年月選択
                    contractYm: {
                        identifier: 'claimYm',
                        rules: [
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5019', '請求年月'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };

        /**
         * CSVダウロードの取得処理
         */
        $scope.downloadCsv = function() {
            let param = {
                claimDt: $scope.search.claimDt,
                claimFlg: $scope.search.claimFlg,
                claimToCompanyId: $scope.search.claimToCompanyId,
            };

            $api.post('/oso01/download/list', param, function(res) {
                if (res.success) {
                    let blob = $api.b64toBlob(res.data.fileBase64String, 'application/octet-stream');
                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, res.data.fileName);
                    } else {
                        let objectUrl = URL.createObjectURL(blob);
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = objectUrl;
                        a.download = res.data.fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };
    });

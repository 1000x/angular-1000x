const moment = require('moment');
const swal = require('sweetalert2');
/**
 * 給与一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('ossoss0103Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 給与情報一覧の取得処理
            $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                salaryYyyymm: moment().format('YYYY-MM'), // 検索用年月
            };

            $scope.searchText = ''; // データ絞り込み用
            $scope.datatable = {};
            $scope.masterCheck = false;

            $scope.departmentList = {}; //部門リスト
            $scope.empleList = [];

            // select list
            $scope.employStatusList = CONST.EMPLOY_STATUS_LIST; // 雇用形態
            $scope.salaryTypeList = CONST.SALARY_TYPE_LIST; // 給与方式
            $scope.salaryPayFlgList = CONST.SALARY_PAY_FLG_LIST; // 給与支払状態
            $scope.salaryEmailFlgList = CONST.SALARY_EMAIL_FLG_LIST; // 送信状態
        };

        /**
         * 給与一覧の取得処理
         */
        $scope.searchList = function() {
            if (!$scope.isValidForm()) {
                return false;
            }
            $api.post('/oss01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.salaryList = [];

                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');

                    for (let i = 0; i < data.salaryList.length; i++) {
                        let info = data.salaryList[i];
                        info.checked = $scope.masterCheck;
                        // 差引支給額の算出
                        info.withdrawalMoney = $scope.calWithdrawalMoney(info);
                        $scope.salaryList.push(info);
                    }
                } else {
                    $scope.salaryList = [];
                }
            });
        };

        /**
         * 差引支給額の算出
         * @param info
         */
        $scope.calWithdrawalMoney = function(info) {
            // 課税支給額(合計)
            let payTotalTax =
                $api.toNumeric(info.monthSalary) + $api.toNumeric(info.dutiesAllow) + $api.toNumeric(info.skillAllow) + $api.toNumeric(info.specialAllow) + $api.toNumeric(info.overtimeAllow) + $api.toNumeric(info.commutAllowTax);
            // 非課税支給額(合計)
            let PayTotalNoTax = $api.toNumeric(info.commutAllowNotax);
            // 控除額(合計)
            let totalDeduction =
                $api.toNumeric(info.healthInsurance) +
                $api.toNumeric(info.welfarePension) +
                $api.toNumeric(info.employInsurance) +
                $api.toNumeric(info.incomeTax) +
                $api.toNumeric(info.municipalTax) +
                $api.toNumeric(info.socialInsurance) +
                $api.toNumeric(info.absence) +
                $api.toNumeric(info.otherDeduction);
            // その他調整額（合計）
            let totalOther = $api.toNumeric(info.otherYearEndAdjustmen) + $api.toNumeric(info.otherAdvanceMoney) + $api.toNumeric(info.otherAdjust);

            return payTotalTax + PayTotalNoTax - totalDeduction + totalOther;
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [0, 10],
                    },
                ],
                order: [],
                displayLength: 20,
            };
        };

        /**
         * dtInstanceCallback table
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み(Search)
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * toggle_master
         */
        $scope.toggle_master = function() {
            $scope.masterCheck = !$scope.masterCheck;
            for (let i = 0; i < $scope.salaryList.length; i++) {
                $scope.salaryList[i].checked = $scope.masterCheck;
            }
        };

        /**
         * 社員名の取得
         */
        $scope.getName = function(empleInfo) {
            let uName;
            // 姓名
            if (empleInfo.lastNmKanji || empleInfo.fristNmKanji) {
                uName = jQuery.trim(empleInfo.lastNmKanji + ' ' + empleInfo.fristNmKanji);
            } else {
                uName = jQuery.trim(empleInfo.lastNmKana + ' ' + empleInfo.fristNmKana);
            }
            return uName;
        };

        /**
         * 給与削除処理
         */
        $scope.salaryDel = function(info) {
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.get('/oss01/d/item/' + info.rowsId, function(res) {
                            if (res.success) {
                                message.showSuccess('削除しました。');
                                // 給与情報一覧の取得処理
                                $scope.searchList();
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         *
         */
        $scope.salaryPaid = function(info) {
            swal({
                text: '支払済みよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.get('/oss01/u/item/' + info.rowsId, function(res) {
                            if (res.success) {
                                message.showSuccess('success');
                                // 給与情報一覧の取得処理
                                $scope.searchList();
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         * hasChecked
         */
        $scope.hasChecked = function() {
            if (!$scope.salaryList) return false;
            let hasChecked = false;
            for (let i = 0; i < $scope.salaryList.length; i++) {
                if ($scope.salaryList[i].checked) {
                    hasChecked = true;
                    break;
                }
            }
            return hasChecked;
        };

        /**
         * 給与明細のダウンロード処理
         */
        $scope.downloadSalary = function() {
            let rowsIdList = [];
            for (let i = 0; i < $scope.salaryList.length; i++) {
                if ($scope.salaryList[i].checked) {
                    rowsIdList.push($scope.salaryList[i].rowsId);
                }
            }
            if (rowsIdList.length > 0) {
                $api.post('/oss01/download/list', rowsIdList, function(res) {
                    if (res.success) {
                        let blob;
                        if (rowsIdList.length > 1) {
                            blob = $api.b64toBlob(res.data.fileBase64String, 'application/octet-stream');
                        } else {
                            blob = $api.b64toBlob(res.data.fileBase64String, 'application/pdf');
                        }
                        if (window.navigator.msSaveBlob) {
                            window.navigator.msSaveBlob(blob, res.data.fileName);
                        } else {
                            let objectUrl = URL.createObjectURL(blob);
                            let a = document.createElement('a');
                            document.body.appendChild(a);
                            a.style = 'display: none';
                            a.href = objectUrl;
                            a.download = res.data.fileName;
                            a.click();
                            document.body.removeChild(a);
                        }
                    } else {
                        message.showError(res.data.message);
                    }
                });
            }
        };

        /**
         * メール送信処理
         */
        $scope.sendMail = function() {
            let rowsIdList = [];
            for (let i = 0; i < $scope.salaryList.length; i++) {
                if ($scope.salaryList[i].checked) {
                    rowsIdList.push($scope.salaryList[i].rowsId);
                }
            }
            if (rowsIdList.length > 0) {
                $api.post('/oss01/mail/list', rowsIdList, function(res) {
                    if (res.success) {
                        message.showSuccess('送信成功しました。');
                        // 給与情報一覧の取得処理
                        $scope.searchList();
                    } else {
                        message.showError(res.data.message);
                    }
                });
            }
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.searchForm').form('validate form');
            return jQuery('.searchForm').form('is valid');
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.searchForm').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 給与年月
                    salaryYyyymm: {
                        identifier: 'salaryYyyymm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '給与年月'),
                            },
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '給与年月'),
                            },
                        ],
                    },
                }, // fields end
            });
        };
    });

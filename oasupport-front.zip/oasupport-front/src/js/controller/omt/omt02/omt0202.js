/**
 * 自社銀行情報更新·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt02omt0202Ctrl', function($scope, $timeout, $api, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.bank = {};

            // $scope.bank.bankCd = '101'; //金融機関コード
            // $scope.bank.bankNm = 'みずほ銀行'; //金融機関名称
            // $scope.bank.bankchKanji = '上野支店'; //支店名（漢字）
            // $scope.bank.bankchKana = 'ウエノ'; //支店名（カナ）
            // $scope.bank.bankchCd = '790'; //支店コード
            // $scope.bank.depositType = '1'; //預金種類
            // $scope.bank.accountCd = '1234567'; //口座番号
            // $scope.bank.accountNm = '創点株式会社'; //口座名義（漢字）
            // $scope.bank.accountNmKana = 'ソウテン（カ'; //口座名義（カナ）

            $scope.bank.bankCd = ''; //金融機関コード
            $scope.bank.bankNm = ''; //金融機関名称
            $scope.bank.bankchKanji = ''; //支店名（漢字）
            $scope.bank.bankchKana = ''; //支店名（カナ）
            $scope.bank.bankchCd = ''; //支店コード
            $scope.bank.depositType = ''; //預金種類
            $scope.bank.accountCd = ''; //口座番号
            $scope.bank.accountNm = ''; //口座名義（漢字）
            $scope.bank.accountNmKana = ''; //口座名義（カナ）

            //預金種類
            $scope.depositTypeList = CONST.DEPOSIT_TYPE_LIST;

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.bankform').form('validate form');
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            let $url = '/omt02/c/item';
            if ($scope.isValidForm()) {
                $api.post($url, $scope.bank, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.bankform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.bankform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //金融機関名称
                    bankNm: {
                        identifier: 'bankNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '金融機関名称'),
                            },
                        ],
                    },
                    //支店名（漢字）
                    bankchKanji: {
                        identifier: 'bankchKanji',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店名（漢字）'),
                            },
                        ],
                    },
                    //支店名（カナ）
                    bankchKana: {
                        identifier: 'bankchKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店名（カナ）'),
                            },
                        ],
                    },
                    //支店コード
                    bankchCd: {
                        identifier: 'bankchCd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店コード'),
                            },
                        ],
                    },
                    //預金種類
                    depositType: {
                        identifier: 'depositType',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '預金種類'),
                            },
                        ],
                    },
                    //口座番号
                    accountCd: {
                        identifier: 'accountCd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座番号'),
                            },
                        ],
                    },
                    //口座名義（漢字）
                    accountNm: {
                        identifier: 'accountNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座名義（漢字）'),
                            },
                        ],
                    },
                    //口座名義（カナ）
                    accountNmKana: {
                        identifier: 'accountNmKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座名義（カナ）'),
                            },
                        ],
                    },
                },
                onSuccess: function() {
                    if (callback) callback();
                },
            });
        };
    });

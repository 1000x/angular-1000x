module.exports = app => {
    require('./commonService')(app);
};
const moment = require('moment');
const swal = require('sweetalert2');
/**
 * 契約情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('osdosd0101Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 契約情報一覧の取得処理
            $scope.searchList();

            // form check初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            if (commonService.getData('osdOsd0101SearchTarget') && jQuery.isPlainObject(commonService.getData('osdOsd0101SearchTarget'))) {
                $scope.search = commonService.getData('osdOsd0101SearchTarget');
                if (!$scope.search.contractYm) {
                    $scope.search.contractYm = moment().format('YYYY-MM');
                }
            } else {
                $scope.search = {
                    contractYm: moment().format('YYYY-MM'), // 検索用年月
                    contractorCompId: '', // 検索用会社名称
                    contractType: '', // 検索用契約区分
                    contractEndFlg: '', // 検索用契約有効・無効区分
                    //"contractEndFlg":     "1",                         // 検索用契約有効・無効区分
                };
            }

            // ソート
            $scope.sort = {};

            $scope.searchText = ''; // データ絞り込み用
            $scope.masterChecked = false;
            $scope.datatable = {};
            $scope.contractList = [];

            // select list
            $scope.contractTypeList = CONST.CONTRACT_TYPE_LIST; // 所属リスト
            $scope.contractEndFlgList = CONST.VALID_FLG_LIST; // 契約有効・無効リスト
        };

        /**
         * 契約情報一覧の取得処理
         */
        $scope.searchList = function() {
            if (!$scope.isValidForm()) {
                return false;
            }
            commonService.setData('osdOsd0101SearchTarget', $scope.search);
            $api.post('/osd01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.contractList = [];
                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(data.contractorCompList, 'corporationCompId', 'customerCompNm');
                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');
                    // 銀行リスト
                    $scope.bankList = commonService.makeArrToDroplist(data.bankList, 'bankId', 'bankNm');

                    for (let i = 0; i < data.contractList.length; i++) {
                        let info = data.contractList[i];
                        info.expand = false;
                        // ソート
                        info.sort = {};
                        // 請求先会社名称
                        info.contractorCompNm = $scope.contractorCompList[info.contractorCompId];
                        // 支払先名称
                        info.payeeNm = $scope.bankList[info.payeeId];
                        // 支払期限
                        info.payDeadline_disp = $scope.makePayDeadline(info);

                        $scope.contractList.push(info);
                    }
                } else {
                    $scope.contractList = [];
                }
            });
        };

        /**
         * sort by
         */
        $scope.sortBy = function(sort, target) {
            sort.target = target;
            sort.reverse = !sort.reverse;
        };

        /**
         * sorting
         */
        $scope.sorting = function(sort, target) {
            return {
                sorting: sort.target != target,
                sorting_asc: sort.target == target && !sort.reverse,
                sorting_desc: sort.target == target && sort.reverse,
            };
        };

        /**
         * 支払期限の編集
         */
        $scope.makePayDeadline = function(contractInfo) {
            if (!contractInfo.payDeadlineMonthFlg) return '';
            let payDeadLine = CONST.PAY_DEADLINE_LIST[contractInfo.payDeadlineMonthFlg] + ' ';
            // 月末の場合
            if (contractInfo.payDeadlineDayFlg == '1') {
                payDeadLine += '月末';
            } else {
                payDeadLine += contractInfo.payDeadlineDay + '日';
            }
            return payDeadLine;
        };

        /**
         * 契約終了処理
         * @param detail
         */
        $scope.contractInvalid = function(detail) {
            swal({
                text: '契約終了してよろしいですか。',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    let data = {
                        rowsId: detail.rowsId,
                    };
                    if (isConfirm) {
                        $api.post('/osd01/u/item/contractEnd', data, function(res) {
                            if (res.success) {
                                message.showSuccess('処理成功');
                                detail.contractEndFlg = '2';
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.searchForm').form('validate form');
            return jQuery('.searchForm').form('is valid');
        };

        /**
         * 出金削除処理
         */
        $scope.contractDel = function(contractInfo) {
            let $url = '/osd01/d/item/' + contractInfo.rowsId;

            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    $api.get($url, function(res) {
                        if (res.success) {
                            message.showSuccess('削除しました。');
                            // 出金情報一覧の取得処理
                            $scope.searchList();
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.searchForm').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 契約年月選択
                    contractYm: {
                        identifier: 'contractYm',
                        rules: [
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '契約年月'),
                            },
                        ],
                    },
                }, // fields end
            });
        };
    });

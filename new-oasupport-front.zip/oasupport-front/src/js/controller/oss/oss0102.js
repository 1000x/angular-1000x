const moment = require('moment');
const swal = require('sweetalert2');
/**
 * 給与明細登録·画面コントローラ
 */
module.exports = app =>
    app.controller('ossoss0102Ctrl', function($scope, $location, $routeParams, $api, message, CONST, commonService, $timeout) {
        // 検索年月の存在チェック
        let salaryYyyymm = null;
        if (commonService.getData('ossOss0101SearchTarget') && jQuery.isPlainObject(commonService.getData('ossOss0101SearchTarget'))) {
            salaryYyyymm = commonService.getData('ossOss0101SearchTarget').salaryYyyymm;
        }
        if (!salaryYyyymm) {
            swal({
                type: 'error',
                text: '給与年月が見つかりません',
                allowOutsideClick: false,
                confirmButtonText: '給与作成一覧画面へ戻る',
            }).then(function() {
                $timeout(function() {
                    $location.path('oss0101');
                });
            });
            return false;
        }

        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.adjustList = []; //給与調整
            $scope.showAdjust = false;
            $scope.employFlg = ''; // 雇用保険FLG

            // select list
            $scope.employStatusList = CONST.EMPLOY_STATUS_LIST; // 雇用形態
            $scope.salaryTypeList = CONST.SALARY_TYPE_LIST; // 給与方式

            $scope.initData(function() {
                $timeout(function() {
                    // 初期化
                    $scope.form_check();
                    // 最大出勤日数の算出
                    $scope.calMaxWorkDays();
                });
            });
        };

        /**
         * 社員基本情報の取得
         * @param callback
         */
        $scope.initData = function(callback) {
            let paramData = {
                rowsId: $routeParams.id,
                salaryYyyymm: salaryYyyymm,
            };

            $api.post('/oss01/r/citem', paramData, function(res) {
                // 給与作成が存在していない場合
                if (res.status == '409') {
                    swal({
                        text: res.data.message,
                        type: 'error',
                        allowOutsideClick: false,
                        confirmButtonText: '給与作成一覧画面へ戻す',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('oss0101');
                        });
                    });
                    return;
                }

                if (res.success) {
                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(res.data.departmentList, 'departId', 'departNm');

                    // 社員情報
                    let employee = res.data.empleInfo;
                    // 給与明細情報作成
                    $scope.makeSalaryInfo(employee);

                    // 給与調整情報作成
                    for (let i = 0; i < res.data.adjustList.length; i++) {
                        let adjustInfo = res.data.adjustList[i];
                        $scope.adjustList.push(adjustInfo);
                        $scope.showAdjust = true;
                    }

                    //雇用保険FLG
                    $scope.employFlg = employee.employInsuranceFlg;

                    $scope.pageInfo = {};
                    // 姓名
                    if (employee.lastNmKanji || employee.fristNmKanji) {
                        $scope.pageInfo.empleNm = jQuery.trim(employee.lastNmKanji + ' ' + employee.fristNmKanji);
                    } else {
                        $scope.pageInfo.empleNm = jQuery.trim(employee.lastNmKana + ' ' + employee.fristNmKana);
                    }

                    callback();
                } else {
                    message.showError(res.data.message);
                }
            });
        };

        /**
         * 差引支給額の算出
         */
        $scope.calWithdrawalMoney = function() {
            if (!$scope.pageInfo) return 0;
            // 総支給額 - 控除額合計 + そのた調整額合計
            return $scope.pageInfo.payTotal - $scope.pageInfo.totalDeduction + $scope.pageInfo.totalOther;
        };

        /**
         * 課税支給額(合計)の算出
         */
        $scope.calPayTotalTax = function() {
            if (!$scope.pageInfo || !$scope.salaryInfo) return 0;
            // 基本給 + 職務手当 + 技術手当 + 特別手当 + 残業手当  + 通勤手当（課税）
            $scope.pageInfo.payTotalTax =
                $api.toNumeric($scope.salaryInfo.monthSalary) +
                $api.toNumeric($scope.salaryInfo.dutiesAllow) +
                $api.toNumeric($scope.salaryInfo.skillAllow) +
                $api.toNumeric($scope.salaryInfo.specialAllow) +
                $api.toNumeric($scope.salaryInfo.overtimeAllow) +
                $api.toNumeric($scope.salaryInfo.commutAllowTax);

            return $scope.pageInfo.payTotalTax;
        };

        /**
         * 非課税支給額(合計)の算出
         */
        $scope.calPayTotalNoTax = function() {
            if (!$scope.pageInfo || !$scope.salaryInfo) return 0;
            // 通勤手当（非課税）
            $scope.pageInfo.PayTotalNoTax = $api.toNumeric($scope.salaryInfo.commutAllowNotax);

            return $scope.pageInfo.PayTotalNoTax;
        };

        /**
         * 総支給額の算出
         */
        $scope.calPayTotal = function() {
            if (!$scope.pageInfo) return 0;
            // 課税支給額(合計) + 非課税支給額(合計)
            $scope.pageInfo.payTotal = $scope.pageInfo.payTotalTax + $scope.pageInfo.PayTotalNoTax;

            return $scope.pageInfo.payTotal;
        };

        /**
         * 雇用保険、所得税の算出
         */
        $scope.calPayTax = function() {
            if (!$scope.salaryInfo) return;
            if (!$scope.isValidForm()) {
                return;
            }
            let param = {
                empleId: $scope.salaryInfo.empleId,
                dependentCounts: $scope.salaryInfo.dependentCounts,
                payTotalTax: $scope.pageInfo.payTotalTax,
                payTotal: $scope.pageInfo.payTotal,
            };
            $api.post(
                '/oss01/r/paytax',
                param,
                function(res) {
                    if (res.success) {
                        // message.showSuccess("success");

                        // 雇用保険あり
                        if ($scope.employFlg == '1') {
                            $scope.salaryInfo.employInsurance = res.data.employInsurance;
                        } else {
                            $scope.salaryInfo.employInsurance = '0';
                        }

                        $scope.salaryInfo.incomeTax = res.data.incomeTax;
                    } else {
                        // message.showError("Error!");
                        $scope.salaryInfo.employInsurance = null;
                        $scope.salaryInfo.incomeTax = null;
                    }
                },
                false
            );
        };

        /**
         * 控除額(合計)の算出
         */
        $scope.calTotalDeduction = function() {
            if (!$scope.pageInfo || !$scope.salaryInfo) return 0;
            // 健康保険 + 厚生年金 + 雇用保険 + 所得税 + 住民税 + 社会保険 + 欠勤控除 + そのた控除
            $scope.pageInfo.totalDeduction =
                $api.toNumeric($scope.salaryInfo.healthInsurance) +
                $api.toNumeric($scope.salaryInfo.welfarePension) +
                $api.toNumeric($scope.salaryInfo.employInsurance) +
                $api.toNumeric($scope.salaryInfo.incomeTax) +
                $api.toNumeric($scope.salaryInfo.municipalTax) +
                $api.toNumeric($scope.salaryInfo.socialInsurance) +
                $api.toNumeric($scope.salaryInfo.absence) +
                $api.toNumeric($scope.salaryInfo.otherDeduction);

            return $scope.pageInfo.totalDeduction;
        };

        /**
         * その他調整額（合計）の算出
         */
        $scope.calTotalOther = function() {
            if (!$scope.pageInfo || !$scope.salaryInfo) return 0;
            // 年末調整還付金額 + 立替金 + その他調整
            $scope.pageInfo.totalOther = $api.toNumeric($scope.salaryInfo.otherYearEndAdjustmen) + $api.toNumeric($scope.salaryInfo.otherAdvanceMoney) + $api.toNumeric($scope.salaryInfo.otherAdjust);

            return $scope.pageInfo.totalOther;
        };

        /**
         * 最大出勤日数の算出
         */
        $scope.calMaxWorkDays = function() {
            if ($scope.salaryInfo.workFrom && $scope.salaryInfo.workTo) {
                if ($scope.isValidFields('workFrom', 'workTo')) {
                    // 最大出勤日数
                    $scope.pageInfo.maxWorkDays = moment($scope.salaryInfo.workTo).diff(moment($scope.salaryInfo.workFrom), 'days') + 1;
                    // 最大出勤時間
                    $scope.pageInfo.maxWorkTimes = $scope.pageInfo.maxWorkDays * 24;

                    $timeout(function() {
                        $scope.form_check();
                    });
                } else {
                    $scope.pageInfo.maxWorkDays = null;
                    $scope.pageInfo.maxWorkTimes = null;
                }
            } else {
                $scope.pageInfo.maxWorkDays = null;
                $scope.pageInfo.maxWorkTimes = null;
            }
        };

        /**
         * is valid fields
         */
        $scope.isValidFields = function() {
            if (arguments.length == 0) return;
            let isValid = true;
            for (let i = 0; i < arguments.length; i++) {
                if (!jQuery('.mainform').form('is valid', arguments[i])) {
                    isValid = false;
                }
            }
            return isValid;
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.mainform').form('validate form');
            return jQuery('.mainform').form('is valid');
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/oss01/c/item', $scope.salaryInfo, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * 給与明細の作成
         */
        $scope.makeSalaryInfo = function(data) {
            let startOfMonth = salaryYyyymm + '-01';
            let endOfMonth = moment(startOfMonth)
                .endOf('month')
                .format('YYYY-MM-DD');

            // 住民税編集
            let municipalTax_val = 0;
            let mm = salaryYyyymm.substring(salaryYyyymm.length - 2);
            switch (mm) {
                case '01':
                case '02':
                case '03':
                case '04':
                case '05':
                    municipalTax_val = data.taxMay; // 5
                    break;
                case '06':
                    municipalTax_val = data.taxJune; // 6
                case '07':
                case '08':
                case '09':
                case '10':
                case '11':
                case '12':
                    municipalTax_val = data.taxJuly; // 7
            }

            $scope.salaryInfo = {
                salaryYyyymm: salaryYyyymm, // 給与年月
                empleId: data.empleId, // 社員ID
                customEmpleId: data.customEmpleId, // 社員ID（カスタマイズ）
                department: data.department, // 部門ID
                employStatus: data.employStatus, // 雇用形態
                salaryType: data.salaryType, // 給与方式
                monthSalary: data.monthSalary, // 基本給
                dutiesAllow: '0', // 職務手当
                skillAllow: '0', // 技術手当
                specialAllow: '0', // 特別手当
                overtimeAllow: '0', // 残業手当
                commutAllowTax: '0', // 通勤手当（課税）
                commutAllowNotax: data.commutPrice || '0', // 通勤手当（非課税）
                dependentCounts: data.dependentCounts || '0', // 通勤手当（非課税）
                healthInsurance: '0', // TODO 健康保険
                welfarePension: '0', // TODO 厚生年金
                employInsurance: data.employInsurance, // 雇用保険
                incomeTax: data.incomeTax, // 所得税
                municipalTax: municipalTax_val, // 住民税
                socialInsurance: '0', // 社会保険
                absence: '0', // 欠勤控除
                otherDeduction: '0', // その他控除
                otherYearEndAdjustmen: '0', // そのた-年末調整還付金額
                otherAdvanceMoney: '0', // その他-立替金
                otherAdjust: '0', // そのた-調整
                workFrom: startOfMonth, // 勤務期間-FROM
                workTo: endOfMonth, // 勤務期間-TO
            };
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            let currentDate = moment().format('YYYY-MM-DD');
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 基本給
                    monthSalary: {
                        identifier: 'monthSalary',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '基本給'),
                            },
                        ],
                    },
                    // 職務手当
                    dutiesAllow: {
                        identifier: 'dutiesAllow',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '職務手当'),
                            },
                        ],
                    },
                    // 技術手当
                    skillAllow: {
                        identifier: 'skillAllow',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '技術手当'),
                            },
                        ],
                    },
                    // 特別手当
                    specialAllow: {
                        identifier: 'specialAllow',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '特別手当'),
                            },
                        ],
                    },
                    // 残業手当
                    overtimeAllow: {
                        identifier: 'overtimeAllow',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '残業手当'),
                            },
                        ],
                    },
                    // 通勤手当（課税）
                    commutAllowTax: {
                        identifier: 'commutAllowTax',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '通勤手当（課税）'),
                            },
                        ],
                    },
                    // 通勤手当（非課税）
                    commutAllowNotax: {
                        identifier: 'commutAllowNotax',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '通勤手当（非課税）'),
                            },
                        ],
                    },
                    // 健康保険
                    healthInsurance: {
                        identifier: 'healthInsurance',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '健康保険'),
                            },
                        ],
                    },
                    // 厚生年金
                    welfarePension: {
                        identifier: 'welfarePension',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '厚生年金'),
                            },
                        ],
                    },
                    // 雇用保険
                    employInsurance: {
                        identifier: 'employInsurance',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '雇用保険'),
                            },
                        ],
                    },
                    // 所得税
                    incomeTax: {
                        identifier: 'incomeTax',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '所得税'),
                            },
                        ],
                    },
                    // 住民税
                    municipalTax: {
                        identifier: 'municipalTax',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '住民税'),
                            },
                        ],
                    },
                    // 社会保険
                    socialInsurance: {
                        identifier: 'socialInsurance',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '社会保険'),
                            },
                        ],
                    },
                    // 欠勤控除
                    absence: {
                        identifier: 'absence',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '欠勤控除'),
                            },
                        ],
                    },
                    // そのた控除
                    otherDeduction: {
                        identifier: 'otherDeduction',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'そのた控除'),
                            },
                        ],
                    },
                    // そのた-年末調整還付金額
                    otherYearEndAdjustmen: {
                        identifier: 'otherYearEndAdjustmen',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '年末調整還付金額'),
                            },
                        ],
                    },
                    // そのた-立替金
                    otherAdvanceMoney: {
                        identifier: 'otherAdvanceMoney',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '立替金'),
                            },
                        ],
                    },
                    // そのた-調整
                    otherAdjust: {
                        identifier: 'otherAdjust',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'その他調整'),
                            },
                        ],
                    },
                    // 勤務開始日
                    workFrom: {
                        identifier: 'workFrom',
                        optional: true,
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '勤務開始日'),
                            },
                        ],
                    },
                    // 勤務終了日
                    workTo: {
                        identifier: 'workTo',
                        optional: true,
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '勤務終了日'),
                            },
                            {
                                type: 'greaterThan[workFrom]',
                                prompt: message.getMsgById('E_XX_FW_5024', '勤務終了日', '勤務開始日'),
                            },
                        ],
                    },
                    // 出勤日数
                    workDays: {
                        identifier: 'workDays',
                        optional: true,
                        depends: 'maxWorkDays',
                        rules: [
                            {
                                type: 'number',
                                prompt: message.getMsgById('E_XX_FW_5028', '出勤日数'),
                            },
                            {
                                type: 'lessThan[maxWorkDays]',
                                prompt: message.getMsgById('E_XX_FW_5017', '出勤日数', $scope.pageInfo.maxWorkDays),
                            },
                        ],
                    },
                    // 出勤時間(h)
                    workTimes: {
                        identifier: 'workTimes',
                        optional: true,
                        depends: 'maxWorkTimes',
                        rules: [
                            {
                                type: 'number',
                                prompt: message.getMsgById('E_XX_FW_5028', '出勤時間(h)'),
                            },
                            {
                                type: 'lessThan[maxWorkTimes]',
                                prompt: message.getMsgById('E_XX_FW_5017', '出勤時間(h)', $scope.pageInfo.maxWorkTimes),
                            },
                        ],
                    },
                    // 欠勤時間(h)
                    absenceTimes: {
                        identifier: 'absenceTimes',
                        optional: true,
                        depends: 'maxWorkTimes',
                        rules: [
                            {
                                type: 'number',
                                prompt: message.getMsgById('E_XX_FW_5028', '欠勤時間(h)'),
                            },
                            {
                                type: 'lessThan[maxWorkTimes]',
                                prompt: message.getMsgById('E_XX_FW_5017', '欠勤時間(h)', $scope.pageInfo.maxWorkTimes),
                            },
                        ],
                    },
                    // 所定時間外出勤時間(h)
                    overTimes: {
                        identifier: 'overTimes',
                        optional: true,
                        depends: 'maxWorkTimes',
                        rules: [
                            {
                                type: 'number',
                                prompt: message.getMsgById('E_XX_FW_5028', '所定時間外出勤時間(h)'),
                            },
                            {
                                type: 'lessThan[maxWorkTimes]',
                                prompt: message.getMsgById('E_XX_FW_5017', '所定時間外出勤時間(h)', $scope.pageInfo.maxWorkTimes),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

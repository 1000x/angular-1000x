/**
 * error404
 */
module.exports = app =>
    app.controller('errorerror404Ctrl', function($scope) {
        /**
         * 初期化
         */
        $scope.init = function() {};
    });

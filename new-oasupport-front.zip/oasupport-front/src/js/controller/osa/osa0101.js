/**
 * ログイン画面コントローラ
 */
module.exports = app =>
    app.controller('osaosa0101Ctrl', function($scope, $timeout, $auth, message, $session, CONST) {
        /**
         * 画面初期化
         */
        $scope.init = function() {
            $scope.user = {
                username: $session.USR_ID || '',
                password: '',
                totp_key: '',
                backup_key: '',
                email: '',
                oneTimeCodeSt: CONST.ONE_TIME_CODE_ST.off,
            };

            $scope.ONE_TIME_CODE_ST = CONST.ONE_TIME_CODE_ST;

            //
            $scope.showBackupkeyFlg = false;

            //初期化
            $timeout(function() {
                $scope.login_form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidLoginForm = function() {
            return jQuery('.login-form').form('validate form');
        };

        $scope.isValidTotpKeyForm = function() {
            return jQuery('.totpkey-form').form('validate form');
        };

        $scope.isValidBackupKeyForm = function() {
            return jQuery('.backupkey-form').form('validate form');
        };

        /**
         * ログイン処理
         */
        $scope.signin = function() {
            if ($scope.isValidLoginForm()) {
                $auth.checkAuthority($scope.user.username, $scope.user.password).then(
                    function(result) {
                        if (CONST.ONE_TIME_CODE_ST.on == result.oneTimeCodeSt) {
                            $scope.user.oneTimeCodeSt = result.oneTimeCodeSt;
                            $scope.user.email = result.email;
                            $timeout(function() {
                                $scope.totpkey_form_check();
                            });
                        } else {
                            $auth.login($scope.user.username, $scope.user.password, '', '', $scope.user.remember);
                        }
                    },
                    function(errMsg) {
                        message.showError(errMsg);
                    }
                );
            }
            return false;
        };

        /**
         * showBackupkey
         */
        $scope.showBackupkey = function() {
            $scope.showBackupkeyFlg = true;
            $timeout(function() {
                $scope.backupkey_form_check();
            });
        };

        /**
         * ログイン処理（totp_key）
         */
        $scope.signinWithTotpKey = function() {
            if ($scope.isValidTotpKeyForm()) {
                $auth.login($scope.user.username, $scope.user.password, $scope.user.totp_key, '', $scope.user.remember);
            }
            return false;
        };

        /**
         * ログイン処理（backup_key）
         */
        $scope.signinWithBackupKey = function() {
            if ($scope.isValidBackupKeyForm()) {
                $auth.login($scope.user.username, $scope.user.password, '', $scope.user.backup_key, $scope.user.remember);
            }
            return false;
        };

        /**
         * login form check
         */
        $scope.login_form_check = function(callback) {
            jQuery('.login-form').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // ユーザーID
                    username: {
                        identifier: 'username',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'ユーザーID'),
                            },
                            /*{
                            type   : 'email',
                            prompt : 'メールアドレスを入力ください。'
                        }*/
                        ],
                    },
                    // 密码
                    password: {
                        identifier: 'password',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'パスワード'),
                            },
                        ],
                    },
                },
            });
        };

        /**
         * totpkey form check
         */
        $scope.totpkey_form_check = function(callback) {
            jQuery('.totpkey-form').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // ユーザーID
                    totp_key: {
                        identifier: 'totp_key',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5023', '認証コード'),
                            },
                        ],
                    },
                },
            });
        };

        /**
         * backupkey form check
         */
        $scope.backupkey_form_check = function(callback) {
            jQuery('.backupkey-form').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // ユーザーID
                    totp_key: {
                        identifier: 'backup_key',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5023', 'スクラッチ認証コード'),
                            },
                        ],
                    },
                },
            });
        };
    });

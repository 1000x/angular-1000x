module.exports = app => {
    // error
    require('./error/error404')(app);
    // hom
    require('./hom/hom0101')(app);
    // omt
    require('./omt/omt01/omt0101')(app);
    require('./omt/omt02/omt0201')(app);
    require('./omt/omt02/omt0202')(app);
    require('./omt/omt02/omt0203')(app);
    require('./omt/omt03/omt0301')(app);
    require('./omt/omt04/omt0401')(app);
    require('./omt/omt04/omt0402')(app);
    require('./omt/omt04/omt0403')(app);
    // osa
    require('./osa/osa0101')(app);
    require('./osa/osa0201')(app);
    require('./osa/osa0210')(app);
    require('./osa/osa0301')(app);
    require('./osa/osa0302')(app);
    require('./osa/osa0303')(app);
    // osd
    require('./osd/osd0101')(app);
    require('./osd/osd0102')(app);
    require('./osd/osd0103')(app);
    require('./osd/osd0104')(app);
    // ose
    require('./ose/ose0101')(app);
    require('./ose/ose0102')(app);
    require('./ose/ose0103')(app);
    // oso
    require('./oso/oso0101')(app);
    require('./oso/oso0102')(app);
    require('./oso/oso0103')(app);
    require('./oso/oso0104')(app);
    // oss
    require('./oss/oss0101')(app);
    require('./oss/oss0102')(app);
    require('./oss/oss0103')(app);
    require('./oss/oss0104')(app);
    require('./oss/oss0201')(app);
    require('./oss/oss0301')(app);
    require('./oss/oss0302')(app);
    // ost
    require('./ost/ost0101')(app);
    require('./ost/ost0102')(app);
    require('./ost/ost0103')(app);
    // osu
    require('./osu/osu0101')(app);
    require('./osu/osu0102')(app);
    require('./osu/osu0103')(app);
    require('./osu/osu0301')(app);
    // osw
    require('./osw/osw0101')(app);
    require('./osw/osw0102')(app);
    require('./osw/osw0103')(app);
    // sla
    require('./sla/sla01/sla0101')(app);
    require('./sla/sla01/sla0102')(app);
    require('./sla/sla01/sla0103')(app);
    require('./sla/sla02/sla0201')(app);
    require('./sla/sla02/sla0202')(app);
    require('./sla/sla02/sla0203')(app);
    require('./sla/sla03/sla0301')(app);
    require('./sla/sla03/sla0302')(app);
    // z99
    require('./z99/menu')(app);
    require('./z99/mobile_menu')(app);
    require('./z99/navbar')(app);
};

const swal = require('sweetalert2');
/**
 * 取引先情報更新·画面コントローラ
 */
module.exports = app =>
    app.controller('oseose0102Ctrl', function($scope, $timeout, $api, message, CONST, commonService) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.company = {};
            $scope.company.banks = [{}];
            $scope.company.corporationNo = ''; //得意先会社法人等番号
            $scope.company.customerCompNm = ''; //得意先会社正式名称
            $scope.company.customerCompEnNm = ''; //得意先会社名称(英字)
            $scope.company.agreementFlg = '0'; //基本契約有無
            $scope.company.post = ''; //郵便番号
            $scope.company.address = ''; //所在地
            $scope.company.registerDt = ''; //設立年月日
            $scope.company.totalCapital = ''; //資本金
            $scope.company.tel = ''; //連絡電話
            $scope.company.email = ''; //連絡メールアドレス
            $scope.company.homepage = ''; //ホームページ

            $scope.tabIndex = 0;
            // $scope.company.banks=[{
            //     bankCd:"001",//金融機関コード
            //     bankNm:"みずほ銀行",//金融機関名称
            //     depositType:"1",//預金種類
            //     bankchCd:"009",//支店コード
            //     bankchKanji:"上野支店",//支店名（漢字）
            //     bankchKana:"ウエノ",//支店名（カナ）
            //     accountCd:"1234567",//口座番号
            //     accountNm:"創点株",//口座名義（漢字）
            //     accountNmKana:"ソウテン（カ１"//口座名義（カナ）
            // }];

            $scope.company.banks = [
                {
                    bankCd: '', //金融機関コード
                    bankNm: '', //金融機関名称
                    depositType: '', //預金種類
                    bankchCd: '', //支店コード
                    bankchKanji: '', //支店名（漢字）
                    bankchKana: '', //支店名（カナ）
                    accountCd: '', //口座番号
                    accountNm: '', //口座名義（漢字）
                    accountNmKana: '', //口座名義（カナ）
                },
            ];

            //預金種類
            $scope.depositTypeList = CONST.DEPOSIT_TYPE_LIST;

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            //return jQuery(".companyform").form('validate form');

            $scope.detailInValidList = [];

            // form valid : updates UI
            jQuery('.bankForm').form('validate form');
            jQuery('.companyform').form('validate form');

            if (jQuery('.companyform').form('is valid') && $scope.detailInValidList.length > 0) {
                let inValidFormIndex;
                if ($.inArray($scope.tabIndex, $scope.detailInValidList) != -1) {
                    inValidFormIndex = $scope.tabIndex;
                } else {
                    inValidFormIndex = $scope.detailInValidList[0];
                    $scope.tabIndex = inValidFormIndex;
                }
                let $errorField = $('.bankForm')
                    .eq(inValidFormIndex)
                    .find('.field.error')
                    .eq(0);
                $errorField.focus();
                $('html,body').animate(
                    {
                        scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                    },
                    200
                );

                return false;
            }
            return jQuery('.companyform').form('is valid');
        };

        /**
         * bankAdd
         */
        $scope.bankAdd = function() {
            $scope.company.banks.push({});

            $scope.tabIndex = $scope.company.banks.length - 1;

            $timeout(function() {
                $('.bank-menu').accordion('open', $scope.company.banks.length - 1);
                $scope.bankFormCheck($scope.tabIndex);
            });
        };

        /**
         * bankReset
         */
        /*    $scope.bankReset = function(index) {
        $scope.company.banks[index]={};
        //return false;
        $timeout(function(){
            $(".bank-menu").accordion("open" , index);
        });
    };
*/
        /**
         * bankDel
         */
        $scope.bankDel = function(index) {
            swal({
                text: '該当銀行情報を削除してよろしいですか？',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    $scope.company.banks.splice(index, 1);
                    $timeout(function() {
                        $('.bank-menu').accordion('open', index - 1);
                    });
                }
            });
        };

        /**
         * 所在地検索
         */
        $scope.getAddress = function(postCd) {
            if (!postCd) {
                $('input[name=postCd]').focusout();
                return;
            }
            commonService.getAddrByPostCd(postCd, function(address) {
                $scope.company.address = address;
            });
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/ose01/c/item', $scope.company, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.companyform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            if ($scope.company.banks) {
                for (let i = 0; i < $scope.company.banks.length; i++) {
                    $scope.bankFormCheck(i);
                }
            }
            jQuery('.companyform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //得意先会社正式名称
                    customerCompNm: {
                        identifier: 'customerCompNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '得意先会社正式名称'),
                            },
                            {
                                type: 'maxLength[100]',
                                prompt: message.getMsgById('E_XX_FW_5018', '得意先会社正式名称', '100'),
                            },
                        ],
                    },
                    //得意先会社名称(英字)
                    customerCompEnNm: {
                        identifier: 'customerCompEnNm',
                        rules: [
                            {
                                type: 'maxLength[100]',
                                prompt: message.getMsgById('E_XX_FW_5018', '得意先会社名称(英字)', '100'),
                            },
                        ],
                    },
                    //郵便番号
                    post: {
                        identifier: 'post',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '郵便番号'),
                            },
                            {
                                type: 'maxLength[8]',
                                prompt: message.getMsgById('E_XX_FW_5018', '郵便番号', '8'),
                            },
                        ],
                    },
                    //所在地
                    address: {
                        identifier: 'address',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '所在地'),
                            },
                            {
                                type: 'maxLength[100]',
                                prompt: message.getMsgById('E_XX_FW_5018', '所在地', '100'),
                            },
                        ],
                    },
                    //設立年月日
                    registerDt: {
                        identifier: 'registerDt',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '設立年月日'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', '設立年月日'),
                            },
                        ],
                    },
                    //資本金
                    totalCapital: {
                        identifier: 'totalCapital',
                        rules: [
                            {
                                type: 'maxLength[15]',
                                prompt: message.getMsgById('E_XX_FW_5018', '資本金', '15'),
                            },
                        ],
                    },
                    //連絡電話
                    tel: {
                        identifier: 'tel',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '連絡電話'),
                            },
                            {
                                type: 'maxLength[30]',
                                prompt: message.getMsgById('E_XX_FW_5018', '連絡電話', '30'),
                            },
                        ],
                    },
                    //連絡メールアドレス
                    email: {
                        identifier: 'email',
                        rules: [
                            {
                                type: 'maxLength[100]',
                                prompt: message.getMsgById('E_XX_FW_5018', '連絡メールアドレス', '100'),
                            },
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', '連絡メールアドレス'),
                            },
                        ],
                    },
                    //ホームページ
                    homepage: {
                        identifier: 'homepage',
                        rules: [
                            {
                                type: 'maxLength[100]',
                                prompt: message.getMsgById('E_XX_FW_5018', 'ホームページ', '100'),
                            },
                        ],
                    },
                    //備考
                    yobi: {
                        identifier: 'yobi',
                        rules: [
                            {
                                type: 'maxLength[300]',
                                prompt: message.getMsgById('E_XX_FW_5018', '備考', '300'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };

        /**
         * bankFormCheck
         */
        $scope.bankFormCheck = function(index) {
            jQuery('.bankForm')
                .eq(index)
                .form({
                    on: 'blur',
                    inline: true,
                    keyboardShortcuts: false,
                    fields: {
                        //金融機関名称
                        bankNm: {
                            identifier: 'bankNm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '金融機関名称'),
                                },
                            ],
                        },
                        //支店名（漢字）
                        bankchKanji: {
                            identifier: 'bankchKanji',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '支店名（漢字）'),
                                },
                            ],
                        },
                        //支店コード
                        bankchCd: {
                            identifier: 'bankchCd',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '支店コード'),
                                },
                            ],
                        },
                        //預金種類
                        depositType: {
                            identifier: 'depositType',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '預金種類'),
                                },
                            ],
                        },
                        //口座番号
                        accountCd: {
                            identifier: 'accountCd',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '口座番号'),
                                },
                            ],
                        },
                        //口座名義（カナ）
                        accountNmKana: {
                            identifier: 'accountNmKana',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '口座名義（カナ）'),
                                },
                            ],
                        },
                    },
                    onFailure: function() {
                        $scope.detailInValidList.push(index);
                    },
                });
        };
    });

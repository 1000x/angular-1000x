/**
 * 請求情報作成·画面コントローラ
 */
module.exports = app =>
    app.controller('osooso0101Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 請求作成用の契約情報一覧取得処理
            $scope.searchList();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };
        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                //"contractYm":         moment().format("YYYY-MM"),  // 検索用年月
                contractYm: '', // 検索用年月
                createStatus: '', // 請求作成状態
                //"createStatus":     "1",                         // 請求作成状態
            };

            $scope.searchText = ''; // データ絞り込み用
            // ソート
            $scope.sort = {};

            $scope.contractList = [];

            // select list
            $scope.contractTypeList = CONST.CONTRACT_TYPE_LIST; // 所属リスト
            $scope.claimFlgList = CONST.CLAIM_FLG_LIST; // 請求情報作成状態リスト
            $scope.contractEndFlgList = CONST.VALID_FLG_LIST; // 契約有効・無効リスト
        };

        /**
         * 請求作成用の契約情報一覧取得処理
         */
        $scope.searchList = function() {
            $api.post('/oso01/r/clist', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.contractList = [];
                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(data.contractorCompList, 'corporationCompId', 'customerCompNm');
                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');
                    // 銀行リスト
                    $scope.bankList = commonService.makeArrToDroplist(data.bankList, 'bankId', 'bankNm');

                    for (let i = 0; i < data.claimCreateList.length; i++) {
                        let info = data.claimCreateList[i];
                        info.toggleCheckFlg = true;
                        info.expand = false;
                        // ソート
                        info.sort = {};
                        // 請求先会社名称
                        info.contractorCompNm = $scope.contractorCompList[info.contractorCompId];
                        // 担当者部門名称
                        info.picDepartNm = $scope.departmentList[info.picDepartId];
                        // 支払先名称
                        info.payeeNm = $scope.bankList[info.payeeId];
                        // 支払期限
                        info.payDeadline_disp = $scope.makePayDeadline(info);
                        // 契約詳細情報
                        for (let j = 0; j < info.details.length; j++) {
                            info.details[j].checked = info.toggleCheckFlg;
                        }
                        $scope.contractList.push(info);
                    }
                } else {
                    $scope.contractList = [];
                }
            });
        };

        /**
         * 支払期限の編集
         */
        $scope.makePayDeadline = function(contractInfo) {
            if (!contractInfo.payDeadlineMonthFlg) return '';
            let payDeadLine = CONST.PAY_DEADLINE_LIST[contractInfo.payDeadlineMonthFlg] + ' ';
            // 月末の場合
            if (contractInfo.payDeadlineDayFlg == '1') {
                payDeadLine += '月末';
            } else {
                payDeadLine += contractInfo.payDeadlineDay + '日';
            }
            return payDeadLine;
        };

        /**
         * sort by
         */
        $scope.sortBy = function(sort, target) {
            sort.target = target;
            sort.reverse = !sort.reverse;
        };

        /**
         * sorting
         */
        $scope.sorting = function(sort, target) {
            return {
                sorting: sort.target != target,
                sorting_asc: sort.target == target && !sort.reverse,
                sorting_desc: sort.target == target && sort.reverse,
            };
        };

        /**
         * 契約詳細情報checkbox
         * @param contractInfo
         */
        $scope.toggle_check = function(contractInfo) {
            contractInfo.toggleCheckFlg = !contractInfo.toggleCheckFlg;
            for (let i = 0; i < contractInfo.details.length; i++) {
                contractInfo.details[i].checked = contractInfo.toggleCheckFlg;
            }
        };

        /**
         * 請求作成処理
         * @param contractInfo
         */
        /*$scope.createClaimInfo = function(contractInfo) {
        // checked item
        let rowsIdList = [];
        for (let i = 0; i < contractInfo.details.length; i++) {
            if (contractInfo.details[i].checked) {
                rowsIdList.push(contractInfo.details[i].rowsId);
            }
        }
        if (rowsIdList.length == 0) {
            message.showError("請求作成対象を選択ください。").then(function(isConfirm) {
                $timeout(function() {
                    contractInfo.expand = true;
                });
            });
            return;
        }

        $timeout(function() {
            $location.path("oso0102/" + contractInfo.rowsId);
        });
    };*/

        $scope.form_check = function() {
            jQuery('.searchform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 契約年月選択
                    contractYm: {
                        identifier: 'contractYm',
                        rules: [
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5019', '契約年月'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

*  install<br/>
     `npm install`   

*  start server<br/>
     `npm run server`

*  build<br/>
     `npm run build`
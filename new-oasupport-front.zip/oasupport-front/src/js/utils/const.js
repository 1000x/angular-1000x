﻿const angular = require('angular');
/**
 * app.consts
 */
module.exports = angular.module('app.consts', []).constant('CONST', {
    /******************* COMMON_START *******************/
    // token key
    TOKEN_KEY: 'managerTokenKey',
    REFRESH_TOKEN_KEY: 'managerRefreshTokenKey',
    // login user key
    LOGIN_USER_KEY: 'managerLoginUserKey',
    // CLIENT_ID
    CLIENT_ID: 'istart',
    // CLIENT_SECRET
    CLIENT_SECRET: 'istart',
    // 消費税
    TAX: 0.08,
    // PERMISSION_KEY
    PERMISSION_KEY: '_SMARTIT_SYSTEM_PERMISSION_KEY',
    /******************** COMMON_END ********************/

    /******************* USER_TYPE_START *******************/
    USER_TYPE: {
        login_user: '1',
    },
    /******************* USER_TYPE_END *******************/

    /******************* PAGE_AUTHORITY_START *******************/
    PAGE_AUTHORITY: {
        editable: '1',
        readonly: '2',
        no_access: '3',
    },
    /******************* PAGE_AUTHORITY_END *******************/

    /******************* PAGE_AUTHORITY_START *******************/
    ONE_TIME_CODE_ST: {
        on: '1',
        off: '0',
    },
    /******************* PAGE_AUTHORITY_END *******************/

    /******************* select list *******************/
    // 性別リスト
    SEX_LIST: {
        '1': '男',
        '2': '女',
    },
    // 配偶有無リスト
    SPOUSEFLG_LIST: {
        '1': '有',
        '2': '無',
    },
    // 給与方式リスト
    SALARYTYPE_LIST: {
        '1': '月給',
        '2': '時給',
        '3': '日給',
    },
    // 賞与夏有無リスト
    BONUS_SUMMER_LIST: {
        '1': '有',
        '2': '無',
    },
    // 賞与冬有無リスト
    BONUS_WINTER_LIST: {
        '1': '有',
        '2': '無',
    },
    // 通勤手段リスト
    COMMUT_ALLOWANCE_LIST: {
        '1': '電車',
        '2': 'バス',
        '3': '電車＋バス',
        '4': '自動車',
        '5': '自転車',
        '6': '徒歩',
    },
    // 在籍リスト
    LEAVE_FLG_LIST: {
        '1': '在職中',
        '2': '退職',
    },
    // ビザ種類リスト
    RESIDENT_STATUS_LIST: {
        '1': '技術・人文知識・国際業務',
        '2': '技術',
        '3': '高度専門職',
        '4': '永住者',
        '5': '企業内転勤',
        '6': '経営・管理',
        '7': '日本籍',
        '8': 'その他',
    },
    // 口座リスト
    DEPOSIT_TYPE_LIST: {
        '1': '普通',
        '2': '当座',
        '3': '定期',
        '4': 'その他',
    },
    // 契約区分リスト
    CONTRACT_TYPE_LIST: {
        '1': '自社員',
        '2': '協力会社社員',
    },
    // 健康保険FLGリスト
    HEALTH_INSURANCE_FLG_LIST: {
        '1': '有',
        '2': '無',
    },
    // 介護保険FLGリスト
    NURS_INSURANCE_FLG_LIST: {
        '1': '有',
        '2': '無',
    },
    // 厚生年金保険FLGリスト
    WELFARE_INSURANCE_FLG_LIST: {
        '1': '有',
        '2': '無',
    },
    // 雇用保険FLGリスト
    EMPLOY_INSURANCE_FLG_LIST: {
        '1': '有',
        '2': '無',
    },
    // 有効・無効リスト
    VALID_FLG_LIST: {
        '1': '有効',
        '2': '無効',
    },
    // 支払期限
    PAY_DEADLINE_LIST: {
        '1': '翌月',
        '2': '翌々月',
        '3': '翌々々月',
    },
    // 契約区分
    //CONTRACT_TYPE_LIST: {
    //    "1": "自社員",
    //    "2": "協力会社社員",
    //},
    // 支払期限(月)
    PAY_DEADLINE_MONTH_LIST: {
        '1': '翌月',
        '2': '翌々月',
        '3': '翌々々月',
    },
    // 支払期限(日)
    PAY_DEADLINE_DAY_LIST: {
        '1': '月末',
        '2': 'その他',
    },
    // 請求情報作成状態リスト
    CLAIM_FLG_LIST: {
        '1': '未作成',
        '2': '作成済み',
    },
    // 請求状態リスト
    CLAIM_STATUS_LIST: {
        '1': '未処理',
        '2': '処理済',
    },
    // 消費税区分リスト
    TAX_LIST: {
        '1': '税込',
        '2': '税抜',
    },
    // 入金状態リスト
    PAY_STATUS_LIST: {
        '1': '未入金',
        '2': '入金済み',
        '3': '削除',
    },
    // 出金状態リスト
    WITHDRAWAL_TYPE_LIST: {
        '1': '未出金',
        '2': '出金済み',
        '3': '削除',
    },
    // 雇用形態リスト
    EMPLOY_STATUS_LIST: {
        '1': '正社員',
        '2': '派遣社員',
        '3': '個人事業主',
        '4': 'アルバイト',
        '9': 'そのた',
    },
    // 給与方式リスト
    SALARY_TYPE_LIST: {
        '1': '月給',
        '2': '時給',
        '3': '日給',
    },
    // 支払状態リスト
    PAY_FLG_LIST: {
        '1': '未支払',
        '2': '支払済み',
    },
    // 給与情報作成状態リスト
    SALARY_CREATE_STATUS_LIST: {
        '1': '未作成',
        '2': '作成済',
    },
    // 給与支払状態リスト
    SALARY_PAY_FLG_LIST: {
        '1': '未支払',
        '2': '支払済',
    },
    // 給与明細送信状態リスト
    SALARY_EMAIL_FLG_LIST: {
        '1': '未発送',
        '2': '発送済',
    },
    // メールSSLリスト
    MAIL_SSL_LIST: {
        '1': '接続の保護なし',
        '2': 'STARTTLS',
        '3': 'SSL/TLS',
    },
    // メール認証方式リスト
    MAIL_AUTHENTICATION_LIST: {
        '1': '認証なし',
        '2': '通常のパスワード認証',
        '3': '暗号化されたパスワード認証',
        '4': 'Kerberos / GSSAPI',
        '5': 'NTLM',
        '6': 'OAuth2',
    },
    // ユーザー状態リスト
    USER_STATUS_LIST: {
        '1': '利用中',
        '2': '停止中',
    },
    // メニュー権限
    PAGE_AUTHORITY_LIST: {
        '1': '編集可',
        '2': '照会',
        '3': 'アクセスなし',
    },
    // 稼働状況
    OPERATION_STATUS_LIST: {
        '1': '稼働空きます',
        '2': '対応不可',
        '3': '応相談',
    },
    // 所属
    AFFILIATION_LIST: {
        '1': '自社社員',
        '2': '協力会社社員',
        '3': 'フリーランス',
    },
    // 国籍
    NATIONALITY_LIST: {
        '1': '日本籍',
        '2': '中国籍',
        '3': 'その他国籍',
    },
    // 並行有無
    PARALLEL_FLG_LIST: {
        '1': '並行あり',
        '2': '並行なし',
    },
    // 公開状況
    OPEN_STATUS_LIST: {
        '1': '公開',
        '2': '非公開',
    },
    // デフォルトメールポート
    DEFAULT_MAIL_PORT_LIST: {
        '587': 587,
        '465': 465,
        '25': 25,
    },
    /******************* select list *******************/
});

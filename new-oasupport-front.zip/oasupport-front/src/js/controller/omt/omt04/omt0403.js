const swal = require('sweetalert2');
/**
 * 自社部門更新·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt04omt0403Ctrl', function($scope, $location, $routeParams, $timeout, $api, message) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.bank = {};

            let $url = '/omt04/r/item/' + $routeParams.id;

            // 自社部門情報の取得
            $api.get($url, function(res) {
                // 自社部門情報が存在していない場合
                if (res.status == '409') {
                    swal({
                        text: res.data.message,
                        type: 'error',
                        allowOutsideClick: false,
                        confirmButtonText: '部門情報一覧画面へ戻す',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('omt0401');
                        });
                    });
                    return;
                }
                if (res.success) {
                    $scope.depart = res.data.departmentInfo;
                }
            });

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.departform').form('validate form');
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            let $url = '/omt04/u/item';
            if ($scope.isValidForm()) {
                $api.post($url, $scope.depart, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.departform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.departform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //部門名称
                    departNm: {
                        identifier: 'departNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '部門名称'),
                            },
                        ],
                    },
                },
                onSuccess: function() {
                    if (callback) callback();
                },
            });
        };
    });

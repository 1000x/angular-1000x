const swal = require('sweetalert2');
/**
 * アカウント更新画面コントローラ
 */
module.exports = app =>
    app.controller('osaosa0303Ctrl', function($scope, $routeParams, $timeout, $api, message, CONST, commonService) {
        /**
         * 画面初期化
         */
        $scope.init = function() {
            $scope.account = {};

            // データ取得
            $api.get('/osa03/r/item/' + $routeParams.id, function(res) {
                if (res.success) {
                    // アカウント情報
                    $scope.account = res.data.account;
                    // 権限リスト
                    $scope.authorityList = res.data.authorityList;
                } else {
                    message.showError(res.data.message);
                }
            });

            // select list
            $scope.pageAuthorityList = CONST.PAGE_AUTHORITY_LIST;
            $scope.userStatusList = CONST.USER_STATUS_LIST;

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.mainform').form('validate form');
            return jQuery('.mainform').form('is valid');
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                swal({
                    text: '更新してよろしいですか。',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(
                    function(isConfirm) {
                        if (isConfirm) {
                            // edit
                            $scope.account.authorityList = [];
                            for (let i = 0; i < $scope.authorityList.length; i++) {
                                $scope.account.authorityList.push({
                                    funcId: $scope.authorityList[i].funcId,
                                    authority: $scope.authorityList[i].authority,
                                });
                            }
                            $api.post('/osa03/u/item', $scope.account, function(res) {
                                if (res.success) {
                                    message.showSuccess('success');
                                } else {
                                    message.showError(res.data.message);
                                    // show error details
                                    let errDetails = res.data.details;
                                    if (errDetails) {
                                        for (let i = 0; i < errDetails.length; i++) {
                                            jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                                        }
                                    }
                                }
                            });
                        }
                    },
                    function(dismiss) {
                        // 処理なし
                    }
                );
            }
        };

        /**
         * 郵便番号より、住所の取得処理
         * @param post
         */
        $scope.getAddress = function(post) {
            commonService.getAddrByPostCd(post, function(address) {
                $scope.account.address = address;
            });
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // アカウントID
                    usrId: {
                        identifier: 'usrId',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'アカウントID'),
                            },
                        ],
                    },
                    // 名前
                    usrNm: {
                        identifier: 'usrNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '名前'),
                            },
                        ],
                    },
                    // アカウント有効期限
                    usrExpireDt: {
                        identifier: 'usrExpireDt',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'アカウント有効期限'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', 'アカウント有効期限'),
                            },
                            //{
                            //    type   : 'greaterThan[' + moment().format("YYYY-MM-DD") + ']',
                            //    prompt : message.getMsgById("E_XX_FW_5015", "アカウント有効期限")
                            //},
                        ],
                    },
                    // メールアドレス
                    email: {
                        identifier: 'email',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'メールアドレス'),
                            },
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', 'メールアドレス'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

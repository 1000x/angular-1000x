/**
 * storage.js
 */
module.exports = (() => {
    const EXPIRE_SUFFIX = '_EXPIRE_';

    return {
        /**
         * hasItem
         * @param {string} key
         */
        hasItem: function(key) {
            const expire = localStorage.getItem(key + EXPIRE_SUFFIX);
            if (!expire) {
                return !!sessionStorage.getItem(key);
            }
            if (expire >= new Date().getTime()) {
                return !!localStorage.getItem(key);
            }
            localStorage.removeItem(key);
            localStorage.removeItem(key + EXPIRE_SUFFIX);
            return false;
        },

        /**
         * getItem
         * @param {string} key
         */
        getItem: function(key) {
            const expire = localStorage.getItem(key + EXPIRE_SUFFIX);
            if (!expire) {
                const data = sessionStorage.getItem(key);
                return data ? JSON.parse(data) : null;
            }
            if (expire >= new Date().getTime()) {
                return JSON.parse(localStorage.getItem(key));
            }
            localStorage.removeItem(key);
            localStorage.removeItem(key + EXPIRE_SUFFIX);
            return null;
        },

        /**
         * setItem
         * @param {string} key
         * @param {object} data
         * @param {number} expire ミリ秒
         */
        setItem: function(key, data, expire) {
            if (!Number(expire) || expire <= 0) {
                sessionStorage.setItem(key, JSON.stringify(data));
            } else {
                localStorage.setItem(key, JSON.stringify(data));
                localStorage.setItem(key + EXPIRE_SUFFIX, new Date().getTime() + expire);
            }
        },

        /**
         * removeItem
         * @param {string} key
         */
        removeItem: function(key) {
            const expire = localStorage.getItem(key + EXPIRE_SUFFIX);
            if (!expire) {
                sessionStorage.removeItem(key);
            } else {
                localStorage.removeItem(key);
                localStorage.removeItem(key + EXPIRE_SUFFIX);
            }
        },
    };
})();

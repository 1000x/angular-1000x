/**
 * ログイン画面コントローラ
 */
module.exports = app =>
    app.controller('osaosa0201Ctrl', function($scope, $timeout, $api, message) {
        /**
         * 画面初期化
         */
        $scope.init = function() {
            $scope.account = {};
            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.passwordResetForm').form('validate form');
        };

        /**
         * ログイン処理
         */
        $scope.pwdChange = function() {
            if ($scope.isValidForm()) {
                $api.post('/osa02/u/item', $scope.account, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                    }
                });
            }
        };

        /**
         * パスワード変更処理
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/osa02/u/item', $scope.account, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.passwordResetForm').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //旧パスワード
                    oldPwd: {
                        identifier: 'oldPwd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '旧パスワード'),
                            },
                            {
                                type: 'minLength[6]',
                                prompt: message.getMsgById('E_XX_FW_5020', '旧パスワード', '6'),
                            },
                        ],
                    },
                    //新パスワード
                    pwd: {
                        identifier: 'pwd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '新パスワード'),
                            },
                            {
                                type: 'minLength[6]',
                                prompt: message.getMsgById('E_XX_FW_5020', '新パスワード', '6'),
                            },
                        ],
                    },
                    //確認パスワード
                    pwdConfirm: {
                        identifier: 'pwdConfirm',
                        rules: [
                            {
                                type: 'match[pwd]',
                                prompt: message.getMsgById('E_XX_FW_5021'),
                            },
                        ],
                    },
                },
            });
        };
    });

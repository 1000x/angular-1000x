const swal = require('sweetalert2');
/**
 * 出金情報更新·画面コントローラ
 */
module.exports = app =>
    app.controller('oswosw0103Ctrl', function($scope, $location, $routeParams, $timeout, $api, message, commonService) {
        /**
         * 初期化
         */
        $scope.init = function() {
            //初期データ取得
            $scope.initData();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * 初期データ取得
         */
        $scope.initData = function() {
            $api.get('/osw01/r/item/' + $routeParams.id, function(res) {
                if (res.success) {
                    $scope.withdrawal = res.data.withdrawalInfo;
                    // 銀行リスト
                    //$scope.bankList = commonService.makeBankDroplist(res.data.withdrawalBankList, "bankId", "bankNm", "bankchKanji", "accountCd", "accountNmKana");
                    $scope.tmpBankList = [];

                    for (let i = 0; i < res.data.withdrawalBankList.length; i++) {
                        let info = res.data.withdrawalBankList[i];
                        if (info['corporationCompId'] == $scope.withdrawal['corporationCompId']) {
                            $scope.tmpBankList.push(info);
                        }
                    }

                    $scope.bankList = commonService.makeBankDroplist($scope.tmpBankList, 'bankId', 'bankNm', 'bankchKanji', 'accountCd', 'accountNmKana');

                    //
                    $scope.allBankList = res.data.withdrawalBankList;

                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(res.data.contractorCompList, 'corporationCompId', 'customerCompNm');
                } else {
                    swal({
                        type: 'error',
                        text: res.data.message,
                        allowOutsideClick: false,
                        confirmButtonText: '出金一覧画面へ戻る',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('osw0101');
                        });
                    });
                }
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.withdrawalUpdateform').form('validate form');
        };

        /**
         * withdrawal bank select change
         */
        $scope.withdrawalBankSelect = function(withdrawal) {
            $scope.bankList = {};
            $scope.tmpBankList = [];

            for (let i = 0; i < $scope.allBankList.length; i++) {
                let info = $scope.allBankList[i];
                if (info['corporationCompId'] == withdrawal['corporationCompId']) {
                    $scope.tmpBankList.push(info);
                }
            }

            $scope.bankList = commonService.makeBankDroplist($scope.tmpBankList, 'bankId', 'bankNm', 'bankchKanji', 'accountCd', 'accountNmKana');

            let firstKey;
            for (let key in $scope.bankList) {
                firstKey = key;
                break;
            }
            if (firstKey) {
                $scope.withdrawal.bankId = firstKey;
            } else {
                $scope.withdrawal.bankId = '';
            }
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/osw01/u/item', $scope.withdrawal, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.withdrawalUpdateform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.withdrawalUpdateform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //請求年月
                    yyyymm: {
                        identifier: 'yyyymm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求年月'),
                            },
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '請求年月'),
                            },
                        ],
                    },
                    //他社請求番号
                    claimId: {
                        identifier: 'claimId',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求番号'),
                            },
                            {
                                type: 'regExp[/^[a-zA-Z0-9-]+$/]',
                                prompt: message.getMsgById('E_XX_FW_5006', '請求番号'),
                            },
                        ],
                    },
                    //請求元会社名称
                    corporationCompId: {
                        identifier: 'corporationCompId',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求元会社名称'),
                            },
                        ],
                    },
                    //摘要
                    summary: {
                        identifier: 'summary',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '摘要'),
                            },
                        ],
                    },
                    //出金金額
                    withdrawalMoney: {
                        identifier: 'withdrawalMoney',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '出金金額'),
                            },
                        ],
                    },
                    // 出金期限
                    withdrawalToYmd: {
                        identifier: 'withdrawalToYmd',
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '出金期限'),
                            },
                            //{
                            //    type   : 'greaterThan[' + moment().format("YYYY-MM-DD") + ']',
                            //    prompt : message.getMsgById("E_XX_FW_5015", "出金期限")
                            //},
                        ],
                    },
                    // 出金日
                    withdrawalYmd: {
                        identifier: 'withdrawalYmd',
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '出金日'),
                            },
                        ],
                    },
                    // 確認日
                    checkYmd: {
                        identifier: 'checkYmd',
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '確認日'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

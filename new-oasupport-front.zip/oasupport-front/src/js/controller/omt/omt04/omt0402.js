/**
 * 自社部門情報更新·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt04omt0402Ctrl', function($scope, $timeout, $api, message) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.depart = {};

            // $scope.depart.departNm = 'システム１部'; //部門
            $scope.depart.departNm = ''; //部門

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.departform').form('validate form');
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            let $url = '/omt04/c/item';
            if ($scope.isValidForm()) {
                $api.post($url, $scope.depart, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.departform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.departform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //部門名称
                    departNm: {
                        identifier: 'departNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '部門名称'),
                            },
                        ],
                    },
                },
                onSuccess: function() {
                    if (callback) callback();
                },
            });
        };
    });

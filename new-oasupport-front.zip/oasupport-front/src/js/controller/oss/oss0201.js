const moment = require('moment');
/**
 * 給与一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('ossoss0201Ctrl', function($scope, $timeout, $api, commonService, message) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 給与情報一覧の取得処理
            //$scope.searchList();

            // datatable options初期化
            // $scope.initDtOption();

            // 部門リストの取得処理
            $api.get('/oss02/r/empleList', function(res) {
                if (res.success) {
                    let data = res.data;
                    // 部門リスト
                    $scope.empleList = commonService.makeArrToDroplist(data.empleList, 'empleId', 'empleNm');
                } else {
                    $scope.empleList = {};
                }
            });

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                salaryYyyymm: moment().format('YYYY-MM'), // 検索用年月
                empleId: '',
            };

            $scope.searchText = ''; // データ絞り込み用
            // $scope.datatable = {};
            // $scope.masterCheck = false;

            $scope.empleList = {};
            //$scope.empleList = [];

            // select list
            // $scope.employStatusList = CONST.EMPLOY_STATUS_LIST;         // 雇用形態
            // $scope.salaryTypeList = CONST.SALARY_TYPE_LIST;             // 給与方式
            // $scope.salaryPayFlgList = CONST.SALARY_PAY_FLG_LIST;        // 給与支払状態
            // $scope.salaryEmailFlgList = CONST.SALARY_EMAIL_FLG_LIST;    // 送信状態
        };

        /**
         * 給与一覧の取得処理
         */
        $scope.searchList = function() {
            if (!$scope.isValidForm()) {
                return false;
            }
            $api.post('/oss01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.salaryList = [];

                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');

                    for (let i = 0; i < data.salaryList.length; i++) {
                        let info = data.salaryList[i];
                        info.checked = $scope.masterCheck;
                        // 差引支給額の算出
                        info.withdrawalMoney = $scope.calWithdrawalMoney(info);
                        $scope.salaryList.push(info);
                    }
                } else {
                    $scope.salaryList = [];
                }
            });
        };

        /**
         * 社員名の取得
         */
        $scope.getName = function(empleInfo) {
            let uName;
            // 姓名
            if (empleInfo.lastNmKanji || empleInfo.fristNmKanji) {
                uName = jQuery.trim(empleInfo.lastNmKanji + ' ' + empleInfo.fristNmKanji);
            } else {
                uName = jQuery.trim(empleInfo.lastNmKana + ' ' + empleInfo.fristNmKana);
            }
            return uName;
        };

        /**
         * 給与明細のダウンロード処理
         */
        $scope.downloadSalary = function() {
            let param = {
                salaryYyyymm: $scope.search.salaryYyyymm,
                empleId: $scope.search.empleId,
            };

            $api.post('/oss02/download/list', param, function(res) {
                if (res.success) {
                    let blob = $api.b64toBlob(res.data.fileBase64String, 'application/octet-stream');
                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, res.data.fileName);
                    } else {
                        let objectUrl = URL.createObjectURL(blob);
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = objectUrl;
                        a.download = res.data.fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.searchForm').form('validate form');
            return jQuery('.searchForm').form('is valid');
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.searchForm').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 給与年月
                    salaryYyyymm: {
                        identifier: 'salaryYyyymm',
                        rules: [
                            // {
                            //     type   : 'empty',
                            //     prompt : message.getMsgById("E_XX_FW_5003", "給与年月")
                            // },
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '給与年月'),
                            },
                        ],
                    },
                }, // fields end
            });
        };
    });

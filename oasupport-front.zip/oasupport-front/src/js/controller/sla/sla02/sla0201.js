const swal = require('sweetalert2');
/**
 * 宛先情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('slasla02sla0201Ctrl', function($scope, $api, commonService, message) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // データ初期化
            $scope.datatable = {};
            $scope.searchText = '';

            // 宛先情報一覧の取得処理
            $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();
        };

        /**
         * 宛先情報一覧の取得処理
         */
        $scope.searchList = function() {
            $scope.addressList = [];
            $api.get('/sla02/r/list', function(res) {
                if (res.success) {
                    $scope.addressList = res.data.addressList;
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [7],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * dtInstanceCallback
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * 取引先情報から一括登録
         */
        $scope.createListFromCustomer = function() {
            $api.get('/sla02/c/list', function(res) {
                if (res.success) {
                    message.showSuccess('処理成功しました。(新規件数: ' + res.data + ')');
                    if (res.data > 0) {
                        $scope.searchList();
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };

        /**
         * 宛先削除処理
         * @param rowsId
         * @param index
         */
        $scope.remove = function(rowsId, index) {
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.get('/sla02/d/item/' + rowsId, function(res) {
                            if (res.success) {
                                message.showSuccess('削除しました。');
                                $scope.addressList.splice(index, 1);
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };
    });

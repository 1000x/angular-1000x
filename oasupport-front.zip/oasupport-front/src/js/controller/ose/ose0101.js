const swal = require('sweetalert2');
/**
 * 取引先情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('oseose0101Ctrl', function($scope, $timeout, $api, commonService, message) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.corporationList = {};
            $scope.datatable = {};

            // 取引先一覧の取得処理
            $scope.getcorporationList();

            // datatable options初期化
            $scope.initDtOption();
        };

        /**
         * 取引先情報一覧の取得処理
         */
        $scope.getcorporationList = function() {
            $api.get('/ose01/r/list', function(res) {
                if (res.success) {
                    $scope.corporationList = [];
                    let data = res.data;
                    for (let i = 0; i < data.length; i++) {
                        $scope.corporationList.push(data[i]);
                    }
                    // dropdown and select trigger
                    $timeout(function() {
                        $('.btn-setting').dropdown({
                            on: 'hover',
                            duration: '100',
                        });
                    });
                } else {
                    $scope.corporationList = [];
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [0, 6],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * dtInstanceCallback
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * 取引先削除処理
         */
        $scope.corporationDel = function(corporationInfo) {
            let $url = '/ose01/d/item/' + corporationInfo.rowsId;

            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.get($url, function(res) {
                            if (res.success) {
                                message.showSuccess('削除しました。');
                                $scope.getcorporationList();
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         * 取引先情報のダウンロード処理
         */
        $scope.downloadCorporation = function() {
            let param = {};
            $api.post('/ose01/download/list', param, function(res) {
                if (res.success) {
                    let blob = $api.b64toBlob(res.data.fileBase64String, 'application/octet-stream');
                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, res.data.fileName);
                    } else {
                        let objectUrl = URL.createObjectURL(blob);
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = objectUrl;
                        a.download = res.data.fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };
    });

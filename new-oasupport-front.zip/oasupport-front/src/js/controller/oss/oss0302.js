/**
 * 給与調整登録·画面コントローラ
 */
module.exports = app =>
    app.controller('ossoss0302Ctrl', function($scope, $timeout, $api, message, commonService) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.empleList = {};

            // 調整情報
            $scope.adjust = {
                empleId: '',
            };

            // select list 初期化
            $scope.selectList();

            $scope.departmentCode = '';
            // 部門リスト
            $scope.departNm = '';
            //$scope.department();
            $scope.departmentList = {};

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * select list 初期化
         */
        $scope.selectList = function() {
            $api.get('/osu01/r/list', function(res) {
                if (res.success) {
                    let data = res.data;

                    // 社員リスト
                    $scope.userList = [];

                    $scope.empleList = data.empleList;

                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');

                    for (let i = 0; i < data.empleList.length; i++) {
                        let info = data.empleList[i];
                        // ID-姓名
                        if (info.lastNmKanji || info.fristNmKanji) {
                            info.userIdNm = jQuery.trim(info.customEmpleId + ' - ' + info.lastNmKanji + ' ' + info.fristNmKanji);
                        } else {
                            info.userIdNm = jQuery.trim(info.customEmpleId + ' - ' + info.lastNmKana + ' ' + info.fristNmKana);
                        }
                        $scope.userList.push(info);
                    }
                    $scope.userList = commonService.makeArrToDroplist($scope.userList, 'empleId', 'userIdNm');
                } else {
                    $scope.userList = [];
                }
            });
        };

        $scope.department = function($empleId) {
            let $depart_id = '';
            for (let i = 0; i < $scope.empleList.length; i++) {
                let info = $scope.empleList[i];

                if ($empleId == info.empleId) {
                    $depart_id = info.department;
                    break;
                }
            }

            $scope.departNm = $scope.departmentList[$depart_id];
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.adjustform').form('validate form');
        };
        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/oss03/c/item', $scope.adjust, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.adjustform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };
        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.adjustform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // ID-姓名
                    userIdNm: {
                        identifier: 'userIdNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '社員番号-名前'),
                            },
                        ],
                    },
                    //請求年月
                    salaryYyyymm: {
                        identifier: 'salaryYyyymm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求年月'),
                            },
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '請求年月'),
                            },
                        ],
                    },
                    //調整金額
                    adjustMoney: {
                        identifier: 'adjustMoney',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '調整金額'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

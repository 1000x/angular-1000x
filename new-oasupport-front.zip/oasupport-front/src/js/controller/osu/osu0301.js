const swal = require('sweetalert2');
/**
 * 社員登録·画面コントローラ
 */
module.exports = app =>
    app.controller('osuosu0301Ctrl', function($scope, $location, $routeParams, $api, message, CONST, $timeout) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // 社員情報
            $scope.bank = {};

            // select list
            $scope.depositTypeList = CONST.DEPOSIT_TYPE_LIST;

            let $url = '/osu03/r/item/' + $routeParams.id;

            // 社員銀行口座情報取得
            $api.get($url, function(res) {
                // 社員情報が存在していない場合
                if (res.status == '409') {
                    swal({
                        text: res.data.message,
                        type: 'error',
                        allowOutsideClick: false,
                        confirmButtonText: '社員一覧画面へ戻す',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('osu0101');
                        });
                    });
                    return;
                }

                if (res.success) {
                    $scope.bank = res.data.empleBankInfo;
                    $scope.empleInfo = res.data.empleInfo;
                    $scope.empleName = $scope.getName($scope.empleInfo);
                }
                if (!$scope.bank) {
                    $scope.bank = {
                        empleId: $routeParams.id,
                    };
                    // TODO
                    /*$scope.bank.bankNm = '三井住友銀行'; //金融機関名称50String
                $scope.bank.bankchKanji = '上野支店'; //支店名（漢字）50String
                $scope.bank.bankchKana = 'ウエノ'; //支店名（カナ）25String
                $scope.bank.bankchCd = '799'; //支店コード5String
                $scope.bank.depositType = '1'; //預金種類1String
                $scope.bank.accountCd = '1234567'; //口座番号12String
                $scope.bank.accountNm = '関俊杰'; //口座名義（漢字）20String
                $scope.bank.accountNmKana = 'セキシュンケツ'; //口座名義（カナ）20String
*/
                }
            });

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.bankForm').form('validate form');
        };

        /**
         * 更新ボタン押下
         */
        $scope.btn_update = function() {
            if ($scope.isValidForm()) {
                $api.post('/osu03/u/item', $scope.bank, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                        // rowsId
                        $scope.bank.rowsId = res.data.rowsId;
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.bankForm').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * get user name
         */
        $scope.getName = function(info) {
            if (info.lastNmKanji || info.fristNmKanji) {
                return info.lastNmKanji + ' ' + info.fristNmKanji;
            }

            return info.lastNmKana + ' ' + info.fristNmKana;
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.bankForm').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //金融機関名称
                    bankNm: {
                        identifier: 'bankNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '金融機関名称'),
                            },
                        ],
                    },
                    // 支店名（カナ）
                    bankchKana: {
                        identifier: 'bankchKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店名（カナ）'),
                            },
                        ],
                    },
                    //支店コード
                    bankchCd: {
                        identifier: 'bankchCd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支店コード'),
                            },
                        ],
                    },
                    //預金種類
                    depositType: {
                        identifier: 'depositType',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支預金種類店コード'),
                            },
                        ],
                    },
                    //口座番号
                    accountCd: {
                        identifier: 'accountCd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座番号'),
                            },
                        ],
                    },
                    //口座名義（カナ）
                    accountNmKana: {
                        identifier: 'accountNmKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '口座名義（カナ）'),
                            },
                        ],
                    },
                },
            });
        };
    });

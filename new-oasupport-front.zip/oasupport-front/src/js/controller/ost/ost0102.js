const moment = require('moment');
const swal = require('sweetalert2');
/**
 * 入金情報登録·画面コントローラ
 */
module.exports = app =>
    app.controller('ostost0102Ctrl', function($scope, $location, $routeParams, $timeout, $api, message, CONST, commonService) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // 入金情報
            $scope.pay = {};

            // select list 初期化
            $scope.initSelectList();

            // copy時、copy元データ取得
            $scope.getCopyData();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * select list 初期化
         */
        $scope.initSelectList = function() {
            // select list
            $scope.contractTypeList = CONST.CONTRACT_TYPE_LIST; // 契約区分
            $scope.payDeadlineMonthList = CONST.PAY_DEADLINE_MONTH_LIST; // 支払期限(月)

            // drop listの取得
            $api.get('/ost01/r/droplist', function(res) {
                if (res.success) {
                    // 銀行リスト
                    //$scope.bankList = commonService.makeArrToDroplist(res.data.bankList, "bankId", "bankNm");
                    $scope.bankList = commonService.makeBankDroplist(res.data.bankList, 'bankId', 'bankNm', 'bankchKanji', 'accountCd', 'accountNmKana');

                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(res.data.contractorCompList, 'corporationCompId', 'customerCompNm');
                }
            });
        };

        /**
         * copy元データ取得
         */
        $scope.getCopyData = function() {
            // パラメータにrowsidある場合
            if ($routeParams.id) {
                $api.get('/ost01/r/item/' + $routeParams.id, function(res) {
                    if (res.success) {
                        $scope.pay = res.data.payInfo;
                        // 請求年月＋１
                        $scope.pay.yyyymm = moment($scope.pay.yyyymm)
                            .add(1, 'months')
                            .format('YYYY-MM');

                        // 入金期限　＋１
                        $scope.pay.payToYmd = moment($scope.pay.payToYmd)
                            .add(1, 'months')
                            .format('YYYY-MM-DD');

                        callback();
                    } else {
                        swal({
                            type: 'error',
                            text: res.data.message,
                            allowOutsideClick: false,
                            confirmButtonText: '入金一覧画面へ戻る',
                        }).then(function() {
                            $timeout(function() {
                                $location.path('ost0101');
                            });
                        });
                    }
                });
            }
        };

        /**
         * pay bank select change
         */
        $scope.payBankSelect = function(bankid) {
            // drop listの取得
            $api.get('/ost01/r/droplist', function(res) {
                if (res.success) {
                    // 銀行リスト
                    $scope.bankList = commonService.makeArrToDroplist(res.data.bankList, 'bankId', 'bankNm');
                }
            });
        };
        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.payform').form('validate form');
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                $api.post('/ost01/c/item', $scope.pay, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.payform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.payform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //請求年月
                    yyyymm: {
                        identifier: 'yyyymm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求年月'),
                            },
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5025', '請求年月'),
                            },
                        ],
                    },
                    //請求番号
                    claimId: {
                        identifier: 'claimId',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求番号'),
                            },
                            {
                                type: 'regExp[/^[a-zA-Z0-9-]+$/]',
                                prompt: message.getMsgById('E_XX_FW_5006', '請求番号'),
                            },
                        ],
                    },
                    //請求先会社名称
                    customerCompNm: {
                        identifier: 'customerCompNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求先会社名称'),
                            },
                        ],
                    },
                    //摘要
                    summary: {
                        identifier: 'summary',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '摘要'),
                            },
                        ],
                    },
                    //入金金額
                    payMoney: {
                        identifier: 'payMoney',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '入金金額'),
                            },
                        ],
                    },
                    // 入金期限
                    payDeadline: {
                        identifier: 'payToYmd',
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '入金期限'),
                            },
                            //{
                            //    type   : 'greaterThan[' + moment().format("YYYY-MM-DD") + ']',
                            //    prompt : message.getMsgById("E_XX_FW_5015", "入金期限")
                            //},
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

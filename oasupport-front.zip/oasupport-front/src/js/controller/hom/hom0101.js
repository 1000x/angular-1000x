/**
 * 社員一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('homhom0101Ctrl', function($scope, $api) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // total
            $scope.receipts_total = 0; //入金（合計）金額
            $scope.payment_total = 0; //出金（合計）金額
            $scope.salary_total = 0; //給与（合計）金額
            $scope.incomeTax_total = 0; //所得税（合計）金額
            $scope.cost_total = 0; //費用（合計）金額
            $scope.profits_total = 0; //概算（合計）金額

            $scope.money_list = [];

            // init data
            $scope.initData();
        };
        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                fromYyyymm: '',
                toYyyymm: '',
            };

            // 概算金額リストの取得処理
            $scope.searchList();

            //$scope.money_list={};
        };
        /**
         * 概算金額リストの取得
         */

        $scope.searchList = function() {
            $api.post('/hom01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.money_list = [];
                    $scope.receipts_total = 0; //入金（合計）金額
                    $scope.payment_total = 0; //出金（合計）金額
                    $scope.salary_total = 0; //給与（合計）金額
                    $scope.incomeTax_total = 0; //所得税（合計）金額
                    $scope.cost_total = 0; //費用（合計）金額
                    $scope.profits_total = 0; //概算（合計）金額

                    for (let i = 0; i < data.salaryList.length; i++) {
                        let salary_info = data.salaryList[i];

                        // 入金
                        salary_info.receipts = 0;
                        for (let j = 0; j < data.receiptsList.length; j++) {
                            if (salary_info.salaryYyyymm == data.receiptsList[j].yyyymm) {
                                salary_info.receipts = data.receiptsList[j].payMoney;
                                break;
                            }
                        }
                        // 出金
                        salary_info.payment = 0;
                        for (let k = 0; k < data.paymentList.length; k++) {
                            if (salary_info.salaryYyyymm == data.paymentList[k].yyyymm) {
                                salary_info.payment = data.paymentList[k].withdrawalMoney;
                                break;
                            }
                        }
                        salary_info.cost = 0; //費用

                        // 概算
                        salary_info.profits = $api.toNumeric(salary_info.receipts) - $api.toNumeric(salary_info.salary) - $api.toNumeric(salary_info.payment) - $api.toNumeric(salary_info.cost);

                        $scope.money_list.push(salary_info);

                        // Total累計
                        $scope.receipts_total = $api.toNumeric($scope.receipts_total) + $api.toNumeric(salary_info.receipts); //入金（合計）金額
                        $scope.payment_total = $api.toNumeric($scope.payment_total) + $api.toNumeric(salary_info.payment); //出金（合計）金額
                        $scope.salary_total = $api.toNumeric($scope.salary_total) + $api.toNumeric(salary_info.salary); //給与（合計）金額
                        $scope.incomeTax_total = $api.toNumeric($scope.incomeTax_total) + $api.toNumeric(salary_info.incomeTax); //所得税（合計）金額
                        $scope.cost_total = $api.toNumeric($scope.cost_total) + $api.toNumeric(salary_info.cost); //費用（合計）金額
                        $scope.profits_total = $api.toNumeric($scope.profits_total) + $api.toNumeric(salary_info.profits); //概算（合計）金額
                    }
                    //
                    //                for (let i = 0; i < data.salaryList.length; i++) {
                    //                    let info = data.salaryList[i];
                    //                    info.checked = $scope.masterCheck;
                    //                    // 差引支給額の算出
                    //                    info.withdrawalMoney = $scope.calWithdrawalMoney(info);
                    //                    $scope.salaryList.push(info);
                    //                }
                } else {
                    // $scope.salaryList = [];
                }
            });
        };
    });

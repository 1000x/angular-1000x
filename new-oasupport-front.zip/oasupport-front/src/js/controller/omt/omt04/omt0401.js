const swal = require('sweetalert2');
/**
 * 部門情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt04omt0401Ctrl', function($scope, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.datatable = {};

            // 銀行一覧の取得処理
            $scope.getdepartList();

            // datatable options初期化
            $scope.initDtOption();
        };

        /**
         * 部門情報一覧の取得処理
         */
        $scope.getdepartList = function() {
            $api.get('/omt04/r/list', function(res) {
                if (res.success) {
                    $scope.departList = [];
                    let data = res.data;
                    for (let i = 0; i < data.departmentList.length; i++) {
                        $scope.departList.push(data.departmentList[i]);
                    }
                    if ($scope.departList.length == 0) {
                        commonService.removeData(CONST.PERMISSION_KEY);
                    }
                } else {
                    $scope.departList = [];
                    commonService.removeData(CONST.PERMISSION_KEY);
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [3],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * 部門削除処理
         */
        $scope.departDel = function(departInfo) {
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    let data = {
                        rowsId: departInfo.rowsId,
                    };
                    $api.post('/omt04/d/item', data, function(res) {
                        if (res.success) {
                            message.showSuccess('削除しました。');
                            $scope.getdepartList();
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        };
    });

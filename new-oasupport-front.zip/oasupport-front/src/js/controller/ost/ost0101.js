const swal = require('sweetalert2');
/**
 * 入金情報一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('ostost0101Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // init data
            $scope.initData();

            // 入金情報一覧の取得処理
            // $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * data init
         */
        $scope.initData = function() {
            // 検索用
            $scope.search = {
                yyyymm: '', // 検索用請求年月
                payToYmd: '', // 検索用入金期限年月
                payType: '', // 検索用支払い状態
                customerCompNm: '', // 会社名前
            };

            $scope.searchText = ''; // データ絞り込み用
            $scope.datatable = {};
            $scope.payList = []; // 検索年月の入金リスト
            $scope.previousMonthPayList = []; // 検索年月の前月入金リスト
            $scope.previousMonthOnlyPayList = []; // 検索年月の前月のみ入金リスト（検索年月の入金リストを除く）
            $scope.previousMonthYesPayList = []; // 検索年月の今月あり、前月あり
            $scope.notPayMoney = 0;
            $scope.allMoney = 0;
            $scope.payMoney = 0;

            // select list
            $scope.payFlgList = CONST.PAY_STATUS_LIST; // 入金状態
            $scope.contractorCompList = {}; // 契約会社リスト
            $scope.bankList = {}; // 支払先リスト
        };

        /**
         * 入金情報一覧の取得処理
         */
        $scope.searchList = function() {
            // 初期化
            $scope.payList = []; // 検索年月の入金リスト
            $scope.previousMonthPayList = []; // 検索年月の前月入金リスト
            $scope.previousMonthOnlyPayList = []; // 検索年月の前月のみ入金リスト（検索年月の入金リストを除く）
            $scope.previousMonthYesPayList = []; // 検索年月の今月あり、前月あり
            $scope.notPayMoney = 0;
            $scope.allMoney = 0;
            $scope.payMoney = 0;

            $api.post('/ost01/r/list', $scope.search, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.payList = [];
                    $scope.previousMonthPayList = [];
                    $scope.previousMonthOnlyPayList = [];
                    $scope.previousMonthYesPayList = [];
                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(data.contractorCompList, 'corporationCompId', 'customerCompNm');

                    //  検索結果リストpush
                    for (let i = 0; i < data.payList.length; i++) {
                        let info = data.payList[i];
                        info.checked = false;
                        $scope.payList.push(info);

                        // 未入金
                        if (data.payList[i].payFlg == '1') {
                            // 未入金
                            $scope.notPayMoney = $api.toNumeric($scope.notPayMoney) + $api.toNumeric(data.payList[i].payMoney);
                            // total 計算
                            $scope.allMoney = $api.toNumeric($scope.allMoney) + $api.toNumeric(data.payList[i].payMoney);
                        }
                        // 入金済み
                        if (data.payList[i].payFlg == '2') {
                            // 入金済み
                            $scope.payMoney = $api.toNumeric($scope.payMoney) + $api.toNumeric(data.payList[i].payMoney);
                            // total 計算
                            $scope.allMoney = $api.toNumeric($scope.allMoney) + $api.toNumeric(data.payList[i].payMoney);
                        }
                    }

                    //  検索結果前月リストpush
                    for (let i = 0; i < data.previousMonthPayList.length; i++) {
                        let info = data.previousMonthPayList[i];

                        // 前月分を検索月に存在するか、チェックし、
                        for (let j = 0; j < data.payList.length; j++) {
                            if (info.customerCompNm == data.payList[j].customerCompNm) {
                                $scope.previousMonthYesPayList.push(info);
                                break;
                            }
                        }
                    }

                    //  今月あり前月ありリストpush
                    for (let i = 0; i < data.previousMonthPayList.length; i++) {
                        let info2 = data.previousMonthPayList[i];
                        let flg = false;

                        // 前月分を検索月に存在するか、チェックし、
                        for (let j = 0; j < data.payList.length; j++) {
                            if (info2.customerCompNm == data.payList[j].customerCompNm) {
                                flg = true;
                                break;
                            }
                        }

                        // 今月のみ場合
                        if (!flg) {
                            $scope.previousMonthOnlyPayList.push(info2);
                        }
                    }

                    //銀行名称リスト
                    $scope.bankList = commonService.makeArrToDroplist(data.bankList, 'bankId', 'bankNm');

                    //銀行口座リスト
                    $scope.bankkozaList = commonService.makeArrToDroplist(data.bankList, 'bankId', 'accountCd');

                    // dropdown and select trigger
                    $timeout(function() {
                        $('.btn-setting').dropdown({
                            on: 'hover',
                            duration: '100',
                        });
                    });
                } else {
                    $scope.payList = [];
                }
            });
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [7],
                    },
                ],
                order: [],
                displayLength: 16,
            };
        };

        /**
         * dtInstanceCallback table
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み(Search)
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * 入金削除処理
         */
        $scope.payDel = function(payInfo) {
            let $url = '/ost01/d/item/' + payInfo.rowsId;

            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    $api.get($url, function(res) {
                        if (res.success) {
                            message.showSuccess('削除しました。');
                            // 入金情報一覧の取得処理
                            $scope.searchList();
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        };

        /**
         * 前月の入金リスト取得処理
         * パラメータ１:　会社名称
         * パラメータ２:　取得項目TYPE（１：請求年月、２：入金予定金額、３：入金期限、４：入金状態）
         */
        $scope.getPreviousMonthPayInfo = function($customerCompNm, $type) {
            //  前月の入金リスト
            for (let i = 0; i < $scope.previousMonthYesPayList.length; i++) {
                if ($customerCompNm == $scope.previousMonthYesPayList[i].customerCompNm) {
                    switch ($type) {
                        case 1:
                            return $scope.previousMonthYesPayList[i].yyyymm; // 請求年月
                            break;
                        case 2:
                            return $scope.previousMonthYesPayList[i].payMoney; // 入金予定金額
                            break;
                        case 3:
                            return $scope.previousMonthYesPayList[i].payToYmd; // 入金期限
                            break;
                        case 4:
                            // return payFlgList[data.previousMonthPayList[i].payFlg];  // 入金状態
                            return $scope.previousMonthYesPayList[i].payFlg; // 入金状態
                            break;
                    }
                }
            }
            return '';
        };

        $scope.form_check = function() {
            jQuery('.searchform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 入金予定年月選択
                    contractYm: {
                        identifier: 'payToYm',
                        rules: [
                            {
                                type: 'date[YYYY-MM]',
                                prompt: message.getMsgById('E_XX_FW_5019', '入金予定年月'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };

        /**
         * CSVダウロードの取得処理
         */
        $scope.download = function() {
            let param = {
                yyyymm: $scope.search.yyyymm,
                payToYmd: $scope.search.payToYmd,
                payFlg: $scope.search.payFlg,
                customerCompNm: $scope.search.customerCompNm,
            };

            $api.post('/ost01/download/list', param, function(res) {
                if (res.success) {
                    let blob = $api.b64toBlob(res.data.fileBase64String, 'application/octet-stream');
                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, res.data.fileName);
                    } else {
                        let objectUrl = URL.createObjectURL(blob);
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = objectUrl;
                        a.download = res.data.fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };
    });

/**
 * menu コントローラ
 */
module.exports = app =>
    app.controller('z99menuCtrl', function($scope, $rootScope, $location, $session, $auth) {
        $scope.compNm = $session.COMP_NM;
        $scope.authorityList = $session.AUTHORITY_LIST;

        /**
         * logout
         */
        $scope.logout = function() {
            $auth.logout();
        };

        /**
         * refresh user
         */
        $rootScope.$on('refresh_user', function() {
            $scope.compNm = $session.COMP_NM;
            $scope.authorityList = $session.AUTHORITY_LIST;
        });

        /**
         * menu/item active
         */
        $scope.isActive = function(str) {
            return $location.path().indexOf(str) == 0;
        };
    });

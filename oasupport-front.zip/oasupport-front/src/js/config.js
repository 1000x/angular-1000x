const angular = require('angular');

module.exports = angular.module('app.config', []).constant('CONFIG', {
    // API_BASE
    // API_BASE: process.env.NODE_ENV == 'production' ? 'https://www.smartit.jp/oasupport-web/api' : 'http://localhost:8080/oasupport-web/api',
    // API_BASE: "http://localhost:8080/oasupport-web/api",
    // API_BASE: "http://160.16.98.97:8080/oasupport-web/api",
    API_BASE: 'https://api.smartit.jp/oasupport-web/api',
    // API_BASE: "https://dev.smartit.jp/oasupport-web/api",

    // AUTH_BASE
    // AUTH_BASE: "http://localhost:8080/oauth-service-web"
    // AUTH_BASE: process.env.NODE_ENV == 'production' ? 'https://www.smartit.jp/oauth-service-web' : 'http://localhost:8080/oauth-service-web',
    // AUTH_BASE: "http://160.16.98.97:8080/oauth-service-web",
    AUTH_BASE: 'https://api.smartit.jp/oauth-service-web',
    // AUTH_BASE: "https://dev.smartit.jp/oauth-service-web",
});

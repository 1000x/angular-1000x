const moment = require('moment');
const swal = require('sweetalert2');
/**
 * 社員一覧·画面コントローラ
 */
module.exports = app =>
    app.controller('osuosu0101Ctrl', function($scope, $timeout, $api, commonService, message, CONST) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.employee_list = [];
            $scope.toggleCheckFlg = false;
            $scope.datatable = {};
            $scope.searchText = '';
            $scope.searchLeaveFlg = '';

            // select list
            $scope.sexList = CONST.SEX_LIST;
            $scope.leaveFlgList = CONST.LEAVE_FLG_LIST;

            // 社員一覧情報の取得処理
            $scope.searchList();

            // datatable options初期化
            $scope.initDtOption();
        };

        /**
         * 在職/退職一覧の取得
         */
        $scope.searchList = function() {
            if (!$scope.searchLeaveFlg) $scope.searchLeaveFlg = '';
            // 社員一覧情報の取得処理
            $api.get('/osu01/r/list?leaveFlg=' + $scope.searchLeaveFlg, function(res) {
                if (res.success) {
                    let data = res.data;
                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');
                    // 社員リスト
                    $scope.employee_list = [];
                    for (let i = 0; i < data.empleList.length; i++) {
                        let info = data.empleList[i];
                        info.checked = false;
                        $scope.employee_list.push(info);
                    }
                    // dropdown and select trigger
                    $timeout(function() {
                        $('.btn-setting').dropdown({
                            on: 'hover',
                            duration: '100',
                        });
                    });
                } else {
                    $scope.employee_list = [];
                }
            });
        };

        /**
         * get user name
         */
        $scope.getName = function(info) {
            if (info.lastNmKanji || info.fristNmKanji) {
                return info.lastNmKanji + ' ' + info.fristNmKanji;
            }

            return info.lastNmKana + ' ' + info.fristNmKana;
        };

        /**
         * 「全選択/解除」ボタン押下
         */
        $scope.toggle_check = function() {
            for (let i = 0; i < $scope.employee_list.length; i++) {
                $scope.employee_list[i].checked = !$scope.toggleCheckFlg;
            }
            $scope.toggleCheckFlg = !$scope.toggleCheckFlg;
        };

        /**
         * dataTable optionの設定
         */
        $scope.initDtOption = function() {
            $scope.datatable.dtOptions = {
                // language
                language: commonService.getDtLanguage(),
                // 件数切替機能 無効
                lengthChange: false,
                columnDefs: [
                    {
                        orderable: false,
                        targets: [0, 10],
                    },
                ],
                order: [2, 'asc'],
                displayLength: 20,
            };
        };

        /**
         * dtInstanceCallback
         */
        $scope.dtInstanceCallback = function(dtInstance) {
            $scope.dtInstance = dtInstance;
        };

        /**
         * データの絞り込み
         */
        $scope.doSearch = function() {
            if (!$scope.dtInstance) return;
            $scope.dtInstance.DataTable.search($scope.searchText).draw();
        };

        /**
         * can retirement
         */
        $scope.canRetirement = function() {
            let canRetirement = false;
            for (let i = 0; i < $scope.employee_list.length; i++) {
                if ($scope.employee_list[i].checked && $scope.employee_list[i].leaveFlg != '2') {
                    canRetirement = true;
                    break;
                }
            }
            return canRetirement;
        };

        /**
         * can remove
         */
        $scope.canRemove = function() {
            let canRemove = false;
            for (let i = 0; i < $scope.employee_list.length; i++) {
                if ($scope.employee_list[i].checked) {
                    canRemove = true;
                    break;
                }
            }
            return canRemove;
        };

        /**
         * 削除処理
         */
        $scope.remove = function(index, rowsId) {
            swal({
                text: '削除してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(
                function(isConfirm) {
                    if (isConfirm) {
                        $api.post('/osu01/d/list', [rowsId], function(res) {
                            if (res.success) {
                                message.showSuccess('処理成功');
                                $scope.employee_list.splice(index, 1);
                                // dropdown and select trigger
                                $timeout(function() {
                                    $('.btn-setting').dropdown({
                                        on: 'hover',
                                        duration: '100',
                                    });
                                });
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                },
                function(dismiss) {
                    // 処理なし
                }
            );
        };

        /**
         * 削除処理(リスト)
         */
        $scope.removeList = function() {
            let rowsIdList = [];
            let removeObjList = [];
            for (let i = 0; i < $scope.employee_list.length; i++) {
                if ($scope.employee_list[i].checked) {
                    rowsIdList.push($scope.employee_list[i].rowsId);
                    removeObjList.push($scope.employee_list[i]);
                }
            }

            if (rowsIdList.length > 0) {
                swal({
                    text: '削除してよろしいですか',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(function(isConfirm) {
                    if (isConfirm) {
                        $api.post('/osu01/d/list', rowsIdList, function(res) {
                            if (res.success) {
                                message.showSuccess('処理成功');
                                for (let i = 0; i < removeObjList.length; i++) {
                                    let index = $scope.employee_list.indexOf(removeObjList[i]);
                                    if (index != -1) $scope.employee_list.splice(index, 1);
                                }
                            } else {
                                message.showError(res.data.message);
                            }
                            removeObjList = null;
                            rowsIdList = null;
                            // dropdown and select trigger
                            $timeout(function() {
                                $('.btn-setting').dropdown({
                                    on: 'hover',
                                    duration: '100',
                                });
                            });
                        });
                    }
                });
            }
        };

        /**
         * 退職/入職処理
         */
        $scope.enrolled = function(employeeInfo) {
            let text = employeeInfo.leaveFlg == '1' ? '退職' : '入職';

            swal({
                text: text + 'してよろしいですか',
                type: 'warning',
                confirmButtonText: '確定',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                cancelButtonText: 'キャンセル',
            }).then(function(isConfirm) {
                if (isConfirm) {
                    let data = {
                        rowsId: employeeInfo.rowsId,
                        leaveFlg: employeeInfo.leaveFlg == '1' ? '2' : '1',
                    };
                    $api.post('/osu01/u/item/enroll', data, function(res) {
                        if (res.success) {
                            message.showSuccess('処理成功');
                            employeeInfo.leaveFlg = data.leaveFlg;
                            if (data.leaveFlg == '1') {
                                employeeInfo.leaveDt = '';
                            } else {
                                employeeInfo.leaveDt = moment().format('YYYY-MM-DD'); // 退社日
                            }
                        } else {
                            message.showError(res.data.message);
                        }
                    });
                }
            });
        };

        /**
         * 退職処理(リスト)
         */
        $scope.retirementList = function() {
            let rowsIdList = [];
            for (let i = 0; i < $scope.employee_list.length; i++) {
                if ($scope.employee_list[i].checked && $scope.employee_list[i].leaveFlg != '2') {
                    rowsIdList.push($scope.employee_list[i].rowsId);
                }
            }
            if (rowsIdList.length > 0) {
                swal({
                    text: '退職してよろしいですか',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(function(isConfirm) {
                    if (isConfirm) {
                        $api.post('/osu01/u/list', rowsIdList, function(res) {
                            if (res.success) {
                                message.showSuccess('処理成功');
                                for (let i = 0; i < $scope.employee_list.length; i++) {
                                    if ($scope.employee_list[i].checked) {
                                        $scope.employee_list[i].checked = false;
                                        $scope.employee_list[i].leaveFlg = '2'; // 退職
                                        $scope.employee_list[i].leaveDt = moment().format('YYYY-MM-DD'); // 退社日
                                    }
                                }
                            } else {
                                message.showError(res.data.message);
                            }
                        });
                    }
                });
            }
        };

        /**
         * 社員情報のダウンロード処理
         */
        $scope.downloadEmployee = function() {
            let param = {
                leaveFlg: $scope.searchLeaveFlg,
            };

            $api.post('/osu01/download/list', param, function(res) {
                if (res.success) {
                    let blob = $api.b64toBlob(res.data.fileBase64String, 'application/octet-stream');
                    if (window.navigator.msSaveBlob) {
                        window.navigator.msSaveBlob(blob, res.data.fileName);
                    } else {
                        let objectUrl = URL.createObjectURL(blob);
                        let a = document.createElement('a');
                        document.body.appendChild(a);
                        a.style = 'display: none';
                        a.href = objectUrl;
                        a.download = res.data.fileName;
                        a.click();
                        document.body.removeChild(a);
                    }
                } else {
                    message.showError(res.data.message);
                }
            });
        };
    });

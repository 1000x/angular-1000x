const swal = require('sweetalert2');
/**
 * 社員更新·画面コントローラ
 */
module.exports = app =>
    app.controller('osuosu0103Ctrl', function($scope, $location, $routeParams, $api, message, CONST, commonService, $timeout) {
        $scope.search = '';

        /**
         * 初期化
         */
        $scope.init = function() {
            // 社員情報
            $scope.employee = {};
            // select list
            $scope.sexList = CONST.SEX_LIST;
            $scope.leaveFlgList = CONST.LEAVE_FLG_LIST;
            $scope.residentStatusList = CONST.RESIDENT_STATUS_LIST;
            $scope.spouseFlgList = CONST.SPOUSEFLG_LIST;
            $scope.salaryTypeList = CONST.SALARYTYPE_LIST;
            $scope.commutAllowanceList = CONST.COMMUT_ALLOWANCE_LIST;

            $scope.bonusSummerList = CONST.BONUS_SUMMER_LIST;
            $scope.bonusWinterList = CONST.BONUS_WINTER_LIST;
            $scope.employStatusList = CONST.EMPLOY_STATUS_LIST;

            // 保険リスト
            $scope.healthInsuranceFlgList = CONST.HEALTH_INSURANCE_FLG_LIST;
            $scope.nursInsuranceFlgList = CONST.NURS_INSURANCE_FLG_LIST;
            $scope.welfareInsuranceFlgList = CONST.WELFARE_INSURANCE_FLG_LIST;
            $scope.employInsuranceFlgList = CONST.EMPLOY_INSURANCE_FLG_LIST;

            let $url = '/osu01/r/item/' + $routeParams.id;

            // 社員情報の取得
            $api.get($url, function(res) {
                // 社員情報が存在していない場合
                if (res.status == '409') {
                    swal({
                        text: res.data.message,
                        type: 'error',
                        allowOutsideClick: false,
                        confirmButtonText: '社員一覧画面へ戻す',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('osu0101');
                        });
                    });
                    return;
                }
                if (res.success) {
                    let data = res.data;
                    // 社員情報
                    $scope.employee = data.empleInfo;
                    // 部門リスト
                    $scope.departmentList = commonService.makeArrToDroplist(data.departmentList, 'departId', 'departNm');
                }
            });

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            return jQuery('.employeeFormUpdate').form('validate form');
        };

        /**
         * 更新ボタン押下
         */
        $scope.infoUpdate = function() {
            let $url = '/osu01/u/item';
            if ($scope.isValidForm()) {
                $api.post($url, $scope.employee, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.employeeFormUpdate').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * 住所検索
         */
        $scope.getAddress = function(postCd) {
            if (!postCd) {
                $('input[name=postCd]').focusout();
                return;
            }
            commonService.getAddrByPostCd(postCd, function(address) {
                $scope.employee.address = address;
            });
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            jQuery('.employeeFormUpdate').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    //部门ID
                    department: {
                        identifier: 'department',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '部门'),
                            },
                        ],
                    },
                    //社員ID（カスタマイズ）
                    customEmpleId: {
                        identifier: 'customEmpleId',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '社員ID（カスタマイズ）'),
                            },
                            {
                                type: 'regExp[/^[A-Za-z0-9]+$/]',
                                prompt: message.getMsgById('E_XX_FW_5006', '社員ID（カスタマイズ）'),
                            },
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '社員ID（カスタマイズ）', '20'),
                            },
                        ],
                    },
                    //入社日
                    joinDt: {
                        identifier: 'joinDt',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '入社日'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', '入社日'),
                            },
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '入社日', '10'),
                            },
                        ],
                    },
                    //姓（漢字）
                    lastNmKanji: {
                        identifier: 'lastNmKanji',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '姓（漢字）'),
                            },
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '姓（漢字）', '20'),
                            },
                        ],
                    },
                    //名（漢字）
                    fristNmKanji: {
                        identifier: 'fristNmKanji',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '名（漢字）'),
                            },
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '名（漢字）', '20'),
                            },
                        ],
                    },
                    //姓（カナ）
                    lastNmKana: {
                        identifier: 'lastNmKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '姓（カナ）'),
                            },
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '姓（カナ）', '20'),
                            },
                        ],
                    },
                    //名（カナ）
                    fristNmKana: {
                        identifier: 'fristNmKana',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '名（カナ）'),
                            },
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '名（カナ）', '20'),
                            },
                        ],
                    },
                    //国籍
                    nationality: {
                        identifier: 'nationality',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '国籍'),
                            },
                        ],
                    },
                    //生年月日
                    birth: {
                        identifier: 'birth',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '生年月日'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', '生年月日'),
                            },
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '生年月日', '10'),
                            },
                        ],
                    },
                    //性別
                    sex: {
                        identifier: 'sex',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '性別'),
                            },
                        ],
                    },
                    //雇用形態
                    employStatus: {
                        identifier: 'employStatus',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '雇用形態'),
                            },
                        ],
                    },
                    //賞与日付
                    bonusSummerDt: {
                        identifier: 'bonusSummerDt',
                        rules: [
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '賞与日付', '10'),
                            },
                        ],
                    },
                    //賞与日付
                    bonusWinterDt: {
                        identifier: 'bonusWinterDt',
                        rules: [
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '賞与日付', '10'),
                            },
                        ],
                    },
                    //給与方式
                    salaryType: {
                        identifier: 'salaryType',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '給与方式'),
                            },
                        ],
                    },
                    //基本給（円）
                    monthSalary: {
                        identifier: 'monthSalary',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '基本給（円）'),
                            },
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '基本給（円）', '20'),
                            },
                        ],
                    },
                    //在留資格
                    residentStatus: {
                        identifier: 'residentStatus',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '在留資格'),
                            },
                            {
                                type: 'maxLength[2]',
                                prompt: message.getMsgById('E_XX_FW_5018', '在留資格', '2'),
                            },
                        ],
                    },
                    //在留カード
                    residentCardNo: {
                        identifier: 'residentCardNo',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '在留カード'),
                            },
                            {
                                type: 'maxLength[15]',
                                prompt: message.getMsgById('E_XX_FW_5018', '在留カード', '15'),
                            },
                        ],
                    },
                    //在留カード有効期限
                    residentCardLimit: {
                        identifier: 'residentCardLimit',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '在留カード有効期限'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', '在留カード有効期限'),
                            },
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '在留カード有効期限', '10'),
                            },
                        ],
                    },
                    //個人番号
                    personalNum: {
                        identifier: 'personalNum',
                        rules: [
                            {
                                type: 'maxLength[15]',
                                prompt: message.getMsgById('E_XX_FW_5018', '個人番号', '15'),
                            },
                        ],
                    },
                    //個人番号有効期限
                    personalNumLimit: {
                        identifier: 'personalNumLimit',
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', '個人番号有効期限'),
                            },
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '個人番号有効期限', '10'),
                            },
                        ],
                    },
                    //郵便番号
                    postCd: {
                        identifier: 'postCd',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '郵便番号'),
                            },
                            {
                                type: 'maxLength[7]',
                                prompt: message.getMsgById('E_XX_FW_5018', '郵便番号', '7'),
                            },
                        ],
                    },
                    //住所
                    address: {
                        identifier: 'address',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '住所'),
                            },
                            {
                                type: 'maxLength[150]',
                                prompt: message.getMsgById('E_XX_FW_5018', '住所', '150'),
                            },
                        ],
                    },
                    //通勤区間の始点
                    station: {
                        identifier: 'station',
                        rules: [
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '通勤区間の始点', '20'),
                            },
                        ],
                    },
                    //通勤区間の終点
                    endStation: {
                        identifier: 'endStation',
                        rules: [
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '通勤区間の終点', '20'),
                            },
                        ],
                    },
                    //通勤手当
                    commutPrice: {
                        identifier: 'commutPrice',
                        rules: [
                            {
                                type: 'maxLength[20]',
                                prompt: message.getMsgById('E_XX_FW_5018', '通勤手当', '20'),
                            },
                        ],
                    },
                    //扶養家族人数
                    dependentCounts: {
                        identifier: 'dependentCounts',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '扶養家族人数'),
                            },
                            {
                                type: 'number',
                                prompt: message.getMsgById('E_XX_FW_5004', '扶養家族人数'),
                            },
                            {
                                type: 'maxLength[3]',
                                prompt: message.getMsgById('E_XX_FW_5018', '扶養家族人数', '3'),
                            },
                        ],
                    },
                    //基礎年金番号
                    pensionNo: {
                        identifier: 'pensionNo',
                        rules: [
                            {
                                type: 'maxLength[15]',
                                prompt: message.getMsgById('E_XX_FW_5018', '基礎年金番号', '15'),
                            },
                        ],
                    },
                    //雇用保険の被保険者番号
                    emplInsuranceNo: {
                        identifier: 'emplInsuranceNo',
                        rules: [
                            {
                                type: 'maxLength[15]',
                                prompt: message.getMsgById('E_XX_FW_5018', '雇用保険の被保険者番号', '15'),
                            },
                        ],
                    },
                    //住民税-5月支払分までの住民税月額
                    taxMay: {
                        identifier: 'taxMay',
                        rules: [
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '住民税-5月支払分までの住民税月額', '10'),
                            },
                        ],
                    },
                    //住民税-6月支払月額
                    taxJune: {
                        identifier: 'taxJune',
                        rules: [
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '住民税-6月支払月額', '10'),
                            },
                        ],
                    },
                    //住民税-7月以降支払月額
                    taxJuly: {
                        identifier: 'taxJuly',
                        rules: [
                            {
                                type: 'maxLength[10]',
                                prompt: message.getMsgById('E_XX_FW_5018', '住民税-7月以降支払月額', '10'),
                            },
                        ],
                    },
                    //メールアドレス
                    email: {
                        identifier: 'email',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'メールアドレス'),
                            },
                            {
                                type: 'maxLength[100]',
                                prompt: message.getMsgById('E_XX_FW_5018', 'メールアドレス', '100'),
                            },
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', 'メールアドレス'),
                            },
                        ],
                    },
                    //連絡先
                    phone: {
                        identifier: 'phone',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '連絡先'),
                            },
                            {
                                type: 'maxLength[11]',
                                prompt: message.getMsgById('E_XX_FW_5018', '連絡先', '11'),
                            },
                        ],
                    },
                    //end
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });

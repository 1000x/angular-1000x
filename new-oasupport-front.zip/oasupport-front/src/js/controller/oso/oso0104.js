const swal = require('sweetalert2');
/**
 * 請求情報更新·画面コントローラ
 */
module.exports = app =>
    app.controller('osooso0104Ctrl', function($scope, $location, $routeParams, $timeout, $api, message, CONST, commonService) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.claimInfo = {};
            $scope.payee = {};

            $scope.tabIndex = 0;

            // select list
            $scope.depositTypeList = CONST.DEPOSIT_TYPE_LIST;

            // データ初期化
            $scope.initData(function() {
                // form初期化
                $timeout(function() {
                    $scope.form_check();
                });
            });
        };

        /**
         * 初期データ取得
         */
        $scope.initData = function(callback) {
            $api.get('/oso01/r/claimitem/' + $routeParams.id, function(res) {
                // 請求が存在していない場合
                if (res.status == '409') {
                    swal({
                        text: res.data.message,
                        type: 'error',
                        allowOutsideClick: false,
                        confirmButtonText: '請求情報一覧画面へ戻す',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('oso0103');
                        });
                    });
                    return;
                }

                if (res.success) {
                    let data = res.data;
                    // 契約会社リスト
                    $scope.contractorCompList = commonService.makeArrToDroplist(data.contractorCompList, 'corporationCompId', 'customerCompNm');

                    // 振込先の取得
                    if (data.claimInfo.payeeId) {
                        for (let i = 0; i < data.bankList.length; i++) {
                            let bank = data.bankList[i];
                            if (bank.bankId == data.claimInfo.payeeId) {
                                $scope.payee = bank;
                                break;
                            }
                        }
                    }
                    // 請求情報設定
                    $scope.claimInfo = data.claimInfo;
                    // tabIndexの再設定
                    if ($routeParams.detailId) {
                        for (let i = 0; i < $scope.claimInfo.details.length; i++) {
                            if ($routeParams.detailId == $scope.claimInfo.details[i].rowsId) {
                                $scope.tabIndex = i;
                                break;
                            }
                        }
                    }
                    callback();
                } else {
                    //message.getMsgById("E_XX_FW_8001", "エラー")
                    message.showError(res.data.message);
                }
            });
        };

        /**
         * 超過時間の算出
         * @param detailInfo
         */
        $scope.calOverTm = function(detailInfo) {
            let overTm = 0;
            let operatTm = Number(detailInfo.operatTm) || 0;
            // 稼働時間 < 基本時間(from)の場合
            if (operatTm < detailInfo.baseTimeStart) {
                overTm = operatTm - detailInfo.baseTimeStart;
            }
            // 稼働時間 > 基本時間(to)の場合
            else if (operatTm > detailInfo.baseTimeEnd) {
                overTm = operatTm - detailInfo.baseTimeEnd;
            }

            detailInfo.overTm = overTm.toFixed(2);

            // 請求金額の算出
            $scope.calClaimMoney(detailInfo);
        };

        /**
         * 請求金額(小計)の算出
         * @param detailInfo
         */
        $scope.calClaimMoney = function(detailInfo) {
            // 請求金額
            let claimMoney = 0;

            let amount = detailInfo.amount || 1; // 数量
            // 単金
            claimMoney += parseInt(detailInfo.price * amount) || 0;

            // 超過時間
            let overTm = Number(detailInfo.overTm) || 0;

            // 超過単価(残業代ある場合)
            if (detailInfo.overtimeFlg == '1' && overTm > 0) {
                claimMoney += parseInt(detailInfo.overPrice * overTm) || 0;
            }

            // 控除単価
            if (overTm < 0) {
                claimMoney += parseInt(detailInfo.deductPrice * overTm) || 0;
            }

            // 消費税(税抜の場合)
            if (detailInfo.taxFlg == '2') {
                claimMoney += parseInt(claimMoney * CONST.TAX) || 0;
            }

            // 交通費(税込の場合)
            if (detailInfo.otherTrafficExpenseFlg == '1') {
                claimMoney += parseInt(detailInfo.otherTrafficExpense) || 0;
            } else {
                claimMoney += parseInt(detailInfo.otherTrafficExpense * (1 + CONST.TAX)) || 0;
            }

            // そのた費用(税込の場合)
            if (detailInfo.otherExpenseFlg == '1') {
                claimMoney += parseInt(detailInfo.otherExpense) || 0;
            } else {
                claimMoney += parseInt(detailInfo.otherExpense * (1 + CONST.TAX)) || 0;
            }

            detailInfo.claimMoney = claimMoney;
        };

        /**
         * 請求金額(合計)の算出
         */
        $scope.calTotalClaimMoney = function() {
            let totalClaimMoney = 0;
            if ($scope.claimInfo.details && $scope.claimInfo.details.length > 0) {
                for (let i = 0; i < $scope.claimInfo.details.length; i++) {
                    totalClaimMoney += Number($scope.claimInfo.details[i].claimMoney) || 0;
                }
            }
            return totalClaimMoney;
        };

        /**
         * change tab
         */
        $scope.changeTab = function(newTabIndex) {
            $scope.tabIndex = newTabIndex;
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            $scope.detailInValidList = [];
            // form valid : updates UI
            jQuery('.detailForm').form('validate form');
            jQuery('.mainform').form('validate form');

            if (jQuery('.mainform').form('is valid') && $scope.detailInValidList.length > 0) {
                let inValidFormIndex;
                if ($.inArray($scope.tabIndex, $scope.detailInValidList) != -1) {
                    inValidFormIndex = $scope.tabIndex;
                } else {
                    inValidFormIndex = $scope.detailInValidList[0];
                    $scope.tabIndex = inValidFormIndex;
                }
                let $errorField = $('.detailForm')
                    .eq(inValidFormIndex)
                    .find('.field.error')
                    .eq(0);
                $errorField.focus();
                $('html,body').animate(
                    {
                        scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                    },
                    200
                );

                return false;
            }
            return jQuery('.mainform').form('is valid');
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                swal({
                    text: '更新してよろしいですか。',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(
                    function(isConfirm) {
                        if (isConfirm) {
                            $api.post('/oso01/u/item', $scope.claimInfo, function(res) {
                                if (res.success) {
                                    message.showSuccess('success');
                                } else {
                                    message.showError(res.data.message);
                                    // show error details
                                    let errDetails = res.data.details;
                                    if (errDetails) {
                                        for (let i = 0; i < errDetails.length; i++) {
                                            jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                                        }
                                    }
                                }
                            });
                        }
                    },
                    function(dismiss) {
                        // 処理なし
                    }
                );
            }
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            // detail form check
            for (let i = 0; i < $scope.claimInfo.details.length; i++) {
                $scope.detailFormCheck(i);
            }
            // main form check
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 請求番号
                    claimNo: {
                        identifier: 'claimNo',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求番号'),
                            },
                            {
                                type: 'regExp[/^[a-zA-Z0-9-]+$/]',
                                prompt: message.getMsgById('E_XX_FW_5006', '請求番号'),
                            },
                        ],
                    },
                    // 担当者名前
                    chargeNm: {
                        identifier: 'chargeNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '担当者名前'),
                            },
                        ],
                    },
                    // 担当者メールアドレス
                    chargeEmail: {
                        identifier: 'chargeEmail',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '担当者メールアドレス'),
                            },
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', '担当者メールアドレス'),
                            },
                        ],
                    },
                    // 発行日
                    issueDt: {
                        identifier: 'issueDt',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '発行日'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '発行日'),
                            },
                        ],
                    },
                    // 請求日
                    claimDt: {
                        identifier: 'claimDt',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求日'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '請求日'),
                            },
                        ],
                    },
                    // 支払期限
                    payDeadline: {
                        identifier: 'payDeadline',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支払期限'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '支払期限'),
                            },
                            //{
                            //    type   : 'greaterThan[' + moment().format("YYYY-MM-DD") + ']',
                            //    prompt : message.getMsgById("E_XX_FW_5015", "支払期限")
                            //},
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };

        /**
         * detailFormCheck
         */
        $scope.detailFormCheck = function(index) {
            // hoursInMonth
            /*let hoursInMonth = moment().daysInMonth() * 24;*/
            let hoursInMonth = 744;

            jQuery('.detailForm')
                .eq(index)
                .form({
                    on: 'blur',
                    inline: true,
                    keyboardShortcuts: false,
                    fields: {
                        // 品名（技術者）
                        empleNm: {
                            identifier: 'empleNm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '品名（技術者）'),
                                },
                            ],
                        },
                        // 業務名称
                        businessNm: {
                            identifier: 'businessNm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '業務名称'),
                                },
                            ],
                        },
                        // 稼働時間
                        operatTm: {
                            identifier: 'operatTm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '稼働時間'),
                                },
                                {
                                    type: 'lessThan[' + hoursInMonth + ']',
                                    prompt: message.getMsgById('E_XX_FW_5017', '稼働時間', hoursInMonth),
                                },
                            ],
                        },
                        // 単価
                        price: {
                            identifier: 'price',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '単価'),
                                },
                            ],
                        },
                        // 数量
                        amount: {
                            identifier: 'amount',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '数量'),
                                },
                                {
                                    type: 'greaterThan[1]',
                                    prompt: message.getMsgById('E_XX_FW_5024', '数量', 1),
                                },
                            ],
                        },
                    },
                    onFailure: function() {
                        $scope.detailInValidList.push(index);
                    },
                });
        };
    });

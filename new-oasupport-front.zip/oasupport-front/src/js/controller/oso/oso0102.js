const moment = require('moment');
const swal = require('sweetalert2');
/**
 * 請求情報登録·画面コントローラ
 */
module.exports = app =>
    app.controller('osooso0102Ctrl', function($scope, $location, $routeParams, $timeout, $api, message, CONST, commonService) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.claimCreateInfo = {};
            $scope.payee = {};
            $scope.yyyymm = '';

            $scope.tabIndex = 0;

            // select list
            $scope.depositTypeList = CONST.DEPOSIT_TYPE_LIST;

            // データ初期化
            $scope.initData(function() {
                // form初期化
                $timeout(function() {
                    $scope.form_check();
                });
            });
        };

        /**
         * 初期データ取得
         */
        $scope.initData = function(callback) {
            $api.get('/oso01/r/citem/' + $routeParams.id, function(res) {
                if (res.success) {
                    let data = res.data;

                    let errorTxt = message.getMsgById('E_OA_OSO_8002');
                    let confirmButtonText = '振込先を設定する';

                    // 振込先の存在チェック
                    if (data.claimCreateInfo.payeeId) {
                        for (let i = 0; i < data.bankList.length; i++) {
                            let bank = data.bankList[i];
                            if (bank.bankId == data.claimCreateInfo.payeeId) {
                                $scope.payee = bank;
                                errorTxt = '';
                                break;
                            }
                        }
                    }
                    // 基準時間の存在チェック
                    if (!errorTxt && data.claimCreateInfo.details) {
                        for (let i = 0; i < data.claimCreateInfo.details.length; i++) {
                            let detailInfo = data.claimCreateInfo.details[i];
                            if (!detailInfo.baseTimeStart || !detailInfo.baseTimeEnd) {
                                errorTxt = message.getMsgById('E_XX_FW_5023', '契約情報の基準時間');
                                confirmButtonText = '基準時間を設定する';
                                break;
                            }
                        }
                    }
                    if (!errorTxt) {
                        // 契約会社リスト
                        $scope.contractorCompList = commonService.makeArrToDroplist(data.contractorCompList, 'corporationCompId', 'customerCompNm');
                        // 請求作成情報
                        $scope.makeClaimCreateInfo(data);

                        callback();
                    } else {
                        swal({
                            text: errorTxt,
                            type: 'warning',
                            confirmButtonText: confirmButtonText,
                            showCancelButton: true,
                            cancelButtonColor: '#d33',
                            cancelButtonText: '戻る',
                        }).then(
                            function(isConfirm) {
                                if (isConfirm) {
                                    $timeout(function() {
                                        $location.path('osd0103/' + data.claimCreateInfo.rowsId);
                                    });
                                }
                            },
                            function(dismiss) {
                                $timeout(function() {
                                    $location.path('oso0101');
                                });
                            }
                        );
                    }
                } else {
                    swal({
                        type: 'error',
                        text: res.data.message,
                        allowOutsideClick: false,
                        confirmButtonText: '請求作成一覧画面へ戻る',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('oso0101');
                        });
                    });
                }
            });
        };

        /**
         * change tab
         */
        $scope.changeTab = function(newTabIndex) {
            $scope.tabIndex = newTabIndex;
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            $scope.detailInValidList = [];
            // form valid : updates UI
            jQuery('.detailForm').form('validate form');
            jQuery('.mainform').form('validate form');

            if (jQuery('.mainform').form('is valid') && $scope.detailInValidList.length > 0) {
                let inValidFormIndex;
                if ($.inArray($scope.tabIndex, $scope.detailInValidList) != -1) {
                    inValidFormIndex = $scope.tabIndex;
                } else {
                    inValidFormIndex = $scope.detailInValidList[0];
                    $scope.tabIndex = inValidFormIndex;
                }
                let $errorField = $('.detailForm')
                    .eq(inValidFormIndex)
                    .find('.field.error')
                    .eq(0);
                $errorField.focus();
                $('html,body').animate(
                    {
                        scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                    },
                    200
                );

                return false;
            }
            return jQuery('.mainform').form('is valid');
        };

        /**
         * 登録ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                swal({
                    text: '請求作成してよろしいですか。',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(
                    function(isConfirm) {
                        if (isConfirm) {
                            for (let i = 0; i < $scope.claimCreateInfo.details.length; i++) {
                                $scope.claimCreateInfo.details[i].yyyymm = $scope.yyyymm;
                            }

                            $api.post('/oso01/c/item', $scope.claimCreateInfo, function(res) {
                                if (res.success) {
                                    message.showSuccess('success');
                                } else {
                                    message.showError(res.data.message);
                                    // show error details
                                    let errDetails = res.data.details;
                                    if (errDetails) {
                                        for (let i = 0; i < errDetails.length; i++) {
                                            jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                                        }
                                    }
                                }
                            });
                        }
                    },
                    function(dismiss) {
                        // 処理なし
                    }
                );
            }
        };

        /**
         * 請求作成情報の編集処理
         * @param data
         */
        $scope.makeClaimCreateInfo = function(data) {
            let claimCreateInfo = data.claimCreateInfo;

            // 当月月末日
            let endMonth = moment()
                .endOf('month')
                .format('YYYY-MM-DD');
            // 請求作成情報
            $scope.claimCreateInfo = {
                contractId: claimCreateInfo.rowsId, // 契約ID
                claimToCompanyId: claimCreateInfo.contractorCompId, // 請求先会社ID
                chargeDepartId: claimCreateInfo.picDepartId, // 担当者部門Id
                chargeNm: claimCreateInfo.picNm, // 担当者名前
                chargeEmail: claimCreateInfo.picEmail, // 担当者メールアドレス
                issueDt: endMonth, // 発行日
                claimDt: endMonth, // 請求日
                payeeId: $scope.payee.bankId, // 振込先ID
                details: [], // 契約詳細
            };

            // 契約詳細
            for (let i = 0; i < claimCreateInfo.details.length; i++) {
                let detailInfo = claimCreateInfo.details[i];
                $scope.claimCreateInfo.details.push({
                    yyyymm: detailInfo.yyyymm, // 請求年月
                    claimMoney: '0', // 請求金額(小計)
                    empleNm: detailInfo.empleNm, // 品名（技術者）
                    price: detailInfo.price, // 単価
                    amount: 1, // 数量
                    taxFlg: detailInfo.taxFlg, // 消費税
                    baseTimeStart: detailInfo.baseTimeStart, // 基準時間(始)
                    baseTimeEnd: detailInfo.baseTimeEnd, // 基準時間(終)
                    overPrice: detailInfo.overPrice || '0', // 超過単価
                    deductPrice: detailInfo.deductPrice || '0', // 控除単価
                    overtimeFlg: detailInfo.overtimeFlg, // 残業代フラグ
                    otherTrafficExpense: '0', // 交通費
                    otherTrafficExpenseFlg: '1', // 交通費-消費税区分
                    otherExpense: '0', // その他費用
                    otherExpenseFlg: '1', // その他費用-消費税区分
                });
            }

            // 支払期限の算出
            $scope.calPayDeadline(claimCreateInfo.payDeadlineMonthFlg, claimCreateInfo.payDeadlineDayFlg, claimCreateInfo.payDeadlineDay);
        };

        /**
         * 支払期限の算出
         * @param payDeadlineMonthFlg 支払期限(月）
         * @param payDeadlineDayFlg 支払日数（月末/その他）
         * @param payDeadlineDay 支払日
         */
        $scope.calPayDeadline = function(payDeadlineMonthFlg, payDeadlineDayFlg, payDeadlineDay) {
            let payDeadline = moment();
            // 翌月の場合
            if (payDeadlineMonthFlg == '1') {
                payDeadline = payDeadline.add(1, 'month');
            }
            // 翌々月の場合
            else if (payDeadlineMonthFlg == '2') {
                payDeadline = payDeadline.add(2, 'month');
            }
            // 翌々々月の場合
            else if (payDeadlineMonthFlg == '3') {
                payDeadline = payDeadline.add(3, 'month');
            }

            // 月末の場合
            if (payDeadlineDayFlg == '1') {
                $scope.claimCreateInfo.payDeadline = payDeadline.endOf('month').format('YYYY-MM-DD');
            } else {
                $scope.claimCreateInfo.payDeadline = payDeadline
                    .startOf('month')
                    .add(payDeadlineDay || 0, 'day')
                    .format('YYYY-MM-DD');
            }
        };

        /**
         * 超過時間の算出
         * @param detailInfo
         */
        $scope.calOverTm = function(detailInfo) {
            let overTm = 0;
            let operatTm = Number(detailInfo.operatTm) || 0;
            // 稼働時間 < 基本時間(from)の場合
            if (operatTm < detailInfo.baseTimeStart) {
                overTm = operatTm - detailInfo.baseTimeStart;
            }
            // 稼働時間 > 基本時間(to)の場合
            else if (operatTm > detailInfo.baseTimeEnd) {
                overTm = operatTm - detailInfo.baseTimeEnd;
            }

            detailInfo.overTm = overTm.toFixed(2);

            // 請求金額の算出
            $scope.calClaimMoney(detailInfo);
        };

        /**
         * 請求金額(小計)の算出
         * @param detailInfo
         */
        $scope.calClaimMoney = function(detailInfo) {
            // 請求金額
            let claimMoney = 0;
            let claimMoneyNoTax = 0;
            let otherMoney = 0;

            let amount = detailInfo.amount || 1; // 数量
            // 単金
            claimMoney += parseInt(detailInfo.price * amount) || 0;

            // 超過時間
            let overTm = Number(detailInfo.overTm) || 0;

            // 超過単価(残業代ある場合)
            if (detailInfo.overtimeFlg == '1' && overTm > 0) {
                claimMoney += parseInt(detailInfo.overPrice * overTm) || 0;
            }

            // 控除単価
            if (overTm < 0) {
                claimMoney += parseInt(detailInfo.deductPrice * overTm) || 0;
            }

            // 税金とそのたを抜き
            claimMoneyNoTax = claimMoney;

            // 消費税(税抜の場合)
            if (detailInfo.taxFlg == '2') {
                claimMoney += parseInt(claimMoney * CONST.TAX) || 0;
            }

            // 交通費(税込の場合)
            if (detailInfo.otherTrafficExpenseFlg == '1') {
                claimMoney += parseInt(detailInfo.otherTrafficExpense) || 0;

                // そのた金額
                otherMoney += parseInt(detailInfo.otherTrafficExpense) || 0;
            } else {
                claimMoney += parseInt(detailInfo.otherTrafficExpense * (1 + CONST.TAX)) || 0;

                // そのた金額
                otherMoney += parseInt(detailInfo.otherTrafficExpense * (1 + CONST.TAX)) || 0;
            }

            // そのた費用(税込の場合)
            if (detailInfo.otherExpenseFlg == '1') {
                claimMoney += parseInt(detailInfo.otherExpense) || 0;

                // そのた金額
                otherMoney += parseInt(detailInfo.otherExpense) || 0;
            } else {
                claimMoney += parseInt(detailInfo.otherExpense * (1 + CONST.TAX)) || 0;

                // そのた金額
                otherMoney += parseInt(detailInfo.otherExpense * (1 + CONST.TAX)) || 0;
            }

            detailInfo.claimMoney = claimMoney;
            detailInfo.claimMoneyNoTax = claimMoneyNoTax;
            detailInfo.otherMoney = otherMoney;
        };

        /**
         * 請求金額(合計)の算出
         */
        $scope.calTotalClaimMoney = function() {
            let totalClaimMoney = 0;
            if ($scope.claimCreateInfo.details && $scope.claimCreateInfo.details.length > 0) {
                for (let i = 0; i < $scope.claimCreateInfo.details.length; i++) {
                    totalClaimMoney += Number($scope.claimCreateInfo.details[i].claimMoney) || 0;
                }
            }
            return totalClaimMoney;
        };

        /**
         * form check
         */
        $scope.form_check = function() {
            // detail form check
            for (let i = 0; i < $scope.claimCreateInfo.details.length; i++) {
                $scope.detailFormCheck(i);
            }
            // main form check
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 請求番号
                    claimNo: {
                        identifier: 'claimNo',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求番号'),
                            },
                            {
                                type: 'regExp[/^[a-zA-Z0-9-]+$/]',
                                prompt: message.getMsgById('E_XX_FW_5006', '請求番号'),
                            },
                        ],
                    },
                    // 担当者名前
                    chargeNm: {
                        identifier: 'chargeNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '担当者名前'),
                            },
                        ],
                    },
                    // 担当者メールアドレス
                    chargeEmail: {
                        identifier: 'chargeEmail',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '担当者メールアドレス'),
                            },
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', '担当者メールアドレス'),
                            },
                        ],
                    },
                    // 発行日
                    issueDt: {
                        identifier: 'issueDt',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '発行日'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '発行日'),
                            },
                        ],
                    },
                    // 請求日
                    claimDt: {
                        identifier: 'claimDt',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '請求日'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '請求日'),
                            },
                        ],
                    },
                    // 支払期限
                    payDeadline: {
                        identifier: 'payDeadline',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '支払期限'),
                            },
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5019', '支払期限'),
                            },
                            //{
                            //    type   : 'greaterThan[' + moment().format("YYYY-MM-DD") + ']',
                            //    prompt : message.getMsgById("E_XX_FW_5015", "支払期限")
                            //},
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };

        /**
         * detailFormCheck
         */
        $scope.detailFormCheck = function(index) {
            // hoursInMonth
            /*let hoursInMonth = moment().daysInMonth() * 24;*/
            let hoursInMonth = 744;

            jQuery('.detailForm')
                .eq(index)
                .form({
                    on: 'blur',
                    inline: true,
                    keyboardShortcuts: false,
                    fields: {
                        // 請求年月
                        empleNm: {
                            identifier: 'yyyymm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '請求年月'),
                                },
                            ],
                        },
                        // 品名（技術者）
                        empleNm: {
                            identifier: 'empleNm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '品名（技術者）'),
                                },
                            ],
                        },
                        // 業務名称
                        businessNm: {
                            identifier: 'businessNm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '業務名称'),
                                },
                            ],
                        },
                        //稼働時間
                        operatTm: {
                            identifier: 'operatTm',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '稼働時間'),
                                },
                                {
                                    type: 'lessThan[' + hoursInMonth + ']',
                                    prompt: message.getMsgById('E_XX_FW_5017', '稼働時間', hoursInMonth),
                                },
                            ],
                        },
                        // 単価
                        price: {
                            identifier: 'price',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '単価'),
                                },
                            ],
                        },
                        // 数量
                        amount: {
                            identifier: 'amount',
                            rules: [
                                {
                                    type: 'empty',
                                    prompt: message.getMsgById('E_XX_FW_5003', '数量'),
                                },
                                {
                                    type: 'greaterThan[1]',
                                    prompt: message.getMsgById('E_XX_FW_5024', '数量', 1),
                                },
                            ],
                        },
                    },
                    onFailure: function() {
                        $scope.detailInValidList.push(index);
                    },
                });
        };
    });

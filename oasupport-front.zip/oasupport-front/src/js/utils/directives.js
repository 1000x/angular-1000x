const angular = require('angular');

/**
 * app.directives
 */
module.exports = angular
    .module('app.directives', [])
    .directive('amountFormat', [
        '$parse',
        '$filter',
        function($parse, $filter) {
            //let numFilter = $filter('currency');
            return {
                restrict: 'A',
                require: 'ngModel',
                link: function(scope, element, attrs, ngModel) {
                    function formatter(value) {
                        if (!value) return '';
                        return value.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                        //return numFilter(value, '￥', 0); // format
                    }

                    function parser(value) {
                        if (!value) return '';
                        return String(value).replace(/[,￥]/g, '');
                    }
                    // model から view へ
                    ngModel.$formatters.push(formatter);
                    // view から model へ
                    ngModel.$parsers.push(parser);

                    $(element).bind('blur', function() {
                        $(this)[0].value = formatter(ngModel.$modelValue);
                    });

                    $(element).on('focus', function() {
                        if (ngModel.$modelValue) {
                            $(this)[0].value = ngModel.$modelValue;
                            $(this).select();
                        }
                    });
                },
            };
        },
    ])
    .directive('inputConvert', [
        function() {
            let Sys = {};
            let ua = navigator.userAgent.toLowerCase();
            let s;
            (s = ua.match(/rv:([\d.]+)\) like gecko/))
                ? (Sys.ie = s[1])
                : (s = ua.match(/msie ([\d.]+)/))
                ? (Sys.ie = s[1])
                : (s = ua.match(/edge\/([\d.]+)/))
                ? (Sys.edge = s[1])
                : (s = ua.match(/firefox\/([\d.]+)/))
                ? (Sys.firefox = s[1])
                : (s = ua.match(/chrome\/([\d.]+)/))
                ? (Sys.chrome = s[1])
                : (s = ua.match(/opera.([\d.]+)/))
                ? (Sys.opera = s[1])
                : (s = ua.match(/version\/([\d.]+).*safari/))
                ? (Sys.safari = s[1])
                : 0;

            return {
                restrict: 'A',
                require: 'ngModel',
                link: function(scope, element, attrs, ngModel) {
                    if (Sys.ie || Sys.firefox || Sys.edge) {
                        $(element).css('ime-mode', 'disabled');
                    }

                    /**
                     * type定義： tel integer number decimal date
                     */
                    let TYPES = {
                        TEL: 'tel', // 電話番号
                        INTEGER: 'integer', // 数字(例：012 will be 12)
                        NUMBER: 'number', // 数字(小数点入力可)
                        DECIMAL: 'decimal', // 数字(小数点、+,-入力可)
                        DATE: 'date', // 日付(数字+/)
                        NO: 'no', // 数字だけ
                        AC: 'ac', // 英数字
                    };

                    /**
                     * type 取得
                     */
                    let type = jQuery.trim(attrs['inputConvert']);
                    if (type) {
                        type = type.toLowerCase();
                    } else {
                        type = TYPES.INTEGER;
                    }

                    /**
                     * removeLeftZero
                     * @param str
                     */
                    function removeLeftZero(str) {
                        if (!str) return '';
                        if (/^0+$/.test(str)) return '0';
                        return str.replace(/\b(0+)/g, '');
                    }

                    /**
                     * getCursortPosition
                     */
                    function getCursortPosition() {
                        let CaretPos = 0;
                        // IE Support
                        if (document.selection) {
                            element[0].focus();
                            let Sel = document.selection.createRange();
                            Sel.moveStart('character', -element[0].value.length);
                            CaretPos = Sel.text.length;
                        } else {
                            CaretPos = element[0].selectionStart;
                        }
                        return CaretPos;
                    }

                    /**
                     * setCaretPosition
                     */
                    function setCaretPosition(pos) {
                        if (element[0].setSelectionRange) {
                            element[0].focus();
                            element[0].setSelectionRange(pos, pos);
                        } else if (element[0].createTextRange) {
                            let range = element[0].createTextRange();
                            range.collapse(true);
                            range.moveEnd('character', pos);
                            range.moveStart('character', pos);
                            range.select();
                        }
                    }

                    $(element)
                        .on('input', function() {
                            let position = getCursortPosition(),
                                selection = window.getSelection().toString();

                            if (!$(this).val()) {
                                ngModel.$setViewValue(null);
                                ngModel.$render();
                                return;
                            }
                            let str = jQuery.trim(String($(this).val()).replace(/[,￥]/g, ''));
                            if (!str) {
                                ngModel.$setViewValue(null);
                                ngModel.$render();
                                return;
                            }

                            if (attrs['maxlength']) {
                                if (str.length > attrs['maxlength']) {
                                    ngModel.$setViewValue(ngModel.$viewValue);
                                    ngModel.$render();
                                    setCaretPosition(position);
                                    return;
                                }
                            }

                            let positionIndex = 0;

                            // 英数字の場合
                            if (type == TYPES.AC) {
                                // 全角→半角
                                if (str.match(/[^0-9a-zA-Z]/)) {
                                    str = str.replace(/[Ａ-Ｚａ-ｚ０-９]/, function(s) {
                                        return String.fromCharCode(s.charCodeAt(0) - 65248);
                                    });
                                    str = str.replace(/[^0-9a-zA-Z]/g, '');

                                    if (ngModel.$viewValue === null || selection || ngModel.$viewValue === undefined || str.length > String(ngModel.$viewValue).length) {
                                        positionIndex = 1;
                                    }
                                } else {
                                    if (ngModel.$viewValue === null || selection || ngModel.$viewValue === undefined) {
                                        positionIndex = 1;
                                    }
                                }
                                ngModel.$setViewValue(str);
                                ngModel.$render();
                            } else if (str.match(/[^0-9]/)) {
                                // 全角→半角
                                str = str.replace(/[０-９]/, function(s) {
                                    return String.fromCharCode(s.charCodeAt(0) - 0xfee0);
                                });

                                // telの場合
                                if (type == TYPES.TEL) {
                                    str = str.replace(/[－ー―]/g, '-').replace(/[^\d\-]/g, '');

                                    // integerの場合
                                } else if (type == TYPES.INTEGER) {
                                    str = removeLeftZero(str.replace(/[^\d]/g, ''));

                                    // numberの場合
                                } else if (type == TYPES.NUMBER) {
                                    str = '0' + str.replace(/[。．]/g, '.').replace(/[^\d\.]/g, '');
                                    let index = str.indexOf('.');
                                    if (index != -1) {
                                        str = removeLeftZero(str.substring(0, index)) + '.' + str.substring(index + 1).replace(/\./g, '');
                                    } else {
                                        str = removeLeftZero(str);
                                    }
                                    // decimalの場合
                                } else if (type == TYPES.DECIMAL) {
                                    str = removeLeftZero(
                                        str
                                            .replace(/[。．]/g, '.')
                                            .replace(/[－ー―]/g, '-')
                                            .replace(/[＋]/g, '+')
                                            .replace(/[^\d.\+\-]/g, '')
                                    );

                                    // dateの場合
                                } else if (type == TYPES.DATE) {
                                    str = str
                                        .replace(/[－ー―]/g, '-')
                                        .replace(/[・／]/g, '/')
                                        .replace(/[^\d\-\/]/g, '');

                                    // noの場合
                                } else if (type == TYPES.NO) {
                                    str = str.replace(/[^\d]/g, '');

                                    // その他
                                } else {
                                    return;
                                }

                                if (ngModel.$viewValue === null || selection || ngModel.$viewValue === undefined || str.length > String(ngModel.$viewValue).length) {
                                    positionIndex = 1;
                                }
                                ngModel.$setViewValue(str);
                                ngModel.$render();
                            } else {
                                if (type == TYPES.INTEGER || type == TYPES.NUMBER || type == TYPES.DECIMAL) {
                                    str = removeLeftZero(str);
                                }

                                if (ngModel.$viewValue === null || selection || ngModel.$viewValue === undefined) {
                                    positionIndex = 1;
                                }
                                ngModel.$setViewValue(str);
                                ngModel.$render();
                            }
                            setCaretPosition(position + positionIndex);
                        })
                        .on('paste', function(e) {
                            let $this = $(this),
                                original = e.originalEvent,
                                original_val = null,
                                str = null;

                            // Get the text
                            // content stream.
                            if (window.clipboardData && window.clipboardData.getData) {
                                // IE
                                original_val = window.clipboardData.getData('Text');
                            } else if (original.clipboardData && original.clipboardData.getData) {
                                original_val = original.clipboardData.getData('text/plain');
                            }

                            str = original_val;

                            if (str) {
                                // 英数字の場合
                                if (type == TYPES.AC) {
                                    str = str.replace(/[Ａ-Ｚａ-ｚ０-９]/g, function(s) {
                                        return String.fromCharCode(s.charCodeAt(0) - 65248);
                                    });
                                    str = str.replace(/[^0-9a-zA-Z]/g, '');
                                } else {
                                    str = str.replace(/[０-９]/g, function(s) {
                                        return String.fromCharCode(s.charCodeAt(0) - 0xfee0);
                                    });

                                    // telの場合
                                    if (type == TYPES.TEL) {
                                        str = str.replace(/[－ー―]/g, '-').replace(/[^\d\-]/g, '');

                                        // integerの場合
                                    } else if (type == TYPES.INTEGER) {
                                        str = removeLeftZero(str.replace(/[^\d]/g, ''));

                                        // numberの場合
                                    } else if (type == TYPES.NUMBER) {
                                        str = removeLeftZero(str.replace(/[。．]/g, '.').replace(/[^\d.]/g, ''));

                                        // decimalの場合
                                    } else if (type == TYPES.DECIMAL) {
                                        str = removeLeftZero(
                                            str
                                                .replace(/[。．]/g, '.')
                                                .replace(/[－ー―]/g, '-')
                                                .replace(/[＋]/g, '+')
                                                .replace(/[^\d.\+\-]/g, '')
                                        );

                                        // dateの場合
                                    } else if (type == TYPES.DATE) {
                                        str = str
                                            .replace(/[－ー―]/g, '-')
                                            .replace(/[・／]/g, '/')
                                            .replace(/[^\d\-\/]/g, '');

                                        // noの場合
                                    } else if (type == TYPES.NO) {
                                        str = str.replace(/[^\d]/g, '');

                                        // その他
                                    } else {
                                        str = jQuery.trim(original_val);
                                    }
                                }

                                // maxlength
                                if (attrs['maxlength']) {
                                    if (str.length > attrs['maxlength']) {
                                        str = str.substr(0, maxlength);
                                    }
                                }

                                str = !str ? null : str;
                            }
                            ngModel.$setViewValue(str);
                            ngModel.$render();

                            return false;
                        });
                },
            };
        },
    ])
    .directive('multiselect', [
        '$timeout',
        function($timeout) {
            return {
                restrict: 'A',
                scope: {
                    model: '=',
                },
                transclude: true,
                require: 'ngModel',
                link: function(scope, element, attrs, ngModel, transclude) {
                    // multiSelect
                    function multiSelect() {
                        transclude(function(clone) {
                            element.append(clone);
                            jQuery(element).multiselect({
                                height: 'auto',
                                minWidth: 170,
                                selectedList: 100,
                                checkAllText: '一括選択',
                                uncheckAllText: 'クリア',
                                noneSelectedText: attrs['noneSelectedText'],
                                selectedText: '# 個選択',
                            });
                        });
                    }

                    // ngmodel value watch
                    scope.$watch(
                        function() {
                            return ngModel.$modelValue;
                        },
                        function(newValue, oldVal) {
                            // title
                            $timeout(function() {
                                let selectedText = jQuery(element)
                                    .next()
                                    .children(':eq(1)')
                                    .text();
                                jQuery(element)
                                    .next()
                                    .attr('title', selectedText);
                            }, 200);
                        }
                    );

                    // options change
                    if (attrs.ngOptions && /\sin\s/.test(attrs.ngOptions)) {
                        let options = attrs.ngOptions.replace(/.*\sin\s([^ ]+).*/, '$1');
                        scope.$watch('$parent.' + options, function(newVal, oldVal) {
                            $timeout(function() {
                                multiSelect();
                                jQuery(element).multiselect('refresh');
                            });
                        });
                    }

                    // 初期化
                    $timeout(function() {
                        multiSelect();
                    });
                },
            };
        },
    ])
    .directive('ngMin', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, elem, attr, ctrl) {
                scope.$watch(attr.ngMin, function() {
                    ctrl.$setViewValue(ctrl.$viewValue);
                });
                let minValidator = function(value) {
                    let min = jQuery.isNumeric(attr.ngMin) ? attr.ngMin : scope.$eval(attr.ngMin) || 0;
                    if (value && value < min) {
                        ctrl.$setValidity('ngMin', false);
                        return undefined;
                    } else {
                        ctrl.$setValidity('ngMin', true);
                        return value;
                    }
                };
                ctrl.$parsers.push(minValidator);
                ctrl.$formatters.push(minValidator);
            },
        };
    })
    .directive('ngMax', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, elem, attr, ctrl) {
                scope.$watch(attr.ngMax, function() {
                    ctrl.$setViewValue(ctrl.$viewValue);
                });
                let maxValidator = function(value) {
                    let max = jQuery.isNumeric(attr.ngMax) ? attr.ngMax : scope.$eval(attr.ngMax) || Infinity;
                    if (value && value > max) {
                        ctrl.$setValidity('ngMax', false);
                        return undefined;
                    } else {
                        ctrl.$setValidity('ngMax', true);
                        return value;
                    }
                };
                ctrl.$parsers.push(maxValidator);
                ctrl.$formatters.push(maxValidator);
            },
        };
    })
    .directive('includeReplace', function() {
        return {
            require: 'ngInclude',
            restrict: 'A' /* optional */,
            link: function(scope, el, attrs) {
                el.replaceWith(el.children());
            },
        };
    })
    .directive('repeatDone', function() {
        return function(scope, element, attrs) {
            if (scope.$last) {
                // all are rendered
                scope.$eval(attrs.repeatDone);
            }
        };
    });

/**
 * navbar コントローラ
 */
module.exports = app =>
    app.controller('z99navbarCtrl', function($scope, $rootScope, $timeout, $session, $auth) {
        $scope.usrNm = $session.USR_NM;

        /**
         * 初期化
         */
        $scope.init = function() {
            // marquee
            let $marquee = $('.marquee .marquee-data').marquee({
                duration: 12000,
            });
            $marquee.on('mouseover', function() {
                $(this).marquee('pause');
            });
            $marquee.on('mouseleave', function() {
                $(this).marquee('resume');
            });

            // dropdown
            $('.navmenu .ui.dropdown').dropdown();
        };

        /**
         * hamburger
         */
        $scope.hamburger = function() {
            let transition = 'scale down';
            $('.ui.sidebar.small-screen')
                .sidebar('setting', {
                    transition: transition,
                    mobileTransition: transition,
                })
                .sidebar('toggle');
        };

        /**
         * logout
         */
        $scope.logout = function() {
            $auth.logout();
        };

        /**
         * refresh user
         */
        $rootScope.$on('refresh_user', function() {
            $scope.usrNm = $session.USR_NM;
        });

        $timeout(function() {
            $scope.init();
        }, 10);
    });

const moment = require('moment');

/**
 * 自社基本情報更新·画面コントローラ
 */
module.exports = app =>
    app.controller('omtomt01omt0101Ctrl', function($scope, $timeout, $api, message, commonService) {
        /**
         * 初期化
         */
        $scope.init = function() {
            $scope.company = {};

            let $url = '/omt01/r/item/';

            // 自社基本情報の取得
            $api.get($url, function(res) {
                if (res.success) {
                    let data = res.data;
                    $scope.company = data;
                }
            });

            // 初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.companyform').form('validate form');
            return jQuery('.companyform').form('is valid');
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            let $url = '/omt01/u/item';
            if ($scope.isValidForm()) {
                $api.post($url, $scope.company, function(res) {
                    if (res.success) {
                        message.showSuccess('success');
                    } else {
                        message.showError(res.data.message);
                        // show error details
                        let errDetails = res.data.details;
                        if (errDetails) {
                            for (let i = 0; i < errDetails.length; i++) {
                                jQuery('.companyform').form('add prompt', errDetails[i].target, errDetails[i].message);
                            }
                        }
                    }
                });
            }
        };

        /**
         * 郵便番号より、住所の取得処理
         * @param post
         */
        $scope.getAddress = function(post) {
            commonService.getAddrByPostCd(post, function(address) {
                $scope.company.address = address;
            });
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.companyform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 企業正式名称
                    compNm: {
                        identifier: 'compNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '企業正式名称'),
                            },
                        ],
                    },
                    // 企業名称(英字)
                    compEnNm: {
                        identifier: 'compEnNm',
                        rules: [
                            {
                                type: 'regExp[/^[A-Za-z0-9\u0000-\u00FF]*$/]',
                                prompt: message.getMsgById('E_XX_FW_5006', '企業名称(英字)'),
                            },
                        ],
                    },

                    // 設立年月日
                    registerDt: {
                        identifier: 'registerDt',
                        rules: [
                            {
                                type: 'date[YYYY-MM-DD]',
                                prompt: message.getMsgById('E_XX_FW_5012', '設立年月日'),
                            },
                            {
                                type: 'lessThan[' + moment().format('YYYY-MM-DD') + ']',
                                prompt: message.getMsgById('E_XX_FW_5016', '設立年月日'),
                            },
                        ],
                    },
                    // ホームページ
                    homepage: {
                        identifier: 'homepage',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', 'ホームページ'),
                            },
                            {
                                type: 'url',
                                prompt: message.getMsgById('E_XX_FW_5026', 'ホームページ'),
                            },
                        ],
                    },
                    //郵便番号
                    post: {
                        identifier: 'post',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '郵便番号'),
                            },
                        ],
                    },
                    //所在地
                    address: {
                        identifier: 'address',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '所在地'),
                            },
                        ],
                    },
                    //                //連絡メールアドレス
                    //                email: {
                    //                    identifier: 'email',
                    //                    rules: [
                    //                        {
                    //                            type   : 'email',
                    //                            prompt : message.getMsgById("E_XX_FW_5011", "メールアドレス")
                    //                        },
                    //                    ]
                    //                },
                },
                onSuccess: function() {
                    if (callback) callback();
                },
            });
        };
    });

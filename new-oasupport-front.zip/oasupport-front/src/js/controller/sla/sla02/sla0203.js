const swal = require('sweetalert2');
/**
 * 宛先情報更新·画面コントローラ
 */
module.exports = app =>
    app.controller('slasla02sla0203Ctrl', function($scope, $routeParams, $location, $timeout, $api, message) {
        /**
         * 初期化
         */
        $scope.init = function() {
            // データ初期化
            $api.get('/sla02/r/item/' + $routeParams.id, function(res) {
                if (res.success) {
                    $scope.address = res.data.address;
                } else {
                    swal({
                        type: 'error',
                        text: res.data.message,
                        allowOutsideClick: false,
                        confirmButtonText: '宛先一覧画面へ戻る',
                    }).then(function() {
                        $timeout(function() {
                            $location.path('sla0201');
                        });
                    });
                }
            });

            //初期化
            $timeout(function() {
                $scope.form_check();
            });
        };

        /**
         * is valid form
         */
        $scope.isValidForm = function() {
            jQuery('.mainform').form('validate form');
            return jQuery('.mainform').form('is valid');
        };

        /**
         * 更新ボタン押下
         */
        $scope.save = function() {
            if ($scope.isValidForm()) {
                swal({
                    text: '更新してよろしいですか。',
                    type: 'warning',
                    confirmButtonText: '確定',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'キャンセル',
                }).then(
                    function(isConfirm) {
                        if (isConfirm) {
                            $api.post('/sla02/u/item', $scope.address, function(res) {
                                if (res.success) {
                                    message.showSuccess('success');
                                } else {
                                    message.showError(res.data.message);
                                    // show error details
                                    let errDetails = res.data.details;
                                    if (errDetails) {
                                        for (let i = 0; i < errDetails.length; i++) {
                                            jQuery('.mainform').form('add prompt', errDetails[i].target, errDetails[i].message);
                                        }
                                    }
                                }
                            });
                        }
                    },
                    function(dismiss) {
                        // 処理なし
                    }
                );
            }
        };

        /**
         * form check
         */
        $scope.form_check = function(callback) {
            jQuery('.mainform').form({
                on: 'blur',
                inline: true,
                keyboardShortcuts: false,
                fields: {
                    // 会社名称
                    customerCompNm: {
                        identifier: 'customerCompNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '会社名称'),
                            },
                        ],
                    },
                    // 担当者名前
                    businessPicNm: {
                        identifier: 'businessPicNm',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '担当者名前'),
                            },
                        ],
                    },
                    // 担当者メールアドレス
                    toEmail: {
                        identifier: 'toEmail',
                        rules: [
                            {
                                type: 'empty',
                                prompt: message.getMsgById('E_XX_FW_5003', '担当者メールアドレス'),
                            },
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', '担当者メールアドレス'),
                            },
                        ],
                    },
                    // CCメールアドレス1
                    ccEmail1: {
                        identifier: 'ccEmail1',
                        optional: true,
                        rules: [
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', 'CCメールアドレス1'),
                            },
                        ],
                    },
                    // CCメールアドレス2
                    ccEmail2: {
                        identifier: 'ccEmail2',
                        optional: true,
                        rules: [
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', 'CCメールアドレス2'),
                            },
                        ],
                    },
                    // CCメールアドレス3
                    ccEmail3: {
                        identifier: 'ccEmail3',
                        optional: true,
                        rules: [
                            {
                                type: 'email',
                                prompt: message.getMsgById('E_XX_FW_5011', 'CCメールアドレス3'),
                            },
                        ],
                    },
                },
                onFailure: function() {
                    let $errorField = $(this)
                        .find('.field.error')
                        .eq(0);
                    $errorField.focus();
                    $('html,body').animate(
                        {
                            scrollTop: $errorField.offset().top - ($(window).height() - $errorField.outerHeight(true)) / 2,
                        },
                        200
                    );
                    return false;
                },
            });
        };
    });
